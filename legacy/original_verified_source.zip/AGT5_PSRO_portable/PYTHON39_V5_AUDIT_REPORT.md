# Python 3.9 compatibility audit: Version 5

## Original issue

The V2 archive had 12 parser-reported Python 3.9 syntax errors in 2 shared
run modules: `code_src/runs/main_run.py` and `code_src/runs/main_run_SB.py`.
They involved double-quoted dictionary keys nested inside double-quoted
f-strings (PEP 701 syntax). That makes *other* scripts fail when importing
the shared modules. The V4 fixed these; V5 revalidates the entire tree.

## Validation performed in this environment

- 39/39 Python source files compiled under Python 3.13.5.
- 39/39 passed independent **Python 3.9 grammar** parsing using parso.
- 13/13 `runs.main_*.py` modules imported successfully.
- 19/19 `adversarial_graph_game` modules imported successfully.
- Four actor–critic PSRO configurations completed a reduced training smoke test.
- Behavior-cloning diagnostic completed a reduced smoke test.
- The exact `main_run_SB_PPO_relgnn_diagnostic.py` module completed reduced
  static/action Rel-GNN trials (seed 11, 8 PPO steps).
- W&B instrumentation remains present, but live cloud logging was not tested.

**Important limitation:** This environment had Python 3.13.5, not Python 3.9.9.
Native runtime validation still requires the real VM's interpreter, and no
full-budget training runs were performed here.

The archive includes `SOURCE_SHA256.json` and `python39_preflight.py` to detect
both unintended version-mixing and syntax/import errors on the VM **before**
launching expensive training.
