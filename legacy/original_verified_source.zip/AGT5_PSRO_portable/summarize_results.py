#!/usr/bin/env python3
"""Summarize the output JSON files from run_full_arch_psro.py (stdlib only)."""
import argparse
import csv
import json
import statistics
from pathlib import Path


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--results', type=Path, default=Path(__file__).resolve().parent / 'results')
    a = p.parse_args()
    files = sorted(a.results.glob('*_seed*.json'))
    runs = []
    steps = []
    for f in files:
        d = json.loads(f.read_text())
        if d.get('status') != 'complete':
            print('SKIP incomplete:', f.name)
            continue
        name = f"{d['actor']}/{d['critic']}"
        h = d['history']
        runs.append({
            'variant': f.stem.rsplit('_seed', 1)[0], 'architecture': name,
            'seed': d['seed'], 'steps': d['steps'], 'expansions': d['n_expansions'],
            'final_value': d['final'], 'abs_gap_to_svi': d['abs_gap'],
            'blue_improving_BR_count': sum(x['blue_improves'] for x in h),
            'red_improving_BR_count': sum(x['red_improves'] for x in h),
            'mean_blue_response_deficit': statistics.mean(x['blue_BR'] - x['meta_before'] for x in h),
            'blue_training_seconds': sum(x['blue_seconds'] for x in h),
            'red_training_seconds': sum(x['red_seconds'] for x in h),
            'elapsed_seconds': d['total_seconds'],
        })
        for x in h:
            steps.append({'variant': runs[-1]['variant'], 'seed': d['seed'], **x})
    a.results.mkdir(parents=True, exist_ok=True)
    for filename, records in [('per_run_results.csv', runs), ('per_iteration_results.csv', steps)]:
        if records:
            with (a.results / filename).open('w', newline='') as f:
                w = csv.DictWriter(f, fieldnames=list(records[0]))
                w.writeheader()
                w.writerows(records)
    grouped = {}
    for r in runs:
        key = (r['variant'], r['steps'], r['expansions'])
        grouped.setdefault(key, []).append(r)
    summary = []
    for (v, budget, expansions), group in sorted(grouped.items()):
        vals = [r['final_value'] for r in group]
        gaps = [r['abs_gap_to_svi'] for r in group]
        def sd(x): return statistics.stdev(x) if len(x) > 1 else 0.0
        summary.append({
            'variant': v, 'steps': budget, 'expansions': expansions,
            'num_seeds': len(group), 'mean_final_value': statistics.mean(vals),
            'sd_final_value': sd(vals), 'mean_abs_gap': statistics.mean(gaps),
            'sd_abs_gap': sd(gaps),
            'improving_blue_BRs': sum(r['blue_improving_BR_count'] for r in group),
            'total_blue_BR_calls': expansions * len(group),
            'mean_blue_training_seconds_total': statistics.mean(r['blue_training_seconds'] for r in group),
        })
    if summary:
        with (a.results / 'architecture_summary.csv').open('w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=list(summary[0])); w.writeheader(); w.writerows(summary)
        for r in summary:
            print(f"{r['variant']:8s} n={r['num_seeds']} budget={r['steps']} "
                  f"V={r['mean_final_value']:.4f} ± {r['sd_final_value']:.4f} "
                  f"gap={r['mean_abs_gap']:.4f} "
                  f"Blue improving={r['improving_blue_BRs']}/{r['total_blue_BR_calls']}")
    else:
        print('No completed result files found in', a.results)

if __name__ == '__main__':
    main()
