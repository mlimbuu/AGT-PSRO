#!/usr/bin/env python3
"""Validate source syntax and Python import/runtime compatibility (stdlib + installed deps)."""
from __future__ import annotations
import ast
import importlib
from pathlib import Path
import sys
import types

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "code_src"))
sys.path.insert(0, str(ROOT / "code_scenario"))


def main():
    # Compile with the active interpreter. On your Python 3.9 VM this is the
    # authoritative syntax check and catches the PEP 701 f-string error.
    scripts = sorted(ROOT.rglob("*.py"))
    for script in scripts:
        source = script.read_text(encoding="utf-8")
        compile(source, str(script), "exec")
        ast.parse(source, filename=str(script), feature_version=(3, 9))
    print("PASS: {} files compile on Python {}".format(len(scripts), sys.version.split()[0]))

    # Python >=3.12's ast.parse(feature_version=(3,9)) is not strict about
    # newer f-string grammar. Use an independent 3.9 grammar parser, if installed.
    try:
        import parso
    except ImportError:
        if sys.version_info >= (3, 12):
            raise RuntimeError(
                "On Python 3.12+, install parso (`python -m pip install parso`) "
                "to perform a strict Python 3.9 f-string check. "
                "Alternatively, run this script using Python 3.9."
            )
    else:
        grammar = parso.load_grammar(version="3.9")
        syntax_errors = []
        for script in scripts:
            parsed = grammar.parse(script.read_text(encoding="utf-8"), error_recovery=True)
            for err in grammar.iter_errors(parsed):
                syntax_errors.append("{}:{}: {}".format(
                    script.relative_to(ROOT), err.start_pos, err))
        if syntax_errors:
            raise SyntaxError("Python 3.9 grammar validation failed:\n" +
                              "\n".join(syntax_errors[:30]))
        print("PASS: {} files satisfy strict Python 3.9 grammar (parso)".format(len(scripts)))

    from adversarial_graph_game.compat import dataclass, strict_zip
    from adversarial_graph_game.models import GameState
    from adversarial_graph_game.psro_ppo_relgnn_ablation import train_relgnn_blue_best_response
    from runs.main_run_SB import SMALL_SCENARIO, build_scenario
    from runs.main_run_SB_RelGNN_behavior_cloning_diagnostic import Result
    assert GameState and train_relgnn_blue_best_response and Result
    print("PASS: game package, run modules, and BC diagnostic import")

    # Import all run entry points without executing their expensive main().
    run_files = sorted((ROOT / "code_src" / "runs").glob("main_*.py"))
    for run_file in run_files:
        importlib.import_module("runs." + run_file.stem)
    print("PASS: {} run modules import, including PPO Rel-GNN diagnostic".format(len(run_files)))

    # Include other project modules in the import audit as well.
    package_files = sorted((ROOT / "code_src" / "adversarial_graph_game").glob("*.py"))
    for package_file in package_files:
        importlib.import_module("adversarial_graph_game." + package_file.stem)
    print("PASS: {} adversarial_graph_game modules import".format(len(package_files)))

    assert list(strict_zip((1, 2), (3, 4))) == [(1, 3), (2, 4)]
    try:
        list(strict_zip((1, 2), (3,)))
    except ValueError:
        pass
    else:
        raise AssertionError("strict_zip must reject unequal-length iterables")
    print("PASS: strict_zip length validation")

    import adversarial_graph_game.compat as compat
    original_sys = compat.sys
    try:
        # Simulate the Python 3.9 branch without changing global sys.version_info.
        compat.sys = types.SimpleNamespace(version_info=(3, 9))
        @dataclass(slots=True, frozen=True)
        class Python39Example:
            value: int
        assert Python39Example(3).value == 3
        assert not hasattr(Python39Example, "__slots__")
        try:
            Python39Example(3).value = 4
        except Exception:
            pass
        else:
            raise AssertionError("Frozen dataclass must remain immutable")
    finally:
        compat.sys = original_sys
    print("PASS: simulated Python 3.9 dataclass compatibility branch")

    game = build_scenario(SMALL_SCENARIO, max_ammo=1).build_game(with_support=True)
    init = GameState(game.canonical_positions(SMALL_SCENARIO.initial_positions),
                     SMALL_SCENARIO.initial_graph, 1)
    assert game.blue_actions(init)
    print("PASS: scenario creation, game state, and legal actions")
    print("Actual interpreter:", sys.version.split()[0])
    if sys.version_info[:2] != (3, 9):
        print("NOTE: To validate Python 3.9 runtime itself, run this script inside a real 3.9 VM.")


if __name__ == "__main__":
    main()
