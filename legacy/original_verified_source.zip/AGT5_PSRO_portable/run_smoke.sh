#!/usr/bin/env bash
# Safe non-scientific end-to-end smoke checks. Does not run the full PPO budgets.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="${PYTHON_BIN:-python3}"
"$PYTHON_BIN" "$ROOT/verify_portability.py"
"$PYTHON_BIN" "$ROOT/run_full_arch_psro.py" --variant all --seed 11 --steps 8 --iterations 1 --out-dir "$ROOT/smoke_results"
"$PYTHON_BIN" "$ROOT/summarize_results.py" --results "$ROOT/smoke_results"
"$PYTHON_BIN" "$ROOT/code_src/runs/main_run_SB_RelGNN_behavior_cloning_diagnostic.py" --seeds 11 --epochs 1 --out-dir "$ROOT/smoke_bc_results"
echo "Smoke test passed; output is for validation only, not experimental analysis."
