"""Blue PPO oracle feature ablation on the SMALL_SCENARIO.

This isolates the first Blue best-response problem against the fixed initial Red
policy.  It does NOT run PSRO.  The exact DP best response (52 on the current SB
cell) is the reference target.

All variants retain the legal-action mask because the Blue legal joint-action
set is state-dependent; removing that mask would require changing the game by
adding semantics/penalties for illegal actions.
"""
from __future__ import annotations

# Enable direct execution without PYTHONPATH, pip install, or a fixed CWD.
import sys as _sys
from pathlib import Path as _Path
_project_root = _Path(__file__).resolve().parents[2]
for _source in (_project_root / "code_src", _project_root / "code_scenario"):
    if str(_source) not in _sys.path:
        _sys.path.insert(0, str(_source))


import csv
import json
from dataclasses import asdict
from pathlib import Path
from statistics import mean, pstdev

from adversarial_graph_game.psro import (
    TabularPolicy,
    evaluate_policy_pair_exact,
    exact_blue_best_response_behavioral,
    make_stay_red_policy,
)
from adversarial_graph_game.psro_ppo import PPOConfig, train_ppo_best_response
from runs.main_run_SB import SMALL_SCENARIO, build_scenario

ROOT = Path(__file__).resolve().parents[1]
AMMO = 1
WITH_SUPPORT = True
SEEDS = (11, 12, 13)
TOTAL_STEPS = 10_000


def greedy_snapshot(policy: TabularPolicy) -> TabularPolicy:
    mapping = {}
    for state, action_probs in policy.action_probabilities.items():
        best_action = max(action_probs, key=action_probs.get)
        mapping[state] = {best_action: 1.0}
    return TabularPolicy(policy.player, mapping, name=f"{policy.name}_greedy")


def main() -> None:
    scenario = SMALL_SCENARIO
    game = build_scenario(scenario, max_ammo=AMMO).build_game(
        with_support=WITH_SUPPORT
    )
    red_seed = make_stay_red_policy(game)
    exact_br = exact_blue_best_response_behavioral(
        game,
        [red_seed],
        [1.0],
        initial_graph=scenario.initial_graph,
        initial_ammo=AMMO,
        initial_positions=scenario.initial_positions,
    ).initial_value

    variants = [
        (
            "A_positions_only",
            dict(
                include_graph_feature=False,
                include_ammo_feature=False,
                include_red_reachability_feature=False,
            ),
        ),
        (
            "B_graph_ammo",
            dict(
                include_graph_feature=True,
                include_ammo_feature=True,
                include_red_reachability_feature=False,
            ),
        ),
        (
            "C_graph_ammo_reach1",
            dict(
                include_graph_feature=True,
                include_ammo_feature=True,
                include_red_reachability_feature=True,
            ),
        ),
    ]

    rows = []
    print(f"Exact Blue BR target: {exact_br:.9f}", flush=True)
    print("All variants use the same legal-action mask.\n", flush=True)

    for variant_name, feature_kwargs in variants:
        print(f"=== {variant_name} ===", flush=True)
        for seed in SEEDS:
            cfg = PPOConfig(
                total_steps=TOTAL_STEPS,
                rollout_steps=512,
                max_episode_steps=32,
                hidden_size=64,
                learning_rate=3e-4,
                update_epochs=4,
                minibatch_size=128,
                entropy_coef=0.01,
                reward_scale=0.01,
                seed=seed,
                **feature_kwargs,
            )
            policy, stats = train_ppo_best_response(
                game,
                player="blue",
                opponent_population=[red_seed],
                opponent_weights=[1.0],
                initial_graph=scenario.initial_graph,
                initial_ammo=AMMO,
                initial_positions=scenario.initial_positions,
                config=cfg,
                name=f"{variant_name}_seed{seed}",
            )
            stochastic_value = evaluate_policy_pair_exact(
                game,
                policy,
                red_seed,
                initial_graph=scenario.initial_graph,
                initial_ammo=AMMO,
                initial_positions=scenario.initial_positions,
            )
            greedy = greedy_snapshot(policy)
            greedy_value = evaluate_policy_pair_exact(
                game,
                greedy,
                red_seed,
                initial_graph=scenario.initial_graph,
                initial_ammo=AMMO,
                initial_positions=scenario.initial_positions,
            )
            row = {
                "variant": variant_name,
                "seed": seed,
                "steps": TOTAL_STEPS,
                "stochastic_value": float(stochastic_value),
                "greedy_value": float(greedy_value),
                "stochastic_gap_to_exact": float(stochastic_value - exact_br),
                "greedy_gap_to_exact": float(greedy_value - exact_br),
                "elapsed_seconds": stats.elapsed_seconds,
                "episodes": stats.episodes,
                "mean_training_episode_cost": stats.mean_episode_cost,
            }
            rows.append(row)
            print(
                f"seed={seed}: stochastic={stochastic_value:.3f} "
                f"(gap {stochastic_value-exact_br:+.3f}), "
                f"greedy={greedy_value:.3f} "
                f"(gap {greedy_value-exact_br:+.3f}), "
                f"time={stats.elapsed_seconds:.2f}s",
                flush=True,
            )

    summaries = []
    print("\n=== SUMMARY ===", flush=True)
    for variant_name, _ in variants:
        vr = [row for row in rows if row["variant"] == variant_name]
        sv = [row["stochastic_value"] for row in vr]
        gv = [row["greedy_value"] for row in vr]
        summary = {
            "variant": variant_name,
            "n_seeds": len(vr),
            "stochastic_mean": mean(sv),
            "stochastic_std": pstdev(sv),
            "stochastic_best": min(sv),
            "greedy_mean": mean(gv),
            "greedy_std": pstdev(gv),
            "greedy_best": min(gv),
            "greedy_mean_gap_to_exact": mean(gv) - exact_br,
        }
        summaries.append(summary)
        print(
            f"{variant_name:25s} | stochastic {summary['stochastic_mean']:.3f} "
            f"± {summary['stochastic_std']:.3f} (best {summary['stochastic_best']:.3f}) | "
            f"greedy {summary['greedy_mean']:.3f} ± {summary['greedy_std']:.3f} "
            f"(best {summary['greedy_best']:.3f})",
            flush=True,
        )

    outdir = ROOT / "ppo_ablation_results"
    outdir.mkdir(exist_ok=True)
    payload = {
        "scenario": scenario.name,
        "ammo": AMMO,
        "support": WITH_SUPPORT,
        "exact_blue_br": float(exact_br),
        "seeds": list(SEEDS),
        "total_steps": TOTAL_STEPS,
        "note": "All variants retain legal-action masking.",
        "rows": rows,
        "summaries": summaries,
    }
    (outdir / "SB_blue_ppo_feature_ablation.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )
    with (outdir / "SB_blue_ppo_feature_ablation.csv").open(
        "w", newline="", encoding="utf-8"
    ) as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    main()
