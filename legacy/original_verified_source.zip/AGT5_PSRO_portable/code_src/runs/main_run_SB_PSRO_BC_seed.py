from __future__ import annotations

# Enable direct execution without PYTHONPATH, pip install, or a fixed CWD.
import sys as _sys
from pathlib import Path as _Path
_project_root = _Path(__file__).resolve().parents[2]
for _source in (_project_root / "code_src", _project_root / "code_scenario"):
    if str(_source) not in _sys.path:
        _sys.path.insert(0, str(_source))

from adversarial_graph_game.compat import strict_zip


import csv, json, random
from dataclasses import asdict
from pathlib import Path
from time import perf_counter

import numpy as np
import torch
from torch import nn

from adversarial_graph_game import PruningMode, solve_ammo_layers
from adversarial_graph_game.matrix_game import solve_zero_sum_matrix_game
from adversarial_graph_game.models import GameState
from adversarial_graph_game.psro import (
    TabularPolicy,
    build_empirical_payoff_matrix,
    evaluate_policy_pair_exact,
    exact_blue_best_response_behavioral,
    make_stay_red_policy,
)
from adversarial_graph_game.psro_ppo import PPOConfig, train_ppo_best_response
from adversarial_graph_game.psro_ppo_relgnn import (
    RelationalGraphBuilder,
    StaticRelGNNActor,
    train_relgnn_blue_best_response,
)
from runs.main_run_SB import SMALL_SCENARIO, build_scenario

ROOT = Path(__file__).resolve().parents[1]
AMMO = 1
MAX_ITER = 5
BLUE_SEED = 11
RED_SEED = 101

BLUE_CFG = PPOConfig(
    total_steps=6000,
    rollout_steps=512,
    max_episode_steps=32,
    hidden_size=64,
    learning_rate=3e-4,
    update_epochs=4,
    minibatch_size=128,
    entropy_coef=0.01,
    entropy_coef_final=None,
    reward_scale=0.01,
    seed=BLUE_SEED,
    include_graph_feature=True,
    include_ammo_feature=True,
    include_red_reachability_feature=True,
)
RED_CFG = PPOConfig(
    total_steps=6000,
    rollout_steps=512,
    max_episode_steps=32,
    hidden_size=64,
    learning_rate=3e-4,
    update_epochs=4,
    minibatch_size=128,
    entropy_coef=0.01,
    entropy_coef_final=None,
    reward_scale=0.01,
    seed=RED_SEED,
    include_graph_feature=True,
    include_ammo_feature=True,
    include_red_reachability_feature=True,
)


def greedy_action(policy: TabularPolicy, state: GameState):
    probs = policy.action_probabilities[state]
    return max(probs, key=probs.get)


def train_static_relgnn_bc_seed(game, red_seed: TabularPolicy, seed: int = 11):
    """BC clone of exact Blue BR to the initial stay-Red seed.

    This affects only Pi_B^0. Later PSRO Blue BRs are random-init PPO as usual.
    """
    exact = exact_blue_best_response_behavioral(
        game, [red_seed], [1.0],
        initial_graph=SMALL_SCENARIO.initial_graph,
        initial_ammo=AMMO,
        initial_positions=SMALL_SCENARIO.initial_positions,
    )
    teacher = exact.policy
    states = sorted(
        [s for s in teacher.action_probabilities if not game.is_terminal(s)],
        key=lambda s: (s.red_ammo, s.graph_id, s.blue_positions),
    )

    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed); torch.set_num_threads(1)
    graph = RelationalGraphBuilder(game, BLUE_CFG)
    actor = StaticRelGNNActor(graph, d=16)
    opt = torch.optim.Adam(actor.parameters(), lr=3e-3)
    examples = []
    for s in states:
        legal = game.blue_actions(s)
        ta = greedy_action(teacher, s)
        examples.append((s, legal, legal.index(ta)))

    started = perf_counter()
    final_acc = 0.0
    final_loss = float('nan')
    epochs = 0
    for epochs in range(1, 81):
        random.shuffle(examples)
        actor.train(); opt.zero_grad(); pending = 0
        for idx, (s, legal, label) in enumerate(examples, start=1):
            logits = actor.logits(s, legal)
            loss = nn.functional.cross_entropy(logits.unsqueeze(0), torch.tensor([label]))
            (loss / 16.0).backward(); pending += 1
            if pending == 16 or idx == len(examples):
                nn.utils.clip_grad_norm_(actor.parameters(), 1.0)
                opt.step(); opt.zero_grad(); pending = 0
        if epochs % 10 == 0 or epochs == 80:
            actor.eval(); correct = 0; losses = []
            with torch.no_grad():
                for s, legal, label in examples:
                    logits = actor.logits(s, legal)
                    losses.append(float(nn.functional.cross_entropy(logits.unsqueeze(0), torch.tensor([label])).item()))
                    correct += int(int(torch.argmax(logits).item()) == label)
            final_acc = correct / len(examples)
            final_loss = float(np.mean(losses))
            if final_acc == 1.0 and final_loss < 1e-3:
                break

    mapping = {}
    actor.eval()
    with torch.no_grad():
        for s in states:
            legal = game.blue_actions(s)
            logits = actor.logits(s, legal)
            chosen = legal[int(torch.argmax(logits).item())]
            mapping[s] = {chosen: 1.0}
    clone = TabularPolicy('blue', mapping, name='blue_static_relgnn_BC_seed')
    bc_value = float(evaluate_policy_pair_exact(
        game, clone, red_seed,
        initial_graph=SMALL_SCENARIO.initial_graph,
        initial_ammo=AMMO,
        initial_positions=SMALL_SCENARIO.initial_positions,
    ))
    return clone, {
        'teacher_exact_br_value': float(exact.initial_value),
        'bc_seed_value_vs_initial_red': bc_value,
        'bc_accuracy': final_acc,
        'bc_loss': final_loss,
        'bc_epochs': epochs,
        'bc_train_seconds': perf_counter() - started,
        'teacher_states': len(states),
    }


def expected_blue_cost(game, blue, red_pop, red_w):
    return float(sum(float(w) * evaluate_policy_pair_exact(
        game, blue, r,
        initial_graph=SMALL_SCENARIO.initial_graph,
        initial_ammo=AMMO,
        initial_positions=SMALL_SCENARIO.initial_positions,
    ) for r, w in strict_zip(red_pop, red_w)))


def expected_red_cost(game, red, blue_pop, blue_w):
    return float(sum(float(w) * evaluate_policy_pair_exact(
        game, b, red,
        initial_graph=SMALL_SCENARIO.initial_graph,
        initial_ammo=AMMO,
        initial_positions=SMALL_SCENARIO.initial_positions,
    ) for b, w in strict_zip(blue_pop, blue_w)))


def main():
    game = build_scenario(SMALL_SCENARIO, max_ammo=AMMO).build_game(with_support=True)
    exact = solve_ammo_layers(game, pruning_mode=PruningMode.NONE, tolerance=1e-9, max_iterations=5000)
    ip = game.canonical_positions(SMALL_SCENARIO.initial_positions)
    svi = float(exact.values[(SMALL_SCENARIO.initial_graph, AMMO)][ip])
    print(f'SVI={svi:.9f}', flush=True)

    red_seed = make_stay_red_policy(game, name='red_stay_seed')
    bc_seed, bc_stats = train_static_relgnn_bc_seed(game, red_seed, seed=BLUE_SEED)
    print('BC_SEED', bc_stats, flush=True)

    blue_pop = [bc_seed]
    red_pop = [red_seed]
    blue_sigs = {bc_seed.signature(digits=7)}
    red_sigs = {red_seed.signature(digits=7)}
    history = []
    total_started = perf_counter()

    for k in range(1, MAX_ITER + 1):
        M = build_empirical_payoff_matrix(
            game, blue_pop, red_pop,
            initial_graph=SMALL_SCENARIO.initial_graph,
            initial_ammo=AMMO,
            initial_positions=SMALL_SCENARIO.initial_positions,
        )
        sol = solve_zero_sum_matrix_game(M, tolerance=1e-9)
        v = float(sol.value)

        bcfg = PPOConfig(**{**asdict(BLUE_CFG), 'seed': BLUE_SEED + k - 1})
        rcfg = PPOConfig(**{**asdict(RED_CFG), 'seed': RED_SEED + k - 1})
        bpol, bstat, _ = train_relgnn_blue_best_response(
            game,
            actor_kind='static_relgnn',
            opponent_population=red_pop,
            opponent_weights=sol.red_policy,
            initial_graph=SMALL_SCENARIO.initial_graph,
            initial_ammo=AMMO,
            initial_positions=SMALL_SCENARIO.initial_positions,
            config=bcfg,
            name=f'blue_static_relgnn_br_{k}',
            gnn_dim=16,
        )
        rpol, rstat = train_ppo_best_response(
            game,
            player='red',
            opponent_population=blue_pop,
            opponent_weights=sol.blue_policy,
            initial_graph=SMALL_SCENARIO.initial_graph,
            initial_ammo=AMMO,
            initial_positions=SMALL_SCENARIO.initial_positions,
            config=rcfg,
            name=f'red_mlp_br_{k}',
        )
        bv = expected_blue_cost(game, bpol, red_pop, sol.red_policy)
        rv = expected_red_cost(game, rpol, blue_pop, sol.blue_policy)
        bsig = bpol.signature(digits=7); rsig = rpol.signature(digits=7)
        bnew = bsig not in blue_sigs; rnew = rsig not in red_sigs
        row = {
            'iteration': k,
            'blue_population_before': len(blue_pop),
            'red_population_before': len(red_pop),
            'meta_value': v,
            'blue_br_value': bv,
            'red_br_value': rv,
            'blue_signed_gain': v - bv,
            'red_signed_gain': rv - v,
            'blue_abs_deviation': abs(v - bv),
            'red_abs_deviation': abs(rv - v),
            'blue_new': bnew,
            'red_new': rnew,
            'blue_train_seconds': float(bstat.elapsed_seconds),
            'red_train_seconds': float(rstat.elapsed_seconds),
            'blue_meta_strategy': [float(x) for x in sol.blue_policy],
            'red_meta_strategy': [float(x) for x in sol.red_policy],
        }
        history.append(row)
        print('ITER', k, row, flush=True)
        if bnew:
            blue_pop.append(bpol); blue_sigs.add(bsig)
        if rnew:
            red_pop.append(rpol); red_sigs.add(rsig)

    M = build_empirical_payoff_matrix(
        game, blue_pop, red_pop,
        initial_graph=SMALL_SCENARIO.initial_graph,
        initial_ammo=AMMO,
        initial_positions=SMALL_SCENARIO.initial_positions,
    )
    sol = solve_zero_sum_matrix_game(M, tolerance=1e-9)
    final_v = float(sol.value)
    payload = {
        'scenario': SMALL_SCENARIO.name,
        'support_relations': ['3->(1,4)', '1->(2,3)'],
        'experiment': 'BC-seeded Blue population only; later Blue BRs random-init Static Rel-GNN PPO',
        'semantics': 'vanilla_PSRO_episode_level_opponent_policy_sampling',
        'blue_seed': 'Static Rel-GNN BC clone of exact Blue BR vs initial stay-Red',
        'blue_oracle': 'Static Rel-GNN actor + MLP critic PPO, random init each BR',
        'red_oracle': 'MLP PPO unchanged',
        'ppo_steps_per_oracle': 6000,
        'ppo_update_epochs': 4,
        'entropy': 'fixed 0.01',
        'svi_reference_value': svi,
        'bc_seed_stats': bc_stats,
        'iterations_run': MAX_ITER,
        'blue_population_size': len(blue_pop),
        'red_population_size': len(red_pop),
        'final_meta_value': final_v,
        'absolute_gap_to_svi': abs(final_v - svi),
        'blue_meta_strategy': [float(x) for x in sol.blue_policy],
        'red_meta_strategy': [float(x) for x in sol.red_policy],
        'payoff_matrix_red_rows_blue_columns': M.tolist(),
        'history': history,
        'elapsed_seconds': perf_counter() - total_started,
    }
    outj = Path('/mnt/data/SB_both_support_PSRO_BCSeed_StaticRelGNNBlue_6k_5iter.json')
    outc = Path('/mnt/data/SB_both_support_PSRO_BCSeed_StaticRelGNNBlue_6k_5iter.csv')
    outj.write_text(json.dumps(payload, indent=2), encoding='utf-8')
    fields = [
        'iteration','blue_population_before','red_population_before','meta_value',
        'blue_br_value','red_br_value','blue_signed_gain','red_signed_gain',
        'blue_abs_deviation','red_abs_deviation','blue_new','red_new',
        'blue_train_seconds','red_train_seconds'
    ]
    with outc.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader()
        for row in history:
            w.writerow({k: row[k] for k in fields})
    print('FINAL', json.dumps({
        'meta': final_v, 'gap': abs(final_v-svi), 'blue_pop': len(blue_pop), 'red_pop': len(red_pop),
        'blue_sigma': payload['blue_meta_strategy'], 'red_sigma': payload['red_meta_strategy'],
        'elapsed': payload['elapsed_seconds']
    }), flush=True)

if __name__ == '__main__':
    main()
