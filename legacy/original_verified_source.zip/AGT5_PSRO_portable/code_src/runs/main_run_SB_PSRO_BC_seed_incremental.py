from __future__ import annotations

# Enable direct execution without PYTHONPATH, pip install, or a fixed CWD.
import sys as _sys
from pathlib import Path as _Path
_project_root = _Path(__file__).resolve().parents[2]
for _source in (_project_root / "code_src", _project_root / "code_scenario"):
    if str(_source) not in _sys.path:
        _sys.path.insert(0, str(_source))

import argparse, csv, json, pickle
from dataclasses import asdict
from pathlib import Path
from time import perf_counter

from adversarial_graph_game import PruningMode, solve_ammo_layers
from adversarial_graph_game.matrix_game import solve_zero_sum_matrix_game
from adversarial_graph_game.psro import build_empirical_payoff_matrix, evaluate_policy_pair_exact, make_stay_red_policy
from adversarial_graph_game.psro_ppo import PPOConfig, train_ppo_best_response
from adversarial_graph_game.psro_ppo_relgnn import train_relgnn_blue_best_response
from runs.main_run_SB import SMALL_SCENARIO, build_scenario
from runs.main_run_SB_PSRO_BC_seed import train_static_relgnn_bc_seed, expected_blue_cost, expected_red_cost

STATE=Path('/mnt/data/psro_bc_seed_state.pkl')
OUTJ=Path('/mnt/data/SB_both_support_PSRO_BCSeed_StaticRelGNNBlue_6k_5iter.json')
OUTC=Path('/mnt/data/SB_both_support_PSRO_BCSeed_StaticRelGNNBlue_6k_5iter.csv')
AMMO=1; BLUE_SEED=11; RED_SEED=101
BLUE_CFG=PPOConfig(total_steps=6000,rollout_steps=512,max_episode_steps=32,hidden_size=64,learning_rate=3e-4,update_epochs=4,minibatch_size=128,entropy_coef=.01,entropy_coef_final=None,reward_scale=.01,seed=BLUE_SEED,include_graph_feature=True,include_ammo_feature=True,include_red_reachability_feature=True)
RED_CFG=PPOConfig(total_steps=6000,rollout_steps=512,max_episode_steps=32,hidden_size=64,learning_rate=3e-4,update_epochs=4,minibatch_size=128,entropy_coef=.01,entropy_coef_final=None,reward_scale=.01,seed=RED_SEED,include_graph_feature=True,include_ammo_feature=True,include_red_reachability_feature=True)

def game_and_svi():
    game=build_scenario(SMALL_SCENARIO,max_ammo=AMMO).build_game(with_support=True)
    exact=solve_ammo_layers(game,pruning_mode=PruningMode.NONE,tolerance=1e-9,max_iterations=5000)
    ip=game.canonical_positions(SMALL_SCENARIO.initial_positions)
    return game,float(exact.values[(SMALL_SCENARIO.initial_graph,AMMO)][ip])

def init():
    game,svi=game_and_svi(); red=make_stay_red_policy(game,name='red_stay_seed'); bc,stats=train_static_relgnn_bc_seed(game,red,seed=BLUE_SEED)
    st={'svi':svi,'bc_stats':stats,'blue_pop':[bc],'red_pop':[red],'history':[],'started':perf_counter()}
    STATE.write_bytes(pickle.dumps(st)); print('INIT',{'svi':svi,**stats},flush=True)

def step():
    st=pickle.loads(STATE.read_bytes()); game,svi=game_and_svi(); blue_pop=st['blue_pop']; red_pop=st['red_pop']; k=len(st['history'])+1
    t=perf_counter(); M=build_empirical_payoff_matrix(game,blue_pop,red_pop,initial_graph=SMALL_SCENARIO.initial_graph,initial_ammo=AMMO,initial_positions=SMALL_SCENARIO.initial_positions); print('matrix_s',perf_counter()-t,flush=True)
    sol=solve_zero_sum_matrix_game(M,tolerance=1e-9); v=float(sol.value); print('META',k,v,sol.blue_policy.tolist(),sol.red_policy.tolist(),flush=True)
    bcfg=PPOConfig(**{**asdict(BLUE_CFG),'seed':BLUE_SEED+k-1}); rcfg=PPOConfig(**{**asdict(RED_CFG),'seed':RED_SEED+k-1})
    t=perf_counter(); bpol,bstat,_=train_relgnn_blue_best_response(game,actor_kind='static_relgnn',opponent_population=red_pop,opponent_weights=sol.red_policy,initial_graph=SMALL_SCENARIO.initial_graph,initial_ammo=AMMO,initial_positions=SMALL_SCENARIO.initial_positions,config=bcfg,name=f'blue_static_relgnn_br_{k}',gnn_dim=16); print('blue_train_s',perf_counter()-t,flush=True)
    t=perf_counter(); rpol,rstat=train_ppo_best_response(game,player='red',opponent_population=blue_pop,opponent_weights=sol.blue_policy,initial_graph=SMALL_SCENARIO.initial_graph,initial_ammo=AMMO,initial_positions=SMALL_SCENARIO.initial_positions,config=rcfg,name=f'red_mlp_br_{k}'); print('red_train_s',perf_counter()-t,flush=True)
    t=perf_counter(); bv=expected_blue_cost(game,bpol,red_pop,sol.red_policy); print('blue_eval_s',perf_counter()-t,flush=True)
    t=perf_counter(); rv=expected_red_cost(game,rpol,blue_pop,sol.blue_policy); print('red_eval_s',perf_counter()-t,flush=True)
    bs={p.signature(digits=7) for p in blue_pop}; rs={p.signature(digits=7) for p in red_pop}; bnew=bpol.signature(digits=7) not in bs; rnew=rpol.signature(digits=7) not in rs
    row={'iteration':k,'blue_population_before':len(blue_pop),'red_population_before':len(red_pop),'meta_value':v,'blue_br_value':bv,'red_br_value':rv,'blue_signed_gain':v-bv,'red_signed_gain':rv-v,'blue_abs_deviation':abs(v-bv),'red_abs_deviation':abs(rv-v),'blue_new':bnew,'red_new':rnew,'blue_train_seconds':float(bstat.elapsed_seconds),'red_train_seconds':float(rstat.elapsed_seconds),'blue_meta_strategy':[float(x) for x in sol.blue_policy],'red_meta_strategy':[float(x) for x in sol.red_policy]}
    st['history'].append(row)
    if bnew: st['blue_pop'].append(bpol)
    if rnew: st['red_pop'].append(rpol)
    STATE.write_bytes(pickle.dumps(st)); print('ROW',row,flush=True)

def finalize():
    st=pickle.loads(STATE.read_bytes()); game,svi=game_and_svi(); M=build_empirical_payoff_matrix(game,st['blue_pop'],st['red_pop'],initial_graph=SMALL_SCENARIO.initial_graph,initial_ammo=AMMO,initial_positions=SMALL_SCENARIO.initial_positions); sol=solve_zero_sum_matrix_game(M,tolerance=1e-9); fv=float(sol.value)
    payload={'scenario':SMALL_SCENARIO.name,'support_relations':['3->(1,4)','1->(2,3)'],'experiment':'BC-seeded Blue population only; later Blue BRs random-init Static Rel-GNN PPO','semantics':'vanilla_PSRO_episode_level_opponent_policy_sampling','blue_seed':'Static Rel-GNN BC clone of exact Blue BR vs initial stay-Red','blue_oracle':'Static Rel-GNN actor + MLP critic PPO, random init each BR','red_oracle':'MLP PPO unchanged','ppo_steps_per_oracle':6000,'ppo_update_epochs':4,'entropy':'fixed 0.01','svi_reference_value':svi,'bc_seed_stats':st['bc_stats'],'iterations_run':len(st['history']),'blue_population_size':len(st['blue_pop']),'red_population_size':len(st['red_pop']),'final_meta_value':fv,'absolute_gap_to_svi':abs(fv-svi),'blue_meta_strategy':[float(x) for x in sol.blue_policy],'red_meta_strategy':[float(x) for x in sol.red_policy],'payoff_matrix_red_rows_blue_columns':M.tolist(),'history':st['history']}
    OUTJ.write_text(json.dumps(payload,indent=2)); fields=['iteration','blue_population_before','red_population_before','meta_value','blue_br_value','red_br_value','blue_signed_gain','red_signed_gain','blue_abs_deviation','red_abs_deviation','blue_new','red_new','blue_train_seconds','red_train_seconds'];
    with OUTC.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); [w.writerow({k:r[k] for k in fields}) for r in st['history']]
    print('FINAL',{'meta':fv,'gap':abs(fv-svi),'blue_pop':len(st['blue_pop']),'red_pop':len(st['red_pop']),'blue_sigma':payload['blue_meta_strategy'],'red_sigma':payload['red_meta_strategy']},flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('cmd',choices=['init','step','finalize']); a=ap.parse_args(); globals()[a.cmd]()
