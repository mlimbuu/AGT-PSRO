"""One-cell SB experiment: SVI ground truth vs vanilla PSRO with PPO oracles.

This intentionally reuses SMALL_SCENARIO and the exact game construction from
main_run_SB.py.  It does not run the full ammo/support/pruning benchmark sweep.
"""
from __future__ import annotations

# Enable direct execution without PYTHONPATH, pip install, or a fixed CWD.
import sys as _sys
from pathlib import Path as _Path
_project_root = _Path(__file__).resolve().parents[2]
for _source in (_project_root / "code_src", _project_root / "code_scenario"):
    if str(_source) not in _sys.path:
        _sys.path.insert(0, str(_source))


import csv
import json
from dataclasses import asdict
from pathlib import Path
from time import perf_counter

from adversarial_graph_game import PruningMode
from adversarial_graph_game.psro import (
    exact_blue_best_response_behavioral,
    exact_red_best_response_behavioral,
    make_proper_blue_policy,
    make_stay_red_policy,
)
from adversarial_graph_game.psro_ppo import PPOConfig, run_vanilla_psro_ppo
from runs.main_run_SB import SMALL_SCENARIO, build_scenario, run_once

ROOT = Path(__file__).resolve().parents[1]

# One matched SB cell only.
AMMO = 1
WITH_SUPPORT = True
PSRO_ITERATIONS = 3

# Small CPU validation budget.  Increase total_steps for stronger response
# oracles; the meta-game code itself is not the expensive part here.
BLUE_PPO = PPOConfig(
    total_steps=10_000,
    rollout_steps=512,
    max_episode_steps=32,
    hidden_size=64,
    learning_rate=3e-4,
    update_epochs=4,
    minibatch_size=128,
    entropy_coef=0.01,
    reward_scale=0.01,
    seed=11,
)
RED_PPO = PPOConfig(
    total_steps=10_000,
    rollout_steps=512,
    max_episode_steps=32,
    hidden_size=64,
    learning_rate=3e-4,
    update_epochs=4,
    minibatch_size=128,
    entropy_coef=0.01,
    reward_scale=0.01,
    seed=101,
)


def main() -> None:
    scenario = SMALL_SCENARIO
    game = build_scenario(scenario, max_ammo=AMMO).build_game(
        with_support=WITH_SUPPORT
    )

    # Exact SVI ground truth on the same single cell.
    _, svi_timing, svi_value = run_once(
        game,
        mode=PruningMode.NONE,
        ammo=AMMO,
        initial_graph=scenario.initial_graph,
        initial_positions=scenario.initial_positions,
        solver_config=scenario.solver,
    )
    print(
        f"SVI ground truth: {svi_value:.12f} "
        f"({svi_timing['elapsed_seconds']:.3f}s)",
        flush=True,
    )

    # First-iteration oracle references are exact because the initial opponent
    # population contains only one policy; there is no mixture-semantics issue.
    blue_seed = make_proper_blue_policy(game)
    red_seed = make_stay_red_policy(game)
    exact_blue_br0 = exact_blue_best_response_behavioral(
        game,
        [red_seed],
        [1.0],
        initial_graph=scenario.initial_graph,
        initial_ammo=AMMO,
        initial_positions=scenario.initial_positions,
    ).initial_value
    exact_red_br0 = exact_red_best_response_behavioral(
        game,
        [blue_seed],
        [1.0],
        initial_graph=scenario.initial_graph,
        initial_ammo=AMMO,
        initial_positions=scenario.initial_positions,
    ).initial_value

    started = perf_counter()
    result = run_vanilla_psro_ppo(
        game,
        initial_graph=scenario.initial_graph,
        initial_ammo=AMMO,
        initial_positions=scenario.initial_positions,
        blue_ppo=BLUE_PPO,
        red_ppo=RED_PPO,
        max_iterations=PSRO_ITERATIONS,
        improvement_tolerance=0.05,
        verbose=True,
    )
    elapsed = perf_counter() - started

    print(
        f"Final restricted-game value: {result.meta_value:.12f}\n"
        f"SVI value:                  {svi_value:.12f}\n"
        f"Absolute gap:               {abs(result.meta_value - svi_value):.6f}\n"
        f"PPO-PSRO elapsed:           {elapsed:.3f}s",
        flush=True,
    )

    output_dir = ROOT / "ppo_psro_results"
    output_dir.mkdir(parents=True, exist_ok=True)
    prefix = output_dir / f"SB_ppo_psro_a{AMMO}_{'support' if WITH_SUPPORT else 'no_support'}"

    payload = {
        "scenario": scenario.name,
        "ammo": AMMO,
        "support": WITH_SUPPORT,
        "semantics": result.semantics,
        "svi_ground_truth": float(svi_value),
        "svi_elapsed_seconds": float(svi_timing["elapsed_seconds"]),
        "ppo_psro_elapsed_seconds": float(elapsed),
        "ppo_psro_meta_value": float(result.meta_value),
        "absolute_gap_to_svi": float(abs(result.meta_value - svi_value)),
        "first_iteration_exact_blue_br_value": float(exact_blue_br0),
        "first_iteration_exact_red_br_value": float(exact_red_br0),
        "blue_ppo": asdict(BLUE_PPO),
        "red_ppo": asdict(RED_PPO),
        "blue_population_size": len(result.blue_population),
        "red_population_size": len(result.red_population),
        "blue_meta_strategy": result.blue_meta_strategy.tolist(),
        "red_meta_strategy": result.red_meta_strategy.tolist(),
        "payoff_matrix_red_rows_blue_columns": result.payoff_matrix.tolist(),
        "history": [asdict(item) for item in result.history],
        "blue_oracle_stats": [asdict(item) for item in result.blue_oracle_stats],
        "red_oracle_stats": [asdict(item) for item in result.red_oracle_stats],
    }
    prefix.with_suffix(".json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    with prefix.with_suffix(".csv").open("w", newline="", encoding="utf-8") as stream:
        fields = [
            "iteration",
            "blue_population_size",
            "red_population_size",
            "meta_value",
            "blue_br_value",
            "red_br_value",
            "blue_improvement",
            "red_improvement",
            "oracle_gap",
        ]
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for item in result.history:
            row = asdict(item)
            writer.writerow({field: row[field] for field in fields})


if __name__ == "__main__":
    main()
