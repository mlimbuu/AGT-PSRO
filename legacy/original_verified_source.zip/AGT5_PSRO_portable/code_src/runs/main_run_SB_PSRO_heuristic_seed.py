from __future__ import annotations

# Enable direct execution without PYTHONPATH, pip install, or a fixed CWD.
import sys as _sys
from pathlib import Path as _Path
_project_root = _Path(__file__).resolve().parents[2]
for _source in (_project_root / "code_src", _project_root / "code_scenario"):
    if str(_source) not in _sys.path:
        _sys.path.insert(0, str(_source))

from adversarial_graph_game.compat import strict_zip


import csv, json
from dataclasses import asdict
from pathlib import Path
from time import perf_counter

from adversarial_graph_game import PruningMode, solve_ammo_layers
from adversarial_graph_game.matrix_game import solve_zero_sum_matrix_game
from adversarial_graph_game.psro import (
    build_empirical_payoff_matrix,
    evaluate_policy_pair_exact,
    make_stay_red_policy,
)
from adversarial_graph_game.psro_ppo import PPOConfig, train_ppo_best_response
from adversarial_graph_game.psro_ppo_relgnn import train_relgnn_blue_best_response
from runs.main_run_SB import SMALL_SCENARIO, build_scenario
from runs.main_run_SB_heuristic_security_bounds import build_snapshot_blue_heuristic

ROOT = Path(__file__).resolve().parents[1]
AMMO = 1
MAX_ITER = 5
BLUE_SEED = 11
RED_SEED = 101

BLUE_CFG = PPOConfig(
    total_steps=6000,
    rollout_steps=512,
    max_episode_steps=32,
    hidden_size=64,
    learning_rate=3e-4,
    update_epochs=4,
    minibatch_size=128,
    entropy_coef=0.01,
    entropy_coef_final=None,
    reward_scale=0.01,
    seed=BLUE_SEED,
    include_graph_feature=True,
    include_ammo_feature=True,
    include_red_reachability_feature=True,
)
RED_CFG = PPOConfig(
    total_steps=6000,
    rollout_steps=512,
    max_episode_steps=32,
    hidden_size=64,
    learning_rate=3e-4,
    update_epochs=4,
    minibatch_size=128,
    entropy_coef=0.01,
    entropy_coef_final=None,
    reward_scale=0.01,
    seed=RED_SEED,
    include_graph_feature=True,
    include_ammo_feature=True,
    include_red_reachability_feature=True,
)


def expected_blue_cost(game, blue, red_pop, red_w):
    return float(sum(float(w) * evaluate_policy_pair_exact(
        game, blue, r,
        initial_graph=SMALL_SCENARIO.initial_graph,
        initial_ammo=AMMO,
        initial_positions=SMALL_SCENARIO.initial_positions,
    ) for r, w in strict_zip(red_pop, red_w)))


def expected_red_cost(game, red, blue_pop, blue_w):
    return float(sum(float(w) * evaluate_policy_pair_exact(
        game, b, red,
        initial_graph=SMALL_SCENARIO.initial_graph,
        initial_ammo=AMMO,
        initial_positions=SMALL_SCENARIO.initial_positions,
    ) for b, w in strict_zip(blue_pop, blue_w)))


def main():
    game = build_scenario(SMALL_SCENARIO, max_ammo=AMMO).build_game(with_support=True)
    exact = solve_ammo_layers(game, pruning_mode=PruningMode.NONE, tolerance=1e-9, max_iterations=5000)
    ip = game.canonical_positions(SMALL_SCENARIO.initial_positions)
    svi = float(exact.values[(SMALL_SCENARIO.initial_graph, AMMO)][ip])

    blue_seed, _ = build_snapshot_blue_heuristic(game, name='blue_support_snapshot_shortest_seed')
    red_seed = make_stay_red_policy(game, name='red_stay_seed')
    seed_pair_value = evaluate_policy_pair_exact(
        game, blue_seed, red_seed,
        initial_graph=SMALL_SCENARIO.initial_graph,
        initial_ammo=AMMO,
        initial_positions=SMALL_SCENARIO.initial_positions,
    )
    print(f'SVI={svi:.9f} HEURISTIC_SEED_vs_stay={seed_pair_value:.9f}', flush=True)

    blue_pop = [blue_seed]
    red_pop = [red_seed]
    blue_sigs = {blue_seed.signature(digits=7)}
    red_sigs = {red_seed.signature(digits=7)}
    history = []
    started = perf_counter()

    for k in range(1, MAX_ITER + 1):
        M = build_empirical_payoff_matrix(
            game, blue_pop, red_pop,
            initial_graph=SMALL_SCENARIO.initial_graph,
            initial_ammo=AMMO,
            initial_positions=SMALL_SCENARIO.initial_positions,
        )
        sol = solve_zero_sum_matrix_game(M, tolerance=1e-9)
        v = float(sol.value)

        bcfg = PPOConfig(**{**asdict(BLUE_CFG), 'seed': BLUE_SEED + k - 1})
        rcfg = PPOConfig(**{**asdict(RED_CFG), 'seed': RED_SEED + k - 1})
        bpol, bstat, _ = train_relgnn_blue_best_response(
            game,
            actor_kind='static_relgnn',
            opponent_population=red_pop,
            opponent_weights=sol.red_policy,
            initial_graph=SMALL_SCENARIO.initial_graph,
            initial_ammo=AMMO,
            initial_positions=SMALL_SCENARIO.initial_positions,
            config=bcfg,
            name=f'blue_static_relgnn_br_{k}',
            gnn_dim=16,
        )
        rpol, rstat = train_ppo_best_response(
            game,
            player='red',
            opponent_population=blue_pop,
            opponent_weights=sol.blue_policy,
            initial_graph=SMALL_SCENARIO.initial_graph,
            initial_ammo=AMMO,
            initial_positions=SMALL_SCENARIO.initial_positions,
            config=rcfg,
            name=f'red_mlp_br_{k}',
        )
        bv = expected_blue_cost(game, bpol, red_pop, sol.red_policy)
        rv = expected_red_cost(game, rpol, blue_pop, sol.blue_policy)
        bsig = bpol.signature(digits=7); rsig = rpol.signature(digits=7)
        bnew = bsig not in blue_sigs; rnew = rsig not in red_sigs
        row = {
            'iteration': k,
            'blue_population_before': len(blue_pop),
            'red_population_before': len(red_pop),
            'meta_value': v,
            'blue_br_value': bv,
            'red_br_value': rv,
            'blue_signed_gain': v - bv,
            'red_signed_gain': rv - v,
            'blue_abs_deviation': abs(v - bv),
            'red_abs_deviation': abs(rv - v),
            'blue_new': bnew,
            'red_new': rnew,
            'blue_train_seconds': float(bstat.elapsed_seconds),
            'red_train_seconds': float(rstat.elapsed_seconds),
            'blue_meta_strategy': [float(x) for x in sol.blue_policy],
            'red_meta_strategy': [float(x) for x in sol.red_policy],
        }
        history.append(row)
        print('ITER', k, row, flush=True)
        if bnew:
            blue_pop.append(bpol); blue_sigs.add(bsig)
        if rnew:
            red_pop.append(rpol); red_sigs.add(rsig)

    M = build_empirical_payoff_matrix(
        game, blue_pop, red_pop,
        initial_graph=SMALL_SCENARIO.initial_graph,
        initial_ammo=AMMO,
        initial_positions=SMALL_SCENARIO.initial_positions,
    )
    sol = solve_zero_sum_matrix_game(M, tolerance=1e-9)
    final = {
        'exact_svi': svi,
        'heuristic_seed_vs_initial_red': float(seed_pair_value),
        'final_meta_value': float(sol.value),
        'gap_to_svi': float(sol.value - svi),
        'blue_population_size': len(blue_pop),
        'red_population_size': len(red_pop),
        'blue_meta_strategy': [float(x) for x in sol.blue_policy],
        'red_meta_strategy': [float(x) for x in sol.red_policy],
        'payoff_matrix': M.tolist(),
        'history': history,
        'elapsed_seconds': perf_counter() - started,
        'setup': {
            'blue_initial_policy': 'current-snapshot support-aware joint shortest path; ignores Red transition dynamics and ammo',
            'blue_oracle': 'Static Rel-GNN actor + MLP critic PPO',
            'red_oracle': 'MLP PPO',
            'ppo_steps_per_oracle': 6000,
            'ppo_update_epochs': 4,
            'entropy_coef': 0.01,
            'psro_semantics': 'one whole opponent population policy sampled per episode from current meta-strategy',
        },
    }
    print('FINAL', {k: final[k] for k in ['exact_svi','final_meta_value','gap_to_svi','blue_population_size','red_population_size','blue_meta_strategy','red_meta_strategy']}, flush=True)

    out_csv = ROOT / 'SB_both_support_PSRO_HeuristicSeed_StaticRelGNNBlue_6k_5iter.csv'
    fields = [k for k in history[0].keys() if k not in ('blue_meta_strategy','red_meta_strategy')]
    with out_csv.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader()
        for row in history:
            w.writerow({k: row[k] for k in fields})
    out_json = ROOT / 'SB_both_support_PSRO_HeuristicSeed_StaticRelGNNBlue_6k_5iter.json'
    out_json.write_text(json.dumps(final, indent=2), encoding='utf-8')
    print(out_csv); print(out_json)


if __name__ == '__main__':
    main()
