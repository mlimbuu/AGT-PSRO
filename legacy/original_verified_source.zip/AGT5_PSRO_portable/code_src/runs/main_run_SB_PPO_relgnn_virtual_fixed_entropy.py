from __future__ import annotations

# Enable direct execution without PYTHONPATH, pip install, or a fixed CWD.
import sys as _sys
from pathlib import Path as _Path
_project_root = _Path(__file__).resolve().parents[2]
for _source in (_project_root / "code_src", _project_root / "code_scenario"):
    if str(_source) not in _sys.path:
        _sys.path.insert(0, str(_source))

import csv,json
from pathlib import Path
from statistics import mean,pstdev
from adversarial_graph_game import PruningMode, solve_ammo_layers, tabular_policy_from_ammo_layer_result
from adversarial_graph_game.models import GameState
from adversarial_graph_game.psro import evaluate_policy_pair_exact, TabularPolicy
from adversarial_graph_game.psro_ppo import PPOConfig
from adversarial_graph_game.psro_ppo_relgnn import train_relgnn_blue_best_response
from runs.main_run_SB import SMALL_SCENARIO, build_scenario
ROOT=Path(__file__).resolve().parents[1]; AMMO=1; SEEDS=(11,12,13)
def greedy_snapshot(p):
 m={}
 for s,ap in p.action_probabilities.items():
  if ap:m[s]={max(ap,key=ap.get):1.0}
 return TabularPolicy('blue',m,name=p.name+'_greedy')
def main():
 sc=SMALL_SCENARIO; game=build_scenario(sc,max_ammo=AMMO).build_game(with_support=True)
 er=solve_ammo_layers(game,pruning_mode=PruningMode.NONE,tolerance=1e-9,max_iterations=5000)
 ip=game.canonical_positions(sc.initial_positions); exact=float(er.values[(sc.initial_graph,AMMO)][ip])
 red=tabular_policy_from_ammo_layer_result(game,er,player='red',name='exact_svi_red_both_support')
 print('exact',exact,flush=True); rows=[]
 for seed in SEEDS:
  cfg=PPOConfig(total_steps=10000,rollout_steps=512,max_episode_steps=32,hidden_size=64,learning_rate=3e-4,update_epochs=6,minibatch_size=128,entropy_coef=.01,entropy_coef_final=None,reward_scale=.01,seed=seed,include_graph_feature=True,include_ammo_feature=True,include_red_reachability_feature=True)
  pol,stats,_=train_relgnn_blue_best_response(game,actor_kind='static_relgnn_virtual',opponent_population=[red],opponent_weights=[1.],initial_graph=sc.initial_graph,initial_ammo=AMMO,initial_positions=sc.initial_positions,config=cfg,name=f'virtual_fixed_seed{seed}',gnn_dim=16)
  sv=float(evaluate_policy_pair_exact(game,pol,red,initial_graph=sc.initial_graph,initial_ammo=AMMO,initial_positions=sc.initial_positions)); gv=float(evaluate_policy_pair_exact(game,greedy_snapshot(pol),red,initial_graph=sc.initial_graph,initial_ammo=AMMO,initial_positions=sc.initial_positions)); init=GameState(ip,sc.initial_graph,AMMO); probs=pol.action_probabilities[init]
  row=dict(seed=seed,stochastic_value=sv,greedy_value=gv,p_split_0_2=float(probs.get((0,2),0)),first=str(max(probs,key=probs.get)),elapsed_seconds=float(stats.elapsed_seconds));rows.append(row);print(row,flush=True)
 vals=[r['stochastic_value'] for r in rows]; pp=[r['p_split_0_2'] for r in rows]
 summary=dict(stochastic_mean=mean(vals),stochastic_std=pstdev(vals),stochastic_best=min(vals),greedy_mean=mean([r['greedy_value'] for r in rows]),p_split_mean=mean(pp),p_split_max=max(pp),exact_svi=exact)
 print('SUMMARY',summary,flush=True)
 out=ROOT/'ppo_virtual_results';out.mkdir(exist_ok=True)
 (out/'SB_both_support_relgnn_virtual_fixed_entropy.json').write_text(json.dumps(dict(rows=rows,summary=summary),indent=2))
 with (out/'SB_both_support_relgnn_virtual_fixed_entropy.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
if __name__=='__main__':main()
