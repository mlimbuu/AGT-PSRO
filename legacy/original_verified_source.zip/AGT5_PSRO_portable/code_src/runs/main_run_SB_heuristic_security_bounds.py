from __future__ import annotations

# Enable direct execution without PYTHONPATH, pip install, or a fixed CWD.
import sys as _sys
from pathlib import Path as _Path
_project_root = _Path(__file__).resolve().parents[2]
for _source in (_project_root / "code_src", _project_root / "code_scenario"):
    if str(_source) not in _sys.path:
        _sys.path.insert(0, str(_source))


import csv
import heapq
import json
from dataclasses import asdict
from pathlib import Path
from typing import Dict, Tuple

from adversarial_graph_game import PruningMode, all_position_states, solve_ammo_layers
from adversarial_graph_game.models import GameState, BlueAction
from adversarial_graph_game.psro import (
    TabularPolicy,
    exact_blue_best_response_behavioral,
    exact_red_best_response_behavioral,
    evaluate_policy_pair_exact,
    make_stay_red_policy,
)
from runs.main_run_SB import SMALL_SCENARIO, build_scenario

ROOT = Path(__file__).resolve().parents[1]
AMMO = 1
TOL = 1e-10

PositionState = tuple[int, ...]


def fixed_snapshot_shortest_values(game, graph_id: int) -> dict[PositionState, float]:
    """Exact deterministic team shortest-path values if Red freezes graph_id forever.

    This is deliberately *not* a game solve. It ignores Red graph-transition dynamics
    and ammo. Support, if present in ``game``, is handled by the actual stage-cost
    function, including the supporter-must-wait semantics.
    """
    positions = tuple(all_position_states(game.spec))
    terminal = game.canonical_positions((game.spec.goal_node,) * game.spec.num_blue_agents)

    reverse: dict[PositionState, list[tuple[PositionState, float, BlueAction]]] = {
        p: [] for p in positions
    }

    # Ammo is irrelevant for a frozen graph because stage cost depends only on the
    # current graph/positions/action. Use ammo=0 merely to form a valid state.
    for p in positions:
        state = GameState(p, graph_id, 0)
        if game.is_terminal(state):
            continue
        for action in game.blue_actions(state):
            q = game.canonical_positions(action)
            c = float(game.stage_cost(state, action))
            # Self-loops are harmless for positive waiting costs but are not needed
            # for shortest paths to the absorbing goal.
            if q == p:
                continue
            reverse[q].append((p, c, action))

    dist = {p: float('inf') for p in positions}
    dist[terminal] = 0.0
    pq: list[tuple[float, PositionState]] = [(0.0, terminal)]
    while pq:
        d, q = heapq.heappop(pq)
        if d > dist[q] + 1e-12:
            continue
        for p, c, _ in reverse[q]:
            nd = d + c
            if nd + 1e-12 < dist[p]:
                dist[p] = nd
                heapq.heappush(pq, (nd, p))

    bad = [p for p, d in dist.items() if d == float('inf')]
    if bad:
        raise RuntimeError(f"Frozen-graph heuristic has states that cannot reach goal: {bad[:5]}")
    return dist


def build_snapshot_blue_heuristic(game, *, name: str) -> tuple[TabularPolicy, dict[int, dict[PositionState, float]]]:
    """Current-snapshot shortest-path policy.

    At each state, Blue pretends the current risk snapshot stays fixed forever and
    takes the first joint action of the exact deterministic shortest path under that
    snapshot. It observes current G, positions and support relations, but *ignores*
    Red transition dynamics and ammo when planning.
    """
    frozen = {
        graph_id: fixed_snapshot_shortest_values(game, graph_id)
        for graph_id in game.spec.graph_costs
    }
    mapping = {}
    for ammo in range(game.spec.max_ammo + 1):
        for graph_id in game.spec.graph_costs:
            values = frozen[graph_id]
            for p in all_position_states(game.spec):
                state = GameState(p, graph_id, ammo)
                if game.is_terminal(state):
                    continue
                legal = game.blue_actions(state)
                chosen = min(
                    legal,
                    key=lambda a: (
                        float(game.stage_cost(state, a)) + values[game.canonical_positions(a)],
                        repr(a),
                    ),
                )
                mapping[state] = {chosen: 1.0}
    return TabularPolicy('blue', mapping, name=name), frozen


def build_myopic_red_heuristic(
    game,
    blue_reference: TabularPolicy,
    frozen_values: dict[int, dict[PositionState, float]],
    *,
    name: str,
) -> TabularPolicy:
    """One-step route-attack Red heuristic.

    Red predicts the next Blue joint action using a simple domain Blue reference
    policy, then chooses the *legal* next graph whose frozen-snapshot Blue cost-to-go
    is largest from that predicted next position. This obeys the real Red action
    graph and ammo legality but does not solve future Red dynamics.
    """
    mapping = {}
    for ammo in range(game.spec.max_ammo + 1):
        for graph_id in game.spec.graph_costs:
            for p in all_position_states(game.spec):
                state = GameState(p, graph_id, ammo)
                if game.is_terminal(state):
                    continue
                legal_r = game.red_actions(state)
                b_actions, b_probs = blue_reference.distribution(game, state)
                # Reference policy is deterministic by construction.
                pred_b = b_actions[int(b_probs.argmax())]
                next_p = game.canonical_positions(pred_b)
                chosen = max(
                    legal_r,
                    key=lambda g_next: (
                        frozen_values[g_next][next_p],
                        # Prefer staying on ties to conserve ammo.
                        1 if g_next == graph_id else 0,
                        -int(g_next),
                    ),
                )
                mapping[state] = {chosen: 1.0}
    return TabularPolicy('red', mapping, name=name)


def initial_action(policy: TabularPolicy, game):
    s0 = GameState(
        game.canonical_positions(SMALL_SCENARIO.initial_positions),
        SMALL_SCENARIO.initial_graph,
        AMMO,
    )
    acts, probs = policy.distribution(game, s0)
    return acts[int(probs.argmax())]


def run_case(with_support: bool) -> dict:
    label = 'support' if with_support else 'no_support'
    game = build_scenario(SMALL_SCENARIO, max_ammo=AMMO).build_game(with_support=with_support)
    ip = game.canonical_positions(SMALL_SCENARIO.initial_positions)

    # Full SVI is used only as calibration on this tiny game, not to construct H_B/H_R.
    svi_res = solve_ammo_layers(
        game,
        pruning_mode=PruningMode.NONE,
        tolerance=1e-9,
        max_iterations=5000,
    )
    j_star = float(svi_res.values[(SMALL_SCENARIO.initial_graph, AMMO)][ip])

    blue_h, frozen = build_snapshot_blue_heuristic(
        game,
        name=f'blue_snapshot_shortest_{label}',
    )
    # Simple Red security heuristic: never spend ammo; keep the current risk
    # snapshot. This deliberately ignores graph-transition prediction and ammo
    # planning beyond the fact that a self-loop is always legal.
    red_h = make_stay_red_policy(game, name=f'red_stay_security_{label}')

    # Security upper bound: feasible Blue heuristic vs its exact worst-case Red BR.
    red_br = exact_red_best_response_behavioral(
        game,
        [blue_h], [1.0],
        initial_graph=SMALL_SCENARIO.initial_graph,
        initial_ammo=AMMO,
        initial_positions=SMALL_SCENARIO.initial_positions,
        tolerance=TOL,
        name=f'red_exact_br_to_blue_h_{label}',
    )
    j_high = float(red_br.initial_value)

    # Security lower bound: feasible Red heuristic vs exact best Blue response.
    blue_br = exact_blue_best_response_behavioral(
        game,
        [red_h], [1.0],
        initial_graph=SMALL_SCENARIO.initial_graph,
        initial_ammo=AMMO,
        initial_positions=SMALL_SCENARIO.initial_positions,
        tolerance=TOL,
        name=f'blue_exact_br_to_red_h_{label}',
    )
    j_low = float(blue_br.initial_value)

    pair_h = float(evaluate_policy_pair_exact(
        game, blue_h, red_h,
        initial_graph=SMALL_SCENARIO.initial_graph,
        initial_ammo=AMMO,
        initial_positions=SMALL_SCENARIO.initial_positions,
    ))

    return {
        'case': label,
        'with_support': with_support,
        'J_low': j_low,
        'J_star_SVI': j_star,
        'J_high': j_high,
        'bound_width': j_high - j_low,
        'lower_gap_to_star': j_star - j_low,
        'upper_gap_to_star': j_high - j_star,
        'heuristic_pair_value': pair_h,
        'blue_heuristic_initial_action': repr(initial_action(blue_h, game)),
        'red_heuristic_initial_action': repr(initial_action(red_h, game)),
        'blue_br_to_red_h_initial_value': j_low,
        'red_br_to_blue_h_initial_value': j_high,
        'blue_br_policy_iterations': int(blue_br.policy_iterations),
        'red_br_policy_iterations': int(red_br.policy_iterations),
        'blue_heuristic_name': blue_h.name,
        'red_heuristic_name': red_h.name,
    }


def main():
    rows = [run_case(False), run_case(True)]
    for r in rows:
        assert r['J_low'] <= r['J_star_SVI'] + 1e-7, r
        assert r['J_star_SVI'] <= r['J_high'] + 1e-7, r
        print(
            f"{r['case']:10s}: {r['J_low']:.6f} <= {r['J_star_SVI']:.6f} <= {r['J_high']:.6f} "
            f" width={r['bound_width']:.6f} Hpair={r['heuristic_pair_value']:.6f} "
            f"B0={r['blue_heuristic_initial_action']} R0={r['red_heuristic_initial_action']}",
            flush=True,
        )

    out_csv = ROOT / 'SB_heuristic_security_bounds.csv'
    with out_csv.open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader(); writer.writerows(rows)

    out_json = ROOT / 'SB_heuristic_security_bounds.json'
    out_json.write_text(json.dumps({
        'description': {
            'blue_heuristic': 'Current-snapshot exact team shortest path; ignores Red transition dynamics and ammo; support uses real supporter-must-wait stage cost.',
            'red_heuristic': 'Stay on the current Red graph (self-loop security heuristic); no transition prediction or ammo planning.',
            'bounds': 'J_low = exact Blue BR vs fixed Red heuristic; J_high = exact Red BR vs fixed Blue heuristic. Full SVI is calibration only.',
        },
        'rows': rows,
    }, indent=2), encoding='utf-8')
    print(out_csv)
    print(out_json)


if __name__ == '__main__':
    main()
