''''''''''''''''''''''''''''''''''''''''''''''''
#Name: Jimmy Argenziano
#Assignment: PA 1
#Due Date: 9/14/2026
''''''''''''''''''''''''''''''''''''''''''''''''
#Honor Code Statement: I received no assistance on this assignment that
#violates the ethical guidelines set forth by professor and class syllabus.
''''''''''''''''''''''''''''''''''''''''''''''''
#Comments and Assumptions:N/A
''''''''''''''''''''''''''''''''''''''''''''''''
##############################################
def affordable_products (products, limit):
    result=[]
    for i in range(0, len(products),2):
    #This loop goes from i 0 to the length of the list every two indexes to capture the product name
        name=products [i]
        price = products[i + 1]
#These lists store the current product and its price
        if price <= limit:
            result.append(name)
            result.append(price)
#Compares price to the set limit and if same or lower, it gets appended into the result list
    return result


# products = ['diaper', 12.5, 'flour',5.1, 'apple', 0.2]
# print (affordable_products(products, 5.0))
##############################################
def calculate_prices (prices, selection):
    result=0.0
    for i in range(selection[0],selection[1]+1,selection[2]):
#This loop cycles through the first parameter of the tup to the second +1 to include the last index, on steps of the third tup value
        result+= prices[i]
#adds the values in the range stores in result
    return round(result,2)


# prices = [2.5, 4.49, 12.5, 5.1, 8.99, 9.99, 10.2]
# tup = (0,6,3)
# print(calculate_prices (prices, tup))

##############################################
def most_expensive_tropical_fruit(fruits, prices, tropical_fruits):
    result = None
    highest = None
    for i in range(len(fruits)):
        if fruits[i] in tropical_fruits:
#Checks if the current fruit is in the tropical list before comparing its price
            if highest is None or prices[i] >= highest:
#Compares prices higher or equal to highest so that in a tie, the last fruit replaces the earlier
                highest = prices[i]
                result = fruits[i]
    return result

# fruits = ["apple", "banana", "mango", "kiwi", "papaya"]
# prices = [1.2, 0.5, 2.0, 1.8, 2.5]
# tropical_fruits = ["banana", "mango", "papaya", "pineapple"]
# print(most_expensive_tropical_fruit(fruits, prices, tropical_fruits))

##############################################
def within_budget(products, prices, budget):
    combined = []
    i = 0
    while i < len(products):
 #Combines the two lists into one alternating name/price format
        combined.append(products[i])
        combined.append(prices[i])
        i += 1
    filtered = affordable_products(combined, budget)
#Filters any product with an individual price higher than the budget
    result = []
    total = 0.0
    i = 0
    while i < len(filtered):
        name = filtered[i]
        price = filtered[i + 1]
        if total + price <= budget:
#only adds if it keeps the total within budget
            result.append(name)
            total += price
        i += 2
    return result



# products = ['cheese','milk','diaper','flour', 'apple', 'juice', 'bread']
# prices = [12.5, 14.99, 11.5, 15.1, 8.99, 9.99, 1.5]
# print(within_budget(products, prices, 10.0)) # ['apple']
##############################################
def find_min_diff(products, prices):
    if len(products) < 2:
        return None
#when not enough products to compare
    min_diff = None
    pair = None

    for i in range(len(products)):
        for j in range(i + 1, len(products)):
#compare every unique pair 
            diff = abs(prices[i] - prices[j])
            if min_diff is None or diff < min_diff:
                min_diff = diff
                pair = (products[i], products[j])
#i comes before j to keep original order
    return pair


products = ['cheese', 'milk', 'diaper', 'flour', 'apple', 'juice', 'bread']
prices = [12.5, 14.99, 11.5, 15.1, 18.99, 19.99, 10.5]
print(find_min_diff(products, prices))