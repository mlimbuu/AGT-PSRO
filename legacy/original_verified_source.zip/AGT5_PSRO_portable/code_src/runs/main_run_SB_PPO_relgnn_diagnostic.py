"""Static Rel-GNN vs Action Rel-GNN PPO diagnostic on the support-enabled SB case."""
from __future__ import annotations

# Enable direct execution without PYTHONPATH, pip install, or a fixed CWD.
import sys as _sys
from pathlib import Path as _Path
_project_root = _Path(__file__).resolve().parents[2]
for _source in (_project_root / "code_src", _project_root / "code_scenario"):
    if str(_source) not in _sys.path:
        _sys.path.insert(0, str(_source))


import csv, json
from pathlib import Path
from statistics import mean, pstdev

from adversarial_graph_game.models import GameState
from adversarial_graph_game.psro import (
    TabularPolicy, evaluate_policy_pair_exact, exact_blue_best_response_behavioral,
    make_stay_red_policy,
)
from adversarial_graph_game.psro_ppo import PPOConfig
from adversarial_graph_game.psro_ppo_relgnn import train_relgnn_blue_best_response
from runs.main_run_SB import SMALL_SCENARIO, build_scenario

ROOT = Path(__file__).resolve().parents[1]
AMMO = 1
WITH_SUPPORT = True
SEEDS = (11, 12, 13)
TOTAL_STEPS = 10_000


def greedy_snapshot(policy: TabularPolicy) -> TabularPolicy:
    mapping = {}
    for s, ap in policy.action_probabilities.items():
        a = max(ap, key=ap.get)
        mapping[s] = {a: 1.0}
    return TabularPolicy("blue", mapping, name=f"{policy.name}_greedy")


def greedy_state_trajectory(game, policy, red, scenario, max_steps=16):
    s = GameState(game.canonical_positions(scenario.initial_positions), scenario.initial_graph, AMMO)
    states = [s.blue_positions]
    actions = []
    costs = []
    for _ in range(max_steps):
        if game.is_terminal(s):
            break
        aps = policy.action_probabilities[s]
        a = max(aps, key=aps.get)
        racts, rprobs = red.distribution(game, s)
        r = racts[max(range(len(racts)), key=lambda i:rprobs[i])]
        c = game.stage_cost(s, a)
        actions.append(a); costs.append(float(c))
        s = game.transition(s, a, int(r))
        states.append(s.blue_positions)
    return states, actions, costs


def main():
    scenario = SMALL_SCENARIO
    game = build_scenario(scenario, max_ammo=AMMO).build_game(with_support=WITH_SUPPORT)
    red = make_stay_red_policy(game)
    exact = exact_blue_best_response_behavioral(
        game,[red],[1.0],initial_graph=scenario.initial_graph,
        initial_ammo=AMMO,initial_positions=scenario.initial_positions,
    ).initial_value
    print(f"Exact Blue BR target = {exact:.9f}", flush=True)

    rows=[]
    for kind in ("static_relgnn","action_relgnn"):
        print(f"\n=== {kind} ===", flush=True)
        for seed in SEEDS:
            cfg=PPOConfig(
                total_steps=TOTAL_STEPS, rollout_steps=512, max_episode_steps=32,
                hidden_size=64, learning_rate=3e-4, update_epochs=4,
                minibatch_size=128, entropy_coef=0.01, reward_scale=0.01,
                seed=seed, include_graph_feature=True, include_ammo_feature=True,
                include_red_reachability_feature=True,
            )
            pol,stats,_=train_relgnn_blue_best_response(
                game, actor_kind=kind, opponent_population=[red], opponent_weights=[1.0],
                initial_graph=scenario.initial_graph, initial_ammo=AMMO,
                initial_positions=scenario.initial_positions, config=cfg,
                name=f"{kind}_seed{seed}", gnn_dim=16,
            )
            sv=evaluate_policy_pair_exact(
                game,pol,red,initial_graph=scenario.initial_graph,
                initial_ammo=AMMO,initial_positions=scenario.initial_positions,
            )
            gp=greedy_snapshot(pol)
            gv=evaluate_policy_pair_exact(
                game,gp,red,initial_graph=scenario.initial_graph,
                initial_ammo=AMMO,initial_positions=scenario.initial_positions,
            )
            states,actions,costs=greedy_state_trajectory(game,pol,red,scenario)
            init=GameState(game.canonical_positions(scenario.initial_positions),scenario.initial_graph,AMMO)
            init_probs=pol.action_probabilities[init]
            correct=(0,2)
            row=dict(
                actor=kind,seed=seed,steps=TOTAL_STEPS,
                stochastic_value=float(sv),greedy_value=float(gv),
                stochastic_gap=float(sv-exact),greedy_gap=float(gv-exact),
                p_exact_first_action=float(init_probs.get(correct,0.0)),
                greedy_first_action=str(max(init_probs,key=init_probs.get)),
                greedy_states=str(states),greedy_actions=str(actions),greedy_stage_costs=str(costs),
                elapsed_seconds=float(stats.elapsed_seconds),
            )
            rows.append(row)
            print(
                f"seed={seed} stochastic={sv:.3f} greedy={gv:.3f} "
                f"P((0,2))={row['p_exact_first_action']:.4f} "
                f"first={row['greedy_first_action']} time={stats.elapsed_seconds:.1f}s",
                flush=True,
            )
            print(f"  states: {states} costs={costs}", flush=True)

    summaries=[]
    print("\n=== SUMMARY ===",flush=True)
    for kind in ("static_relgnn","action_relgnn"):
        rr=[r for r in rows if r['actor']==kind]
        sv=[r['stochastic_value'] for r in rr]; gv=[r['greedy_value'] for r in rr]
        pp=[r['p_exact_first_action'] for r in rr]
        ss=dict(actor=kind,n_seeds=len(rr),stochastic_mean=mean(sv),stochastic_std=pstdev(sv),
                stochastic_best=min(sv),greedy_mean=mean(gv),greedy_std=pstdev(gv),
                greedy_best=min(gv),p_exact_first_action_mean=mean(pp),
                p_exact_first_action_max=max(pp))
        summaries.append(ss)
        print(f"{kind:18s} stochastic {ss['stochastic_mean']:.3f}±{ss['stochastic_std']:.3f} "
              f"best={ss['stochastic_best']:.3f} | greedy {ss['greedy_mean']:.3f} "
              f"best={ss['greedy_best']:.3f} | Psplit={ss['p_exact_first_action_mean']:.4f}",flush=True)

    outdir=ROOT/'ppo_relgnn_results';outdir.mkdir(exist_ok=True)
    payload=dict(scenario=scenario.name,ammo=AMMO,support=WITH_SUPPORT,exact_blue_br=float(exact),
                 seeds=list(SEEDS),total_steps=TOTAL_STEPS,
                 note="Action Rel-GNN uses next occupancy + stay occupancy to match current supporter-must-wait timing.",
                 rows=rows,summaries=summaries)
    (outdir/'SB_blue_ppo_relgnn_diagnostic.json').write_text(json.dumps(payload,indent=2),encoding='utf-8')
    with (outdir/'SB_blue_ppo_relgnn_diagnostic.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

if __name__=='__main__': main()
