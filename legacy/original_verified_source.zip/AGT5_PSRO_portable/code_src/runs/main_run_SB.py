from __future__ import annotations

# Enable direct execution without PYTHONPATH, pip install, or a fixed CWD.
import sys as _sys
from pathlib import Path as _Path
_project_root = _Path(__file__).resolve().parents[2]
for _source in (_project_root / "code_src", _project_root / "code_scenario"):
    if str(_source) not in _sys.path:
        _sys.path.insert(0, str(_source))


import csv
import json
import platform
import statistics
import sys
from datetime import datetime
from dataclasses import asdict, dataclass, field, replace
from pathlib import Path
from time import perf_counter
from typing import Any, Iterable, Mapping, Sequence


from adversarial_graph_game import (
    AdversarialGraphBuilder,
    PruningMode,
    all_position_states,
    compare_game_pair,
    max_layer_value_difference,
    solve_ammo_layers,
    write_solver_diagnostics,
    run_vanilla_psro_exact,
)

ROOT = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[2]


# ---------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------

@dataclass(frozen=True)
class TerrainEdge:
    u: int
    v: int
    cost: float


@dataclass(frozen=True)
class RiskEdge:
    u: int
    v: int
    penalty: float


@dataclass(frozen=True)
class AttackConfiguration:
    """One complete snapshot of the risky edges active in a Red graph.

    A Red transition selects the entire next snapshot. One transition may
    therefore activate one edge, several edges, or no new edges.
    """

    configuration_id: int
    risky_edges: tuple[RiskEdge, ...] = ()
    label: str = ""
    display_name: str = ""


@dataclass(frozen=True)
class SupportRelation:
    support_node: int
    risk_u: int
    risk_v: int


@dataclass(frozen=True)
class SolverConfig:
    tolerance: float = 1e-8
    bound_tolerance: float = 1e-8
    max_iterations: int = 5_000


@dataclass(frozen=True)
class BenchmarkConfig:
    name: str
    goal_node: int
    num_blue_agents: int
    initial_positions: tuple[int, ...]
    initial_graph: int

    terrain_edges: tuple[TerrainEdge, ...]
    attack_configurations: tuple[AttackConfiguration, ...]
    red_transitions: Mapping[int, tuple[int, ...]]

    ammo_levels: tuple[int, ...]
    support_relations: tuple[SupportRelation, ...] = ()

    gamma: float = 0.9
    wait_cost: float = 1.0
    active_support_wait_cost: float = 0.01
    use_agent_symmetry: bool = False

    support_options: tuple[bool, ...] = (False, True)
    pruning_modes: tuple[PruningMode, ...] = tuple(PruningMode)

    repetitions: int = 3
    solver: SolverConfig = field(default_factory=SolverConfig)

    # Exhaustive matched-game preflight. This checks that support does not
    # alter actions/transitions or increase any immediate matching cost.
    enable_diagnostics: bool = True
    diagnostic_tolerance: float = 1e-10
    fail_on_diagnostic_violation: bool = True

    def validate(self) -> None:
        if self.num_blue_agents <= 0:
            raise ValueError("num_blue_agents must be positive.")

        if len(self.initial_positions) != self.num_blue_agents:
            raise ValueError(
                "initial_positions must contain exactly "
                f"{self.num_blue_agents} entries."
            )

        if not self.ammo_levels:
            raise ValueError("ammo_levels cannot be empty.")

        if any(ammo < 0 for ammo in self.ammo_levels):
            raise ValueError("ammo levels must be nonnegative.")

        if self.repetitions <= 0:
            raise ValueError("repetitions must be positive.")

        configuration_ids = [
            configuration.configuration_id
            for configuration in self.attack_configurations
        ]
        graph_ids = set(configuration_ids)

        if len(configuration_ids) != len(graph_ids):
            raise ValueError("Attack configuration IDs must be unique.")

        if self.initial_graph not in graph_ids:
            raise ValueError(
                f"initial_graph={self.initial_graph} is not present "
                "in attack_configurations."
            )

        transition_keys = set(self.red_transitions)
        if transition_keys != graph_ids:
            missing = graph_ids - transition_keys
            extra = transition_keys - graph_ids
            raise ValueError(
                "red_transitions must define every graph exactly once. "
                f"Missing={sorted(missing)}, extra={sorted(extra)}."
            )

        for current_graph, next_graphs in self.red_transitions.items():
            if not next_graphs:
                raise ValueError(
                    f"Graph {current_graph} must have at least one successor."
                )
            unknown = set(next_graphs) - graph_ids
            if unknown:
                raise ValueError(
                    f"Graph {current_graph} transitions to unknown graphs "
                    f"{sorted(unknown)}."
                )
            if current_graph not in next_graphs:
                raise ValueError(
                    f"Graph {current_graph} must include its self-loop in "
                    "red_transitions."
                )

        nodes = {
            node
            for edge in self.terrain_edges
            for node in (edge.u, edge.v)
        }

        if self.goal_node not in nodes:
            raise ValueError("goal_node is not present in terrain_edges.")

        missing_positions = set(self.initial_positions) - nodes
        if missing_positions:
            raise ValueError(
                f"Initial positions not in graph: {sorted(missing_positions)}"
            )

        terrain_edge_keys = {
            frozenset((edge.u, edge.v)) for edge in self.terrain_edges
        }
        risky_edge_keys = {
            frozenset((edge.u, edge.v))
            for configuration in self.attack_configurations
            for edge in configuration.risky_edges
        }

        for configuration in self.attack_configurations:
            for edge in configuration.risky_edges:
                if frozenset((edge.u, edge.v)) not in terrain_edge_keys:
                    raise ValueError(
                        f"Risk edge {(edge.u, edge.v)} in graph "
                        f"{configuration.configuration_id} is not a terrain edge."
                    )

        for relation in self.support_relations:
            if relation.support_node not in nodes:
                raise ValueError(
                    f"Support node {relation.support_node} is not in graph."
                )

            relation_edge = frozenset((relation.risk_u, relation.risk_v))
            if relation_edge not in terrain_edge_keys:
                raise ValueError(
                    "Support relation references a non-terrain edge: "
                    f"{(relation.risk_u, relation.risk_v)}."
                )
            if relation_edge not in risky_edge_keys:
                raise ValueError(
                    "Support relation references an edge that is never risky: "
                    f"{(relation.risk_u, relation.risk_v)}."
                )

        # Deliberately do not require every risky edge to have a support
        # relation. A risky edge without one always receives its full penalty.


# ---------------------------------------------------------------------
# Scenario construction
# ---------------------------------------------------------------------

def build_scenario(config: BenchmarkConfig, *, max_ammo: int):
    """
    Construct one scenario for the requested maximum Red ammo level.
    """
    config.validate()

    builder = AdversarialGraphBuilder(
        goal_node=config.goal_node,
        num_blue_agents=config.num_blue_agents,
        max_ammo=max_ammo,
        gamma=config.gamma,
        wait_cost=config.wait_cost,
        active_support_wait_cost=config.active_support_wait_cost,
        indistinguishable_blue_agents=config.use_agent_symmetry,
    )

    builder.add_undirected_edges(
        [(edge.u, edge.v, edge.cost) for edge in config.terrain_edges]
    )

    for attack_configuration in config.attack_configurations:
        risk_mapping = {
            (edge.u, edge.v): edge.penalty
            for edge in attack_configuration.risky_edges
        }
        builder.add_undirected_attack_configuration(
            attack_configuration.configuration_id,
            risk_mapping,
        )

    # Red's action is a graph-to-graph transition. The next graph is a
    # complete risk snapshot, not an individual edge toggle. Every non-self
    # transition consumes one ammo unit in environment.transition().
    for current_graph, next_graphs in config.red_transitions.items():
        for next_graph in next_graphs:
            builder.allow_red_transition(current_graph, next_graph)

    for relation in config.support_relations:
        builder.add_undirected_support_relation(
            relation.support_node,
            relation.risk_u,
            relation.risk_v,
        )

    return builder.build()


# ---------------------------------------------------------------------
# Solver execution
# ---------------------------------------------------------------------

def run_once(
    game,
    *,
    mode: PruningMode,
    ammo: int,
    initial_graph: int,
    initial_positions: tuple[int, ...],
    solver_config: SolverConfig,
):
    wall_clock_started_at = datetime.now().astimezone()
    timer_start = perf_counter()

    result = solve_ammo_layers(
        game,
        pruning_mode=mode,
        tolerance=solver_config.tolerance,
        bound_tolerance=solver_config.bound_tolerance,
        max_iterations=solver_config.max_iterations,
    )

    elapsed_seconds = perf_counter() - timer_start
    wall_clock_finished_at = datetime.now().astimezone()

    layer_key = (initial_graph, ammo)
    if layer_key not in result.values:
        raise KeyError(
            f"Solver result does not contain layer {layer_key}. "
            f"Available layers: {sorted(result.values)}"
        )

    layer_values = result.values[layer_key]
    canonical_initial_positions = game.canonical_positions(initial_positions)
    if canonical_initial_positions not in layer_values:
        raise KeyError(
            f"Initial Blue state {canonical_initial_positions} is not present in "
            f"layer {layer_key}."
        )

    value = layer_values[canonical_initial_positions]

    timing = {
        "started_at": wall_clock_started_at.isoformat(),
        "finished_at": wall_clock_finished_at.isoformat(),
        "elapsed_seconds": elapsed_seconds,
        "elapsed_formatted": format_duration(elapsed_seconds),
    }
    return result, timing, value


def benchmark(
    config: BenchmarkConfig,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    config.validate()
    benchmark_started_at = datetime.now().astimezone()
    benchmark_timer_start = perf_counter()
    rows: list[dict[str, Any]] = []

    for ammo in sorted(set(config.ammo_levels)):
        scenario = build_scenario(config, max_ammo=ammo)

        diagnostic_dir = (
            PROJECT_ROOT
            / "diagnostics"
            / config.name
            / f"ammo_{ammo}"
        )
        if (
            config.enable_diagnostics
            and False in config.support_options
            and True in config.support_options
        ):
            no_support_game, support_game = scenario.build_comparison_pair()
            summary = compare_game_pair(
                no_support_game,
                support_game,
                output_dir=diagnostic_dir / "matched_game_preflight",
                tolerance=config.diagnostic_tolerance,
                fail_on_violation=config.fail_on_diagnostic_violation,
            )
            print(
                "support preflight "
                f"ammo={ammo}: "
                f"passed={summary.passed}, "
                f"cost_increases={summary.support_cost_increases}, "
                f"action_mismatches={summary.action_set_mismatches}, "
                f"transition_mismatches={summary.transition_mismatches}",
                flush=True,
            )

        for with_support in config.support_options:
            game = scenario.build_game(with_support=with_support)

            baseline_result = None

            # Ensure NONE is solved first because other modes are compared
            # against it for value preservation.
            modes = sorted(
                config.pruning_modes,
                key=lambda mode: mode is not PruningMode.NONE,
            )

            for mode in modes:
                times: list[float] = []
                run_timings: list[dict[str, Any]] = []
                final_result = None
                final_value = None

                for repetition in range(config.repetitions):
                    print(
                        f"scenario={config.name} "
                        f"ammo={ammo} "
                        f"support={with_support} "
                        f"mode={mode.value} "
                        f"run={repetition + 1}/{config.repetitions}",
                        flush=True,
                    )

                    final_result, timing, final_value = run_once(
                        game,
                        mode=mode,
                        ammo=ammo,
                        initial_graph=config.initial_graph,
                        initial_positions=config.initial_positions,
                        solver_config=config.solver,
                    )
                    elapsed = float(timing["elapsed_seconds"])
                    times.append(elapsed)
                    run_timings.append(
                        {
                            "repetition": repetition + 1,
                            **timing,
                        }
                    )

                assert final_result is not None
                assert final_value is not None

                if mode is PruningMode.NONE:
                    baseline_result = final_result

                if baseline_result is None:
                    raise RuntimeError(
                        "PruningMode.NONE must be included so that value "
                        "preservation can be evaluated."
                    )

                write_solver_diagnostics(
                    result=final_result,
                    game=game,
                    initial_graph=config.initial_graph,
                    ammo=ammo,
                    initial_positions=config.initial_positions,
                    output_dir=diagnostic_dir / "solver",
                    label=(
                        ("support" if with_support else "no_support")
                        + "_"
                        + mode.value
                    ),
                )

                stats = final_result.pruning_stats
                median_seconds = statistics.median(times)
                mean_seconds = statistics.mean(times)

                retained_position_states = len(
                    all_position_states(game.spec)
                )
                labeled_position_states = len(
                    all_position_states(
                        replace(
                            game.spec,
                            indistinguishable_blue_agents=False,
                        )
                    )
                )

                rows.append(
                    {
                        "scenario": config.name,
                        "nodes": count_nodes(config.terrain_edges),
                        "agents": config.num_blue_agents,
                        "agent_symmetry": (
                            game.spec.indistinguishable_blue_agents
                        ),
                        "position_states": retained_position_states,
                        "labeled_position_states": labeled_position_states,
                        "position_state_reduction_fraction": (
                            1.0 - retained_position_states / labeled_position_states
                        ),
                        "ammo": ammo,
                        "support": with_support,
                        "mode": mode.value,
                        "value": float(final_value),
                        "seconds_median": median_seconds,
                        "seconds_mean": mean_seconds,
                        "seconds_stdev": (
                            statistics.stdev(times)
                            if len(times) > 1
                            else 0.0
                        ),
                        "wall_clock_median": format_duration(median_seconds),
                        "wall_clock_mean": format_duration(mean_seconds),
                        "all_seconds": times,
                        "run_timings": run_timings,
                        "matrix_games": stats.matrix_games_solved,
                        "original_entries": stats.original_matrix_entries,
                        "solved_entries": stats.solved_matrix_entries,
                        "entry_reduction_fraction": (
                            stats.matrix_entry_reduction_fraction
                        ),
                        "bound_blue_removed": (
                            stats.bound_blue_actions_removed
                        ),
                        "bound_red_removed": (
                            stats.bound_red_actions_removed
                        ),
                        "temporary_blue_removed": (
                            stats.temporary_blue_actions_removed
                        ),
                        "temporary_red_removed": (
                            stats.temporary_red_actions_removed
                        ),
                        "max_value_difference": max_layer_value_difference(
                            baseline_result,
                            final_result,
                        ),
                        "iterations_total": sum(
                            final_result.iterations.values()
                        ),
                        "iterations_by_layer": {
                            f"g{graph}_a{layer_ammo}": count
                            for (graph, layer_ammo), count
                            in final_result.iterations.items()
                        },
                    }
                )

    add_derived_metrics(rows)

    benchmark_elapsed_seconds = perf_counter() - benchmark_timer_start
    benchmark_finished_at = datetime.now().astimezone()
    benchmark_timing = {
        "started_at": benchmark_started_at.isoformat(),
        "finished_at": benchmark_finished_at.isoformat(),
        "elapsed_seconds": benchmark_elapsed_seconds,
        "elapsed_formatted": format_duration(benchmark_elapsed_seconds),
    }
    return rows, benchmark_timing


# ---------------------------------------------------------------------
# Derived metrics
# ---------------------------------------------------------------------

def add_derived_metrics(rows: list[dict[str, Any]]) -> None:
    group_keys = {
        (
            str(row["scenario"]),
            int(row["ammo"]),
            bool(row["support"]),
        )
        for row in rows
    }

    for scenario, ammo, support in group_keys:
        group = [
            row
            for row in rows
            if row["scenario"] == scenario
            and row["ammo"] == ammo
            and row["support"] == support
        ]

        baseline = next(
            (row for row in group if row["mode"] == PruningMode.NONE.value),
            None,
        )
        if baseline is None:
            raise ValueError(
                f"No unpruned baseline for scenario={scenario}, "
                f"ammo={ammo}, support={support}."
            )

        baseline_seconds = float(baseline["seconds_median"])

        for row in group:
            row_seconds = float(row["seconds_median"])
            row["speedup_vs_none"] = (
                baseline_seconds / row_seconds
                if row_seconds > 0.0
                else float("inf")
            )

    behavior_keys = {
        (
            str(row["scenario"]),
            bool(row["support"]),
            str(row["mode"]),
        )
        for row in rows
    }

    for scenario, support, mode in behavior_keys:
        group = sorted(
            (
                row
                for row in rows
                if row["scenario"] == scenario
                and row["support"] == support
                and row["mode"] == mode
            ),
            key=lambda row: int(row["ammo"]),
        )

        previous = None
        for row in group:
            if previous is None:
                row["marginal_value_from_previous_ammo"] = None
                row["previous_ammo"] = None
            else:
                row["previous_ammo"] = int(previous["ammo"])
                row["marginal_value_from_previous_ammo"] = (
                    float(row["value"]) - float(previous["value"])
                )
            previous = row


# ---------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------

def write_outputs(
    config: BenchmarkConfig,
    rows: list[dict[str, Any]],
    benchmark_timing: dict[str, Any],
    *,
    output_directory: Path = ROOT,
) -> None:
    output_directory.mkdir(parents=True, exist_ok=True)

    safe_name = sanitize_name(config.name)
    prefix = output_directory / safe_name

    metadata = {
        "python": sys.version,
        "platform": platform.platform(),
        "processor": platform.processor(),
        "repetitions": config.repetitions,
        "timing_summary": (
            f"Median of {config.repetitions} complete solver runs per cell."
        ),
        "benchmark_wall_clock": benchmark_timing,
        "scenario": config_to_json(config),
    }

    prefix.with_suffix(".json").write_text(
        json.dumps(
            {
                "metadata": metadata,
                "results": rows,
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    fields = [
        "scenario",
        "nodes",
        "agents",
        "agent_symmetry",
        "position_states",
        "labeled_position_states",
        "position_state_reduction_fraction",
        "ammo",
        "previous_ammo",
        "support",
        "mode",
        "value",
        "marginal_value_from_previous_ammo",
        "seconds_median",
        "seconds_mean",
        "seconds_stdev",
        "wall_clock_median",
        "wall_clock_mean",
        "speedup_vs_none",
        "matrix_games",
        "original_entries",
        "solved_entries",
        "entry_reduction_fraction",
        "bound_blue_removed",
        "bound_red_removed",
        "temporary_blue_removed",
        "temporary_red_removed",
        "iterations_total",
        "max_value_difference",
    ]

    with prefix.with_suffix(".csv").open(
        "w",
        newline="",
        encoding="utf-8",
    ) as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()

        for row in rows:
            writer.writerow({field: row.get(field) for field in fields})

    prefix.with_suffix(".txt").write_text(
        make_text_report(config, metadata, rows),
        encoding="utf-8",
    )


def make_text_report(
    config: BenchmarkConfig,
    metadata: dict[str, Any],
    rows: list[dict[str, Any]],
) -> str:
    lines = [
        f"Scenario: {config.name}",
        f"Python: {str(metadata['python']).splitlines()[0]}",
        f"Platform: {metadata['platform']}",
        str(metadata["timing_summary"]),
        (
            "Total benchmark wall-clock: "
            f"{metadata['benchmark_wall_clock']['elapsed_formatted']} "
            f"({float(metadata['benchmark_wall_clock']['elapsed_seconds']):.3f} seconds)"
        ),
        f"Started: {metadata['benchmark_wall_clock']['started_at']}",
        f"Finished: {metadata['benchmark_wall_clock']['finished_at']}",
        "",
    ]

    for ammo in sorted(set(config.ammo_levels)):
        lines.append(f"AMMO={ammo}")

        for support in config.support_options:
            lines.append(f"  SUPPORT={support}")
            lines.append(
                "    mode                 value       seconds   speedup  "
                "states       entries         reduction  max_diff"
            )

            matching_rows = [
                row
                for row in rows
                if row["ammo"] == ammo
                and row["support"] == support
            ]

            for row in matching_rows:
                lines.append(
                    f"    {str(row['mode']):20s} "
                    f"{float(row['value']):10.6f}  "
                    f"{float(row['seconds_median']):8.3f}  "
                    f"{float(row['speedup_vs_none']):7.2f}x  "
                    f"{int(row['position_states']):4d}/"
                    f"{int(row['labeled_position_states']):<4d}  "
                    f"{int(row['solved_entries']):8d}/"
                    f"{int(row['original_entries']):<8d} "
                    f"{100.0 * float(row['entry_reduction_fraction']):8.2f}%  "
                    f"{float(row['max_value_difference']):.3e}"
                )

        lines.append("")

    lines.append("VALUE BEHAVIOR: UNPRUNED BASELINE")

    for support in config.support_options:
        baseline_rows = sorted(
            (
                row
                for row in rows
                if row["support"] == support
                and row["mode"] == PruningMode.NONE.value
            ),
            key=lambda row: int(row["ammo"]),
        )

        label = "support" if support else "no_support"
        values = ", ".join(
            f"a{row['ammo']}={float(row['value']):.6f}"
            for row in baseline_rows
        )
        lines.append(f"  {label}: {values}")

        increments = []
        for row in baseline_rows:
            previous_ammo = row["previous_ammo"]
            increment = row["marginal_value_from_previous_ammo"]

            if previous_ammo is not None and increment is not None:
                increments.append(
                    f"a{row['ammo']}-a{previous_ammo}="
                    f"{float(increment):.6f}"
                )

        if increments:
            lines.append("    increments: " + ", ".join(increments))

    return "\n".join(lines)


# ---------------------------------------------------------------------
# Exact-oracle PSRO output
# ---------------------------------------------------------------------

def run_exact_psro_for_scenario(
    config: BenchmarkConfig,
    *,
    ammo: int,
    with_support: bool,
    max_iterations: int = 12,
    oracle_tolerance: float = 1e-8,
):
    """Run the small-game exact-oracle PSRO validation on the SB game.

    The PSRO meta-game is over complete policies.  The current exact oracle
    uses a state-wise behavioral mixture of the opponent population so that
    the best response remains a Markov policy and can be solved exactly.
    The later MARL oracle should use the standard episode-level opponent-policy
    sampling semantics.
    """

    scenario = build_scenario(config, max_ammo=ammo)
    game = scenario.build_game(with_support=with_support)
    started = perf_counter()
    result = run_vanilla_psro_exact(
        game,
        initial_graph=config.initial_graph,
        initial_ammo=ammo,
        initial_positions=config.initial_positions,
        max_iterations=max_iterations,
        oracle_tolerance=oracle_tolerance,
        lp_tolerance=config.solver.tolerance,
        verbose=True,
    )
    elapsed = perf_counter() - started
    return result, elapsed


def write_exact_psro_outputs(
    config: BenchmarkConfig,
    result,
    *,
    ammo: int,
    with_support: bool,
    elapsed_seconds: float,
    svi_ground_truth: float | None = None,
    output_directory: Path = ROOT,
) -> None:
    output_directory.mkdir(parents=True, exist_ok=True)
    suffix = "support" if with_support else "no_support"
    prefix = output_directory / (
        f"{sanitize_name(config.name)}_psro_exact_a{ammo}_{suffix}"
    )

    history = [asdict(item) for item in result.history]
    payload = {
        "scenario": config.name,
        "ammo": ammo,
        "support": with_support,
        "semantics": result.semantics,
        "converged": result.converged,
        "elapsed_seconds": elapsed_seconds,
        "meta_value": result.meta_value,
        "svi_ground_truth": svi_ground_truth,
        "absolute_gap_to_svi": (
            None
            if svi_ground_truth is None
            else abs(result.meta_value - svi_ground_truth)
        ),
        "blue_population_size": len(result.blue_population),
        "red_population_size": len(result.red_population),
        "blue_meta_strategy": result.blue_meta_strategy.tolist(),
        "red_meta_strategy": result.red_meta_strategy.tolist(),
        "payoff_matrix_red_rows_blue_columns": result.payoff_matrix.tolist(),
        "blue_policy_names": [p.name for p in result.blue_population],
        "red_policy_names": [p.name for p in result.red_population],
        "history": history,
    }
    prefix.with_suffix(".json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )

    fields = [
        "iteration",
        "blue_population_size",
        "red_population_size",
        "meta_value",
        "blue_br_value",
        "red_br_value",
        "blue_improvement",
        "red_improvement",
        "oracle_gap",
        "blue_added",
        "red_added",
    ]
    with prefix.with_suffix(".csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in history:
            writer.writerow({field: row.get(field) for field in fields})

    lines = [
        f"Scenario: {config.name}",
        f"Ammo: {ammo}",
        f"Support: {with_support}",
        f"Semantics: {result.semantics}",
        f"Converged: {result.converged}",
        f"PSRO meta value: {result.meta_value:.12f}",
        (
            "SVI ground truth: n/a"
            if svi_ground_truth is None
            else f"SVI ground truth: {svi_ground_truth:.12f}"
        ),
        (
            "Absolute gap to SVI: n/a"
            if svi_ground_truth is None
            else f"Absolute gap to SVI: {abs(result.meta_value - svi_ground_truth):.6e}"
        ),
        f"Blue population: {len(result.blue_population)}",
        f"Red population: {len(result.red_population)}",
        f"Elapsed: {format_duration(elapsed_seconds)}",
        "",
        "iteration  |Pi_B|  |Pi_R|  meta_value       blue_BR          red_BR           oracle_gap",
    ]
    for row in result.history:
        lines.append(
            f"{row.iteration:9d}  "
            f"{row.blue_population_size:6d}  "
            f"{row.red_population_size:6d}  "
            f"{row.meta_value:14.8f}  "
            f"{row.blue_br_value:14.8f}  "
            f"{row.red_br_value:14.8f}  "
            f"{row.oracle_gap:.3e}"
        )
    prefix.with_suffix(".txt").write_text("\n".join(lines), encoding="utf-8")


# ---------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------

def format_duration(seconds: float) -> str:
    """Convert elapsed seconds to HH:MM:SS.mmm."""
    total_milliseconds = round(seconds * 1_000)
    hours, remainder = divmod(total_milliseconds, 3_600_000)
    minutes, remainder = divmod(remainder, 60_000)
    whole_seconds, milliseconds = divmod(remainder, 1_000)
    return (
        f"{hours:02d}:"
        f"{minutes:02d}:"
        f"{whole_seconds:02d}."
        f"{milliseconds:03d}"
    )


def count_nodes(edges: Iterable[TerrainEdge]) -> int:
    return len(
        {
            node
            for edge in edges
            for node in (edge.u, edge.v)
        }
    )


def sanitize_name(name: str) -> str:
    return "".join(
        character.lower()
        if character.isalnum()
        else "_"
        for character in name
    ).strip("_")


def config_to_json(config: BenchmarkConfig) -> dict[str, Any]:
    data = asdict(config)

    # Enum objects are not directly JSON serializable.
    data["pruning_modes"] = [
        mode.value for mode in config.pruning_modes
    ]

    return data


def describe_scenario(config: BenchmarkConfig) -> str:
    """Return a readable summary of risk snapshots and Red transitions."""

    configurations = {
        item.configuration_id: item for item in config.attack_configurations
    }

    def graph_name(graph_id: int) -> str:
        configuration = configurations[graph_id]
        return configuration.display_name or f"G{graph_id}"

    lines = [
        f"Scenario: {config.name}",
        f"Initial graph: {graph_name(config.initial_graph)}",
        "Attack configurations (complete risk snapshots):",
    ]

    for graph_id in sorted(configurations):
        configuration = configurations[graph_id]
        label = f" - {configuration.label}" if configuration.label else ""
        if configuration.risky_edges:
            edges = ", ".join(
                f"{{{edge.u},{edge.v}}}: +{edge.penalty:g}"
                for edge in configuration.risky_edges
            )
        else:
            edges = "no risky edges"
        lines.append(f"  {graph_name(graph_id)}{label}: {edges}")

    lines.append("Allowed Red transitions:")
    for current_graph in sorted(config.red_transitions):
        successors = ", ".join(
            graph_name(next_graph)
            for next_graph in config.red_transitions[current_graph]
        )
        lines.append(f"  {graph_name(current_graph)} -> {successors}")

    lines.append(
        "Support is opportunistic: reduction applies only when a currently "
        "risky edge has a matching support relation and another agent "
        "occupies/holds that support node during the traversal."
    )
    return "\n".join(lines)




G0 = 0
G1 = 1
G2 = 2
G12 = 3


# # 1 ammo, 2 ammo, 3 ammo
# Type 1
SMALL_SCENARIO = BenchmarkConfig(
    name="small_ammo_benchmark",
    goal_node=4,
    num_blue_agents=2,
    initial_positions=(0,0),
    initial_graph=G1,
    terrain_edges=(
        TerrainEdge(0, 1, 10.0),
        TerrainEdge(1, 4, 10.0),
        TerrainEdge(0, 2, 10.0),
        TerrainEdge(2, 3, 10.0),
        TerrainEdge(3, 4, 10.0),
    ),
    attack_configurations=(
        AttackConfiguration(
            configuration_id=G0,
            risky_edges=(),
            label="safe graph",
            display_name="G0",
        ),
        AttackConfiguration(
            configuration_id=G1,
            risky_edges=(
                RiskEdge(1, 4, 200.0),
            ),
            label="edge {1,4} attacked",
            display_name="G1",
        ),
        AttackConfiguration(
            configuration_id=G2,
            risky_edges=(
                RiskEdge(2, 3, 200.0),
                        ),
            label="edge {2,3} attacked",
            display_name="G2",
        ),
        AttackConfiguration(
                configuration_id=G12,
                risky_edges=(
                    RiskEdge(2, 3, 200.0),
                    RiskEdge(1, 4, 200.0),
                            ),
                            
                label="edge {2, 3} & {1, 4} attacked",
                display_name="G12",
                ),

    ),
    # red_transitions={
    #     G1: (G1, G2, G12),
    #     G2: (G2, G12, G12),
    #     G12: (G1, G2, G12,),
    # },
    red_transitions={
        # G0 is not reachable from the selected initial graph in this setup,
        # but every declared attack configuration must have an action entry.
        G0: (G0,),
        G1: (G1, G2,),
        G2: (G2, G12,),
        G12: (G12,),
        },
    support_relations=(
        SupportRelation(
            support_node=3,
            risk_u=1,
            risk_v=4,
        ),
        SupportRelation(
            support_node=1,
            risk_u=2,
            risk_v=3,
        ),
    ),
    ammo_levels=(1,2,3),
    gamma=1 - 1e-9,
    # gamma=1.0,
    wait_cost=1.0,
    # active_support_wait_cost=0.01,
    active_support_wait_cost=1.0,
    repetitions=3,
    use_agent_symmetry=True,
)


# G0 =0
# G1=1
# G2=2
# G3=3

# # # Type II
# SMALL_SCENARIO2 = BenchmarkConfig(
#     name="small_ammo_benchmark",
#     goal_node=4,
#     num_blue_agents=3,
#     initial_positions=(0,0,0),
#     initial_graph=G1,
#     terrain_edges=(
#         TerrainEdge(0, 1, 10.0),
#         TerrainEdge(1, 4, 10.0),
#         TerrainEdge(0, 2, 10.0),
#         TerrainEdge(2, 3, 10.0),
#         TerrainEdge(2, 4, 10.0),
#         TerrainEdge(3, 4, 10.0),
#     ),
#     attack_configurations=(
#         # AttackConfiguration(
#         #     configuration_id=G0,
#         #     risky_edges=(),
#         #     label="safe graph",
#         #     display_name="G0",
#         # ),
#         AttackConfiguration(
#             configuration_id=G1,
#             risky_edges=(
#                 RiskEdge(1, 4, 200.0),
#             ),
#             label="edge {1,4} attacked",
#             display_name="G1",
#         ),
#         AttackConfiguration(
#             configuration_id=G2,
#             risky_edges=(
#                 RiskEdge(2, 3, 200.0),
#                         ),
#             label="edge {2,3} attacked",
#             display_name="G2",
#         ),
#         AttackConfiguration(
#                 configuration_id=G12,
#                 risky_edges=(
#                     RiskEdge(2, 4, 200.0),
#                             ),
                            
#                 label="edge {2,3} & {1, 4} attacked",
#                 display_name="G12",
#                 ),

#     ),
#     ## reversible transitions
#     red_transitions={
#         G1: (G1, G2,G12),
#         G2: (G1, G2,G12),
#         G12: (G1, G2,G12),
#     },

#     ## hybrid (irreversible with stochasticity)
#     # red_transitions={
#     #         G1: (G1, G2,),
#     #         G2: (G2, G12,),
#     #         G12: (G1, G12,),
#     #     },
#     support_relations=(
#         SupportRelation(
#             support_node=3,
#             risk_u=1,
#             risk_v=4,
#         ),
#         # SupportRelation(
#         #     support_node=1,
#         #     risk_u=2,
#         #     risk_v=3,
#         #         ),
#         # SupportRelation(
#         #     support_node=1,
#         #     risk_u=2,
#         #     risk_v=4,
#         #         ),
#     ),
#     ammo_levels=(1,),
#     gamma=1 - 1e-9,
#     # gamma=1.0,
#     wait_cost=1.0,
#     # active_support_wait_cost=0.01,
#     active_support_wait_cost=1.0,
#     repetitions=1,
#     use_agent_symmetry=True,
# )


# # 1, 2, 3 ammo

## Type II
# MEDIUM_SCENARIO = BenchmarkConfig(
#     name="medium_eight_node_cumulative_attacks",
#     goal_node=7,
#     num_blue_agents=2,
#     initial_positions=(0, 0,),
#     initial_graph=G1,
#     terrain_edges=(
#         TerrainEdge(0, 1, 10.0),
#         TerrainEdge(1, 3, 10.0),
#         TerrainEdge(0, 2, 10.0),
#         TerrainEdge(2, 6, 10.0),
#         TerrainEdge(3, 6, 10.0),
#         TerrainEdge(3, 4, 10.0),
#         TerrainEdge(4, 7, 10.0),
#         TerrainEdge(6, 5, 10.0),
#         TerrainEdge(5, 7, 10.0),
#     ),
#     attack_configurations=(
#         # G0: no attack package has been activated.
#         # AttackConfiguration(
#         #     G0,
#         #     label="no active attacks",
#         #     display_name="G0",
#         # ),
#         # G1: attack package 1 activates two risky edges at once.
#         AttackConfiguration(
#             G1,
#             (
#                 RiskEdge(1, 3, 200.0),
#             ),
#             label="attack package 1 active",
#             display_name="G1",
#         ),
#         # G2: attack package 2 activates the lower-route edge.
#         AttackConfiguration(
#             G2,
#             (
#                 RiskEdge(6, 5, 200.0),
#             ),
#             label="attack package 2 active",
#             display_name="G2",
#         ),
#         AttackConfiguration(
#                     G3,
#                     (
#                         RiskEdge(4, 7, 200.0),
#                     ),
#                     label="attack package 3 active",
#                     display_name="G3",
#                 ),
#     ),
#     # Internal graph ID 3 represents G12. Attacks accumulate and cannot be
#     # removed. A non-self transition costs one ammo, regardless of how many
#     # edges are included in the selected attack package.
#     red_transitions={
#         G1: (G1, G2, G3),   # stay, activate package 1, or activate package 2
#         G2: (G1, G2, G3),
#         G3: (G1, G2, G3),            # stay or activate package 2 as well
#     },
#     support_relations=(
#     #     SupportRelation(
#     #         support_node=2,
#     #         risk_u=1,
#     #         risk_v=3,
#     #     ),
#         # SupportRelation(
#         #     support_node=3,
#         #     risk_u=6,
#         #     risk_v=5,
#         #         ),
#          SupportRelation(
#                     support_node=5,
#                     risk_u=4,
#                     risk_v=7,
#                         ),
#     ),
#     ammo_levels=(1,2,3),
#     gamma=0.99,
#     repetitions=3,
#     use_agent_symmetry=True,
# )

# ## Type I
# MEDIUM_SCENARIO = BenchmarkConfig(
#     name="medium_eight_node_cumulative_attacks",
#     goal_node=7,
#     num_blue_agents=2,
#     initial_positions=(0, 0,),
#     initial_graph=G1,
#     terrain_edges=(
#         TerrainEdge(0, 1, 10.0),
#         TerrainEdge(1, 3, 10.0),
#         TerrainEdge(0, 2, 10.0),
#         TerrainEdge(2, 6, 10.0),
#         TerrainEdge(3, 6, 10.0),
#         TerrainEdge(3, 4, 10.0),
#         TerrainEdge(4, 7, 10.0),
#         TerrainEdge(6, 5, 10.0),
#         TerrainEdge(5, 7, 10.0),
#     ),
#     attack_configurations=(
#         # G0: no attack package has been activated.
#         # AttackConfiguration(
#         #     G0,
#         #     label="no active attacks",
#         #     display_name="G0",
#         # ),
#         # G1: attack package 1 activates two risky edges at once.
#         AttackConfiguration(
#             G1,
#             (
#                 RiskEdge(1, 3, 200.0),
#             ),
#             label="attack package 1 active",
#             display_name="G1",
#         ),
#         # G2: attack package 2 activates the lower-route edge.
#         AttackConfiguration(
#             G2,
#             (
#                 RiskEdge(6, 5, 200.0),
#             ),
#             label="attack package 2 active",
#             display_name="G2",
#         ),
#         AttackConfiguration(
#                     G12,
#                     (
#                         RiskEdge(4, 7, 200.0),
#                          RiskEdge(6, 5, 200.0),
#                     ),
#                     label="attack package 3 active",
#                     display_name="G12",
#                 ),

#     ),
#     # Internal graph ID 3 represents G12. Attacks accumulate and cannot be
#     # removed. A non-self transition costs one ammo, regardless of how many
#     # edges are included in the selected attack package.
#     red_transitions={
#         G1: (G1, G2,),   # stay, activate package 1, or activate package 2
#         G2: (G2, G12),
#         G12: (G12,),            # stay or activate package 2 as well
        
#     },
#     support_relations=(
#         SupportRelation(
#             support_node=2,
#             risk_u=1,
#             risk_v=3,
#         ),
#         SupportRelation(
#             support_node=3,
#             risk_u=6,
#             risk_v=5,
#                 ),
#          SupportRelation(
#                     support_node=5,
#                     risk_u=4,
#                     risk_v=7,
#                         ),
#     ),
#     ammo_levels=(1,2,3),
#     gamma=0.99,
#     # gamma=1 - 1e-9,
#     repetitions=3,
#     use_agent_symmetry=True,
# )


if __name__ == "__main__":
    # Select the experiment here.
    base_scenario = SMALL_SCENARIO

    print(describe_scenario(base_scenario), flush=True)
    print("Available pruning modes:", PruningMode.__members__)

    # --------------------------------------------------------------
    # Execution switches
    # --------------------------------------------------------------
    RUN_SVI_BENCHMARK = True
    RUN_EXACT_PSRO = True

    ACTIVE_PRUNING_MODES = (
        PruningMode.NONE,
        # PruningMode.BOUND_CERTIFIED,
        # PruningMode.TEMPORARY_STRICT,
        # PruningMode.HYBRID,
    )

    # The first PSRO validation should be small. Change these independently
    # from the SVI benchmark sweep.
    PSRO_AMMO = min(base_scenario.ammo_levels)
    PSRO_WITH_SUPPORT = True
    PSRO_MAX_ITERATIONS = 12
    PSRO_ORACLE_TOLERANCE = 1e-8

    scenario = replace(
        base_scenario,
        pruning_modes=ACTIVE_PRUNING_MODES,
    )

    rows: list[dict[str, Any]] = []
    if RUN_SVI_BENCHMARK:
        rows, benchmark_timing = benchmark(scenario)
        write_outputs(scenario, rows, benchmark_timing)
        print(
            "benchmark complete: "
            f"{benchmark_timing['elapsed_formatted']} "
            f"({benchmark_timing['elapsed_seconds']:.3f} seconds)",
            flush=True,
        )

    if RUN_EXACT_PSRO:
        svi_ground_truth = None
        if rows:
            matches = [
                row
                for row in rows
                if row["ammo"] == PSRO_AMMO
                and row["support"] == PSRO_WITH_SUPPORT
                and row["mode"] == PruningMode.NONE.value
            ]
            if matches:
                svi_ground_truth = float(matches[0]["value"])

        print(
            "\nStarting exact-oracle PSRO validation "
            f"(ammo={PSRO_AMMO}, support={PSRO_WITH_SUPPORT})",
            flush=True,
        )
        psro_result, psro_elapsed = run_exact_psro_for_scenario(
            scenario,
            ammo=PSRO_AMMO,
            with_support=PSRO_WITH_SUPPORT,
            max_iterations=PSRO_MAX_ITERATIONS,
            oracle_tolerance=PSRO_ORACLE_TOLERANCE,
        )
        write_exact_psro_outputs(
            scenario,
            psro_result,
            ammo=PSRO_AMMO,
            with_support=PSRO_WITH_SUPPORT,
            elapsed_seconds=psro_elapsed,
            svi_ground_truth=svi_ground_truth,
        )
        print(
            "PSRO complete: "
            f"meta_value={psro_result.meta_value:.9f}, "
            f"|Pi_B|={len(psro_result.blue_population)}, "
            f"|Pi_R|={len(psro_result.red_population)}, "
            f"converged={psro_result.converged}, "
            f"elapsed={format_duration(psro_elapsed)}",
            flush=True,
        )
        if svi_ground_truth is not None:
            print(
                "PSRO vs SVI: "
                f"SVI={svi_ground_truth:.9f}, "
                f"abs_gap={abs(psro_result.meta_value - svi_ground_truth):.3e}",
                flush=True,
            )

