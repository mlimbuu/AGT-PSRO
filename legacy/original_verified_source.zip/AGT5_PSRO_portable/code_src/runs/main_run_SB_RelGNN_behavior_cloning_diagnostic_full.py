"""Behavior-cloning diagnostic for Static and Action-conditioned Rel-GNN Blue actors.

Purpose: test representational capacity only.  Exact DP Blue best response against
fixed stay-Red supplies supervised state -> legal joint-action labels.  We train
the same Rel-GNN actor classes used by PPO and evaluate their GREEDY cloned
policies exactly against Red.
"""
from __future__ import annotations

# Enable direct execution without PYTHONPATH, pip install, or a fixed CWD.
import sys as _sys
from pathlib import Path as _Path
_project_root = _Path(__file__).resolve().parents[2]
for _source in (_project_root / "code_src", _project_root / "code_scenario"):
    if str(_source) not in _sys.path:
        _sys.path.insert(0, str(_source))

from adversarial_graph_game.compat import dataclass, strict_zip


import argparse
import json
import random
from dataclasses import asdict
from pathlib import Path
from time import perf_counter

import numpy as np
import torch
from torch import nn
from torch.distributions import Categorical

from adversarial_graph_game.models import GameState
from adversarial_graph_game.psro import (
    TabularPolicy,
    evaluate_policy_pair_exact,
    exact_blue_best_response_behavioral,
    make_stay_red_policy,
)
from adversarial_graph_game.psro_ppo import PPOConfig
from adversarial_graph_game.psro_ppo_relgnn import (
    RelationalGraphBuilder,
    StaticRelGNNActor,
    ActionRelGNNActor,
)
from runs.main_run_SB import SMALL_SCENARIO, build_scenario

ROOT = Path(__file__).resolve().parents[1]
AMMO = 1
WITH_SUPPORT = True
SEEDS = (11, 12, 13)
MAX_EPOCHS = 400
LR = 3e-3
BATCH_STATES = 16
GNN_DIM = 16


@dataclass(slots=True)
class Result:
    actor_kind: str
    seed: int
    epochs: int
    train_accuracy: float
    loss: float
    greedy_cost: float
    gap_to_exact: float
    initial_teacher_action: tuple[int, ...]
    initial_clone_action: tuple[int, ...]
    initial_clone_probability: float
    elapsed_seconds: float


def teacher_action(policy: TabularPolicy, state: GameState):
    probs = policy.action_probabilities[state]
    return max(probs, key=probs.get)


def build_greedy_policy(game, actor, states, name: str) -> tuple[TabularPolicy, dict]:
    mapping = {}
    stochastic = {}
    actor.eval()
    with torch.no_grad():
        for state in states:
            legal = game.blue_actions(state)
            logits = actor.logits(state, legal)
            probs = torch.softmax(logits, dim=-1).cpu().numpy()
            stochastic[state] = {a: float(p) for a, p in strict_zip(legal, probs)}
            chosen = legal[int(np.argmax(probs))]
            mapping[state] = {chosen: 1.0}
    return TabularPolicy("blue", mapping, name=name), stochastic


def trajectory(game, blue_policy: TabularPolicy, red_policy: TabularPolicy):
    state = GameState(
        game.canonical_positions(SMALL_SCENARIO.initial_positions),
        SMALL_SCENARIO.initial_graph,
        AMMO,
    )
    rows = []
    total = 0.0
    for t in range(32):
        if game.is_terminal(state):
            break
        b = teacher_action(blue_policy, state)
        ra, rp = red_policy.distribution(game, state)
        r = ra[int(np.argmax(rp))]
        stage = float(game.stage_cost(state, b))
        nxt = game.transition(state, b, int(r))
        rows.append({
            "t": t,
            "state": list(state.blue_positions),
            "blue_action": list(b),
            "red_action": int(r),
            "stage_cost": stage,
            "next_state": list(nxt.blue_positions),
        })
        total += stage
        state = nxt
    return rows, total


def train_one(kind: str, seed: int, game, teacher, exact_value: float, states, max_epochs: int = MAX_EPOCHS):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed); torch.set_num_threads(1)
    cfg = PPOConfig(
        include_graph_feature=True,
        include_ammo_feature=True,
        include_red_reachability_feature=True,
    )
    graph = RelationalGraphBuilder(game, cfg)
    actor = StaticRelGNNActor(graph, d=GNN_DIM) if kind == "static_relgnn" else ActionRelGNNActor(graph, d=GNN_DIM)
    opt = torch.optim.Adam(actor.parameters(), lr=LR)

    examples = []
    for s in states:
        legal = game.blue_actions(s)
        ta = teacher_action(teacher, s)
        try:
            label = legal.index(ta)
        except ValueError as e:
            raise RuntimeError(f"teacher action {ta} not in legal actions for {s}") from e
        examples.append((s, legal, label))

    started = perf_counter()
    final_loss = float("nan")
    final_acc = 0.0
    epoch = 0
    for epoch in range(1, max_epochs + 1):
        random.shuffle(examples)
        actor.train()
        epoch_losses = []
        opt.zero_grad()
        pending = 0
        for idx, (s, legal, label) in enumerate(examples, start=1):
            logits = actor.logits(s, legal)
            target = torch.tensor([label], dtype=torch.long)
            loss = nn.functional.cross_entropy(logits.unsqueeze(0), target)
            # Average gradients over state minibatch.
            (loss / BATCH_STATES).backward()
            epoch_losses.append(float(loss.detach().item()))
            pending += 1
            if pending == BATCH_STATES or idx == len(examples):
                nn.utils.clip_grad_norm_(actor.parameters(), 1.0)
                opt.step(); opt.zero_grad(); pending = 0

        if epoch % 10 == 0 or epoch == max_epochs:
            actor.eval()
            correct = 0
            losses = []
            with torch.no_grad():
                for s, legal, label in examples:
                    logits = actor.logits(s, legal)
                    losses.append(float(nn.functional.cross_entropy(logits.unsqueeze(0), torch.tensor([label])).item()))
                    correct += int(int(torch.argmax(logits).item()) == label)
            final_acc = correct / len(examples)
            final_loss = float(np.mean(losses))
            if final_acc == 1.0 and final_loss < 1e-3:
                break

    elapsed = perf_counter() - started
    clone, stochastic = build_greedy_policy(game, actor, states, f"BC_{kind}_seed{seed}")
    red = make_stay_red_policy(game)
    value = float(evaluate_policy_pair_exact(
        game, clone, red,
        initial_graph=SMALL_SCENARIO.initial_graph,
        initial_ammo=AMMO,
        initial_positions=SMALL_SCENARIO.initial_positions,
    ))
    init = GameState(game.canonical_positions(SMALL_SCENARIO.initial_positions), SMALL_SCENARIO.initial_graph, AMMO)
    teach0 = teacher_action(teacher, init)
    probs0 = stochastic[init]
    clone0 = max(probs0, key=probs0.get)
    p0 = float(probs0[clone0])
    result = Result(
        actor_kind=kind, seed=seed, epochs=epoch,
        train_accuracy=final_acc, loss=final_loss,
        greedy_cost=value, gap_to_exact=value-exact_value,
        initial_teacher_action=tuple(teach0),
        initial_clone_action=tuple(clone0),
        initial_clone_probability=p0,
        elapsed_seconds=elapsed,
    )
    return result, clone, actor


def main(seeds=SEEDS, max_epochs=MAX_EPOCHS, outdir=None):
    game = build_scenario(SMALL_SCENARIO, max_ammo=AMMO).build_game(with_support=WITH_SUPPORT)
    red = make_stay_red_policy(game)
    exact = exact_blue_best_response_behavioral(
        game, [red], [1.0],
        initial_graph=SMALL_SCENARIO.initial_graph,
        initial_ammo=AMMO,
        initial_positions=SMALL_SCENARIO.initial_positions,
    )
    teacher = exact.policy
    exact_value = float(exact.initial_value)
    states = sorted(
        [s for s in teacher.action_probabilities if not game.is_terminal(s)],
        key=lambda s: (s.red_ammo, s.graph_id, s.blue_positions),
    )
    init = GameState(game.canonical_positions(SMALL_SCENARIO.initial_positions), SMALL_SCENARIO.initial_graph, AMMO)
    print(f"Exact DP BR value: {exact_value:.9f}")
    print(f"Teacher states: {len(states)}")
    print(f"Exact initial action: {teacher_action(teacher, init)}")

    results = []
    best_by_kind = {}
    for kind in ("static_relgnn", "action_relgnn"):
        print(f"\n=== {kind} ===")
        best = None
        for seed in seeds:
            res, clone, actor = train_one(kind, seed, game, teacher, exact_value, states, max_epochs=max_epochs)
            results.append(res)
            if best is None or res.greedy_cost < best[0].greedy_cost or (res.greedy_cost == best[0].greedy_cost and res.train_accuracy > best[0].train_accuracy):
                best = (res, clone)
            print(
                f"seed={seed} ep={res.epochs:3d} acc={res.train_accuracy:.4f} "
                f"loss={res.loss:.6f} greedy={res.greedy_cost:.6f} gap={res.gap_to_exact:+.6f} "
                f"init={res.initial_clone_action} p={res.initial_clone_probability:.4f} time={res.elapsed_seconds:.1f}s"
            )
        best_by_kind[kind] = best

    teacher_traj, teacher_total = trajectory(game, teacher, red)
    print("\nExact teacher trajectory:")
    for row in teacher_traj:
        print(f"  {tuple(row['state'])} -> {tuple(row['next_state'])} via {tuple(row['blue_action'])}, cost={row['stage_cost']:.1f}")
    print(f"  total={teacher_total:.1f}")

    traj_payload = {"exact": teacher_traj}
    for kind, (res, clone) in best_by_kind.items():
        tr, total = trajectory(game, clone, red)
        traj_payload[kind] = tr
        print(f"\nBest {kind} BC trajectory:")
        for row in tr:
            print(f"  {tuple(row['state'])} -> {tuple(row['next_state'])} via {tuple(row['blue_action'])}, cost={row['stage_cost']:.1f}")
        print(f"  total={total:.1f}")

    outdir = Path(outdir) if outdir is not None else ROOT / "ppo_ablation_results"
    outdir.mkdir(exist_ok=True)
    payload = {
        "scenario": SMALL_SCENARIO.name,
        "ammo": AMMO,
        "support": WITH_SUPPORT,
        "purpose": "diagnostic only: Rel-GNN representational capacity via exact-DP behavior cloning",
        "exact_blue_br": exact_value,
        "teacher_states": len(states),
        "gnn_dim": GNN_DIM,
        "max_epochs": max_epochs,
        "learning_rate": LR,
        "results": [asdict(r) for r in results],
        "trajectories": traj_payload,
    }
    path = outdir / "SB_blue_relgnn_behavior_cloning_diagnostic.json"
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(f"\nSaved {path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="DP teacher vs Rel-GNN behavior cloning diagnostic")
    parser.add_argument("--seeds", type=int, nargs="+", default=list(SEEDS))
    parser.add_argument("--epochs", type=int, default=MAX_EPOCHS)
    parser.add_argument("--out-dir", type=Path, default=None)
    args = parser.parse_args()
    if args.epochs < 1:
        parser.error("--epochs must be at least one")
    main(seeds=args.seeds, max_epochs=args.epochs, outdir=args.out_dir)
