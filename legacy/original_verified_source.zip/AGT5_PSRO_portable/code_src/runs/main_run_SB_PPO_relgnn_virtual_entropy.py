"""Both-support SB: Static Rel-GNN vs Static Rel-GNN + virtual node.

Controlled change: both use linear entropy decay 0.1 -> 0.0, same MLP critic,
10k PPO steps, 6 epochs, seeds 11/12/13. Opponent is the exact SVI Red
equilibrium policy of the both-support game.
"""
from __future__ import annotations

# Enable direct execution without PYTHONPATH, pip install, or a fixed CWD.
import sys as _sys
from pathlib import Path as _Path
_project_root = _Path(__file__).resolve().parents[2]
for _source in (_project_root / "code_src", _project_root / "code_scenario"):
    if str(_source) not in _sys.path:
        _sys.path.insert(0, str(_source))


import csv, json
from pathlib import Path
from statistics import mean, pstdev

from adversarial_graph_game import PruningMode, solve_ammo_layers, tabular_policy_from_ammo_layer_result
from adversarial_graph_game.models import GameState
from adversarial_graph_game.psro import evaluate_policy_pair_exact, TabularPolicy
from adversarial_graph_game.psro_ppo import PPOConfig
from adversarial_graph_game.psro_ppo_relgnn import train_relgnn_blue_best_response
from runs.main_run_SB import SMALL_SCENARIO, build_scenario

ROOT = Path(__file__).resolve().parents[1]
AMMO=1
SEEDS=(11,12,13)
TOTAL_STEPS=10_000
UPDATE_EPOCHS=6


def greedy_snapshot(policy: TabularPolicy) -> TabularPolicy:
    mapping={}
    for s,ap in policy.action_probabilities.items():
        if not ap: continue
        a=max(ap,key=ap.get)
        mapping[s]={a:1.0}
    return TabularPolicy('blue',mapping,name=f'{policy.name}_greedy')


def greedy_trajectory(game, policy, red, scenario, max_steps=32):
    s=GameState(game.canonical_positions(scenario.initial_positions),scenario.initial_graph,AMMO)
    states=[s.blue_positions]; actions=[]; costs=[]
    for _ in range(max_steps):
        if game.is_terminal(s): break
        a=max(policy.action_probabilities[s],key=policy.action_probabilities[s].get)
        racts,rprobs=red.distribution(game,s)
        r=racts[max(range(len(racts)), key=lambda i:rprobs[i])]
        c=float(game.stage_cost(s,a))
        actions.append(a); costs.append(c)
        s=game.transition(s,a,int(r)); states.append(s.blue_positions)
    return states,actions,costs


def main():
    scenario=SMALL_SCENARIO
    print('support relations:', scenario.support_relations, flush=True)
    gs=build_scenario(scenario,max_ammo=AMMO)
    game=gs.build_game(with_support=True)

    exact_res=solve_ammo_layers(game, pruning_mode=PruningMode.NONE, tolerance=1e-9, max_iterations=5000)
    init_pos=game.canonical_positions(scenario.initial_positions)
    exact=float(exact_res.values[(scenario.initial_graph,AMMO)][init_pos])
    red=tabular_policy_from_ammo_layer_result(game,exact_res,player='red',name='exact_svi_red_both_support')
    print(f'Exact SVI value = {exact:.9f}',flush=True)

    conditions=[
        ('static_relgnn_decay01to0','static_relgnn'),
        ('static_relgnn_virtual_decay01to0','static_relgnn_virtual'),
    ]
    rows=[]
    for label,kind in conditions:
        print(f'\n=== {label} ===',flush=True)
        for seed in SEEDS:
            cfg=PPOConfig(
                total_steps=TOTAL_STEPS, rollout_steps=512,max_episode_steps=32,
                hidden_size=64, learning_rate=3e-4, update_epochs=UPDATE_EPOCHS,
                minibatch_size=128, entropy_coef=0.1, entropy_coef_final=0.0,
                reward_scale=0.01, seed=seed,
                include_graph_feature=True,include_ammo_feature=True,
                include_red_reachability_feature=True,
            )
            pol,stats,_=train_relgnn_blue_best_response(
                game,actor_kind=kind,opponent_population=[red],opponent_weights=[1.0],
                initial_graph=scenario.initial_graph,initial_ammo=AMMO,
                initial_positions=scenario.initial_positions,config=cfg,
                name=f'{label}_seed{seed}',gnn_dim=16,
            )
            sv=float(evaluate_policy_pair_exact(game,pol,red,initial_graph=scenario.initial_graph,initial_ammo=AMMO,initial_positions=scenario.initial_positions))
            gp=greedy_snapshot(pol)
            gv=float(evaluate_policy_pair_exact(game,gp,red,initial_graph=scenario.initial_graph,initial_ammo=AMMO,initial_positions=scenario.initial_positions))
            init=GameState(init_pos,scenario.initial_graph,AMMO)
            probs=pol.action_probabilities[init]
            first=max(probs,key=probs.get)
            states,actions,costs=greedy_trajectory(game,pol,red,scenario)
            row=dict(
                condition=label, actor=kind, critic='mlp', seed=seed,
                total_steps=TOTAL_STEPS,update_epochs=UPDATE_EPOCHS,
                entropy_start=0.1,entropy_final=0.0,
                exact_svi=exact,stochastic_value=sv,greedy_value=gv,
                stochastic_gap=sv-exact,greedy_gap=gv-exact,
                p_split_0_2=float(probs.get((0,2),0.0)),
                greedy_first_action=str(first),greedy_states=str(states),
                greedy_actions=str(actions),greedy_stage_costs=str(costs),
                elapsed_seconds=float(stats.elapsed_seconds),
            )
            rows.append(row)
            print(f'seed={seed} stochastic={sv:.4f} greedy={gv:.4f} Psplit={row["p_split_0_2"]:.4f} first={first} time={stats.elapsed_seconds:.1f}s',flush=True)
            print(' states',states,'costs',costs,flush=True)

    summaries=[]
    print('\n=== SUMMARY ===',flush=True)
    for label,_ in conditions:
        rr=[r for r in rows if r['condition']==label]
        vals=[r['stochastic_value'] for r in rr]; gre=[r['greedy_value'] for r in rr]; pp=[r['p_split_0_2'] for r in rr]; times=[r['elapsed_seconds'] for r in rr]
        ss=dict(condition=label,n_seeds=len(rr),stochastic_mean=mean(vals),stochastic_std=pstdev(vals),stochastic_best=min(vals),greedy_mean=mean(gre),greedy_std=pstdev(gre),greedy_best=min(gre),p_split_mean=mean(pp),p_split_max=max(pp),elapsed_mean=mean(times))
        summaries.append(ss)
        print(label,ss,flush=True)

    out=ROOT/'ppo_virtual_results'; out.mkdir(exist_ok=True)
    payload=dict(scenario=scenario.name,support_relations=[str(x) for x in scenario.support_relations],ammo=AMMO,exact_svi=exact,seeds=list(SEEDS),total_steps=TOTAL_STEPS,update_epochs=UPDATE_EPOCHS,entropy_schedule=[0.1,0.0],opponent='exact SVI Red equilibrium policy',rows=rows,summaries=summaries)
    (out/'SB_both_support_relgnn_virtual_entropy_decay.json').write_text(json.dumps(payload,indent=2),encoding='utf-8')
    with (out/'SB_both_support_relgnn_virtual_entropy_decay.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

if __name__=='__main__': main()
