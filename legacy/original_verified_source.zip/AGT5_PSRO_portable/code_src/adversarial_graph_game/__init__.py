"""Exact tabular baseline for an adversarial graph-traversal game."""

from .costs import (
    EdgeRiskCost,
    EdgeRiskSpec,
    EdgeSupportCost,
    EdgeSupportSpec,
    EdgeTraversalCost,
    NodeSupportCost,
    NodeSupportSpec,
)
from .diagnostics import (
    PairDiagnosticSummary,
    compare_game_pair,
    configure_diagnostic_logger,
    cost_breakdown,
    write_solver_diagnostics,
)
from .environment import AdversarialGraphGame
from .graph_factory import (
    AdversarialGraphBuilder,
    GraphScenario,
    make_edge_support_demo_scenario,
)
from .layers import AmmoLayerResult, solve_ammo_layers
from .matrix_game import solve_zero_sum_matrix_game
from .models import (
    BlueAction,
    Edge,
    EquilibriumPolicy,
    GameSpec,
    GameState,
    GraphId,
    MatrixGameSolution,
    Node,
    PruningMode,
    PruningStats,
    RedAction,
    ValueIterationResult,
)
from .psro import (
    BestResponseResult,
    PSROIteration,
    PSROResult,
    TabularPolicy,
    build_empirical_payoff_matrix,
    evaluate_policy_pair_exact,
    exact_blue_best_response_behavioral,
    exact_red_best_response_behavioral,
    make_proper_blue_policy,
    make_stay_red_policy,
    run_vanilla_psro_exact,
    tabular_policy_from_ammo_layer_result,
)
from .pruning import (
    IntervalPruningResult,
    PruningResult,
    normalize_pruning_mode,
    prune_interval_dominated_actions,
    prune_strictly_dominated_actions,
)
from .reference_games import (
    make_berneburg_matlab_reference_game,
    matlab_state,
)
from .shapley import bellman_shapley_residual, shapley_value_iteration
from .symmetry import (
    canonicalize_action_within_position_groups,
    canonicalize_positions,
    unique_actions_mod_agent_symmetry,
)
from .state_space import (
    all_position_states,
    enumerate_full_state_space,
    reachable_states,
)
from .validation import (
    SolverCrossCheck,
    cross_check_solvers,
    max_layer_value_difference,
)

__all__ = [
    "AdversarialGraphBuilder",
    "AdversarialGraphGame",
    "AmmoLayerResult",
    "BlueAction",
    "Edge",
    "EdgeRiskCost",
    "EdgeRiskSpec",
    "EdgeSupportCost",
    "EdgeSupportSpec",
    "EdgeTraversalCost",
    "EquilibriumPolicy",
    "GameSpec",
    "GameState",
    "GraphId",
    "GraphScenario",
    "IntervalPruningResult",
    "MatrixGameSolution",
    "Node",
    "NodeSupportCost",
    "NodeSupportSpec",
    "PruningMode",
    "PruningResult",
    "PruningStats",
    "SolverCrossCheck",
    "bellman_shapley_residual",
    "canonicalize_action_within_position_groups",
    "canonicalize_positions",
    "cross_check_solvers",
    "RedAction",
    "ValueIterationResult",
    "all_position_states",
    "enumerate_full_state_space",
    "make_edge_support_demo_scenario",
    "make_berneburg_matlab_reference_game",
    "matlab_state",
    "max_layer_value_difference",
    "normalize_pruning_mode",
    "prune_interval_dominated_actions",
    "prune_strictly_dominated_actions",
    "reachable_states",
    "shapley_value_iteration",
    "solve_ammo_layers",
    "solve_zero_sum_matrix_game",
    "unique_actions_mod_agent_symmetry",
    "PairDiagnosticSummary",
    "compare_game_pair",
    "configure_diagnostic_logger",
    "cost_breakdown",
    "write_solver_diagnostics",
    "BestResponseResult",
    "PSROIteration",
    "PSROResult",
    "TabularPolicy",
    "build_empirical_payoff_matrix",
    "evaluate_policy_pair_exact",
    "exact_blue_best_response_behavioral",
    "exact_red_best_response_behavioral",
    "make_proper_blue_policy",
    "make_stay_red_policy",
    "run_vanilla_psro_exact",
    "tabular_policy_from_ammo_layer_result",
]
