"""Three PSRO population initialization conditions; existing PPO oracles unchanged.

Usage: python run_full_psro_long.py --init all --seeds 11 12 13 --steps 100000 --iterations 5 --wandb
"""
from __future__ import annotations

import argparse
import json
import random
import sys
import time
from collections import deque
from dataclasses import asdict
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
for directory in (ROOT / "code_src", ROOT / "code_scenario"):
    if str(directory) not in sys.path:
        sys.path.insert(0, str(directory))

from runs.main_run_SB import SMALL_SCENARIO, build_scenario
from runs.main_run_SB_PSRO_BC_seed import train_static_relgnn_bc_seed
from runs.main_run_SB_heuristic_security_bounds import build_snapshot_blue_heuristic
from adversarial_graph_game import PruningMode, solve_ammo_layers, all_position_states
from adversarial_graph_game.models import GameState
from adversarial_graph_game.psro import (
    TabularPolicy, make_stay_red_policy,
    evaluate_policy_pair_exact, build_empirical_payoff_matrix,
)
from adversarial_graph_game.matrix_game import solve_zero_sum_matrix_game
from adversarial_graph_game.psro_ppo import PPOConfig, train_ppo_best_response
from adversarial_graph_game.psro_ppo_relgnn_ablation import train_relgnn_blue_best_response

SCENARIO = SMALL_SCENARIO
AMMO = 1
BLUE_ACTOR = "static_relgnn"
BLUE_CRITIC = "mlp"
BASE_CFG = PPOConfig(
    total_steps=6000, rollout_steps=512, max_episode_steps=32,
    hidden_size=64, learning_rate=3e-4, update_epochs=4,
    minibatch_size=128, entropy_coef=0.01, entropy_coef_final=None,
    reward_scale=0.01, include_graph_feature=True,
    include_ammo_feature=True, include_red_reachability_feature=True,
)


def pair_value(game, blue, red):
    return float(evaluate_policy_pair_exact(
        game, blue, red,
        initial_graph=SCENARIO.initial_graph, initial_ammo=AMMO,
        initial_positions=SCENARIO.initial_positions,
    ))


def payoff(game, blue_pop, red_pop):
    return build_empirical_payoff_matrix(
        game, blue_pop, red_pop,
        initial_graph=SCENARIO.initial_graph, initial_ammo=AMMO,
        initial_positions=SCENARIO.initial_positions,
    )


def random_proper_blue_seed(game, seed):
    """Random tie-breaking among goal-progress actions, without risk/support planning.

    PSRO needs a legal policy to populate its first restricted matrix. The
    shortest-hop constraint ensures eventual arrival; it is not a risk-aware
    or support-aware policy, and it is NOT a learned PPO oracle.
    """
    rng = random.Random(seed)
    distances = {game.spec.goal_node: 0}
    queue = deque([game.spec.goal_node])
    while queue:
        node = queue.popleft()
        for adjacent in game.spec.adjacency[node]:
            if adjacent not in distances:
                distances[adjacent] = distances[node] + 1
                queue.append(adjacent)
    mapping = {}
    for ammo in range(game.spec.max_ammo + 1):
        for graph_id in game.spec.graph_costs:
            for positions in all_position_states(game.spec):
                state = GameState(positions, graph_id, ammo)
                if game.is_terminal(state):
                    continue
                legal = game.blue_actions(state)
                best = min(sum(distances[node] for node in action) for action in legal)
                candidates = [action for action in legal
                              if sum(distances[node] for node in action) == best]
                chosen = rng.choice(candidates)
                mapping[state] = {chosen: 1.0}
    return TabularPolicy("blue", mapping, name="blue_random_proper_seed")


def start_populations(game, condition, seed):
    red_seed = make_stay_red_policy(game, name="red_stay_seed")
    seed_stats = {}
    if condition == "scratch":
        # Random legal goal-progress policy for a finite initial payoff matrix.
        # This does not use risk/support planning, BC, or a pretrained PPO model.
        blue_seed = random_proper_blue_seed(game, seed)
    elif condition == "bc":
        # Preserve the existing BC population-seeding procedure; later PPO
        # oracles are randomly initialized, exactly as in the original script.
        blue_seed, seed_stats = train_static_relgnn_bc_seed(game, red_seed, seed=seed)
    elif condition == "heuristic":
        blue_seed, _ = build_snapshot_blue_heuristic(
            game, name="blue_support_snapshot_shortest_seed")
    else:
        raise ValueError(condition)
    return [blue_seed], [red_seed], seed_stats


def run(condition, seed, args):
    torch.set_num_threads(args.threads)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    game = build_scenario(SCENARIO, max_ammo=AMMO).build_game(with_support=True)
    blue_pop, red_pop, seed_stats = start_populations(game, condition, seed)
    blue_signatures = {p.signature(digits=7) for p in blue_pop}
    red_signatures = {p.signature(digits=7) for p in red_pop}
    out_dir = args.out_dir / condition
    out_dir.mkdir(parents=True, exist_ok=True)
    result_file = out_dir / ("seed%d.json" % seed)
    config = {**asdict(BASE_CFG), "total_steps": args.steps}
    svi = None
    if not args.skip_svi:
        exact = solve_ammo_layers(game, pruning_mode=PruningMode.NONE,
                                  tolerance=1e-9, max_iterations=5000)
        position = game.canonical_positions(SCENARIO.initial_positions)
        svi = float(exact.values[(SCENARIO.initial_graph, AMMO)][position])

    tracker = None
    if args.wandb:
        import wandb
        tracker = wandb.init(
            project=args.wandb_project, entity=args.wandb_entity,
            name="%s-seed%d-%dsteps" % (condition, seed, args.steps),
            group=condition, job_type="psro-initialization-long",
            mode=args.wandb_mode, reinit=True,
            config={"condition": condition, "seed": seed,
                    "steps_per_oracle": args.steps, "iterations": args.iterations,
                    "blue_actor": BLUE_ACTOR, "blue_critic": BLUE_CRITIC,
                    "red_actor": "mlp", "red_critic": "mlp",
                    "scenario": SCENARIO.name, "with_support": True,
                    "ppo": config, "svi": svi},
        )
        wandb.define_metric("psro/iteration")
        wandb.define_metric("psro/*", step_metric="psro/iteration")
        for player in ("blue", "red"):
            wandb.define_metric("ppo/%s/global_steps" % player)
            wandb.define_metric("ppo/%s/*" % player,
                                step_metric="ppo/%s/global_steps" % player)

    started = time.perf_counter()
    history = []
    result = {
        "status": "running", "condition": condition, "seed": seed,
        "scenario": SCENARIO.name, "support": True,
        "blue_actor": BLUE_ACTOR, "blue_critic": BLUE_CRITIC,
        "red_oracle": "mlp PPO", "ppo_config": config,
        "ppo_steps_per_oracle": args.steps, "psro_iterations": args.iterations,
        "exact_svi": svi, "bc_seed_stats": seed_stats,
        "initial_blue": [p.name for p in blue_pop],
        "initial_red": [p.name for p in red_pop], "history": history,
    }

    def save():
        result_file.write_text(json.dumps(result, indent=2), encoding="utf-8")

    try:
        mat = payoff(game, blue_pop, red_pop)
        solution = solve_zero_sum_matrix_game(mat, tolerance=1e-9)
        result["initial_value"] = float(solution.value)
        result["initial_blue_seed_pair_value"] = pair_value(game, blue_pop[0], red_pop[0])
        save()
        if tracker is not None:
            initial = {"psro/iteration": 0,
                       "psro/meta_value": float(solution.value),
                       "psro/blue_population": len(blue_pop),
                       "psro/red_population": len(red_pop)}
            if svi is not None:
                initial["psro/abs_gap_to_svi"] = abs(float(solution.value) - svi)
            tracker.log(initial)
        print("START", condition, "seed", seed, "initial", result["initial_value"], flush=True)

        for iteration in range(1, args.iterations + 1):
            iteration_start = time.perf_counter()
            mat = payoff(game, blue_pop, red_pop)
            solution = solve_zero_sum_matrix_game(mat, tolerance=1e-9)
            v = float(solution.value)
            blue_weights = np.asarray(solution.blue_policy, dtype=float)
            red_weights = np.asarray(solution.red_policy, dtype=float)

            def metric_callback(player):
                if tracker is None:
                    return None
                def emit(metrics):
                    s = int(metrics["steps"])
                    payload = {"ppo/%s/global_steps" % player: (iteration - 1) * args.steps + s,
                               "ppo/%s/local_steps" % player: s,
                               "ppo/%s/psro_iteration" % player: iteration}
                    payload.update({"ppo/%s/%s" % (player, key): val
                                    for key, val in metrics.items()
                                    if key != "steps" and val is not None})
                    tracker.log(payload)
                return emit

            blue_cfg = PPOConfig(**{**config, "seed": seed + iteration - 1})
            red_cfg = PPOConfig(**{**config, "seed": seed + 90 + iteration - 1})
            blue_policy, blue_stats, _ = train_relgnn_blue_best_response(
                game, actor_kind=BLUE_ACTOR, critic_kind=BLUE_CRITIC,
                opponent_population=red_pop, opponent_weights=red_weights,
                initial_graph=SCENARIO.initial_graph, initial_ammo=AMMO,
                initial_positions=SCENARIO.initial_positions, config=blue_cfg,
                name="%s_seed%d_blue_br_%d" % (condition, seed, iteration),
                gnn_dim=16, metric_callback=metric_callback("blue"),
            )
            red_policy, red_stats = train_ppo_best_response(
                game, player="red", opponent_population=blue_pop,
                opponent_weights=blue_weights,
                initial_graph=SCENARIO.initial_graph, initial_ammo=AMMO,
                initial_positions=SCENARIO.initial_positions, config=red_cfg,
                name="%s_seed%d_red_br_%d" % (condition, seed, iteration),
                metric_callback=metric_callback("red"),
            )
            blue_br = float(sum(float(weight) * pair_value(game, blue_policy, p)
                                for weight, p in zip(red_weights, red_pop)))
            red_br = float(sum(float(weight) * pair_value(game, p, red_policy)
                               for weight, p in zip(blue_weights, blue_pop)))
            blue_sig = blue_policy.signature(digits=7)
            red_sig = red_policy.signature(digits=7)
            blue_added = blue_sig not in blue_signatures
            red_added = red_sig not in red_signatures
            if blue_added:
                blue_pop.append(blue_policy)
                blue_signatures.add(blue_sig)
            if red_added:
                red_pop.append(red_policy)
                red_signatures.add(red_sig)
            mat = payoff(game, blue_pop, red_pop)
            updated = solve_zero_sum_matrix_game(mat, tolerance=1e-9)
            new_value = float(updated.value)
            row = {
                "iteration": iteration, "meta_before": v, "meta_after": new_value,
                "blue_BR": blue_br, "red_BR": red_br,
                "blue_gain": v-blue_br, "red_gain": red_br-v,
                "learned_BR_candidate_gap": red_br-blue_br,
                "blue_added": blue_added, "red_added": red_added,
                "blue_population": len(blue_pop), "red_population": len(red_pop),
                "blue_seconds": float(blue_stats.elapsed_seconds),
                "red_seconds": float(red_stats.elapsed_seconds),
                "iteration_seconds": time.perf_counter()-iteration_start,
                "elapsed_seconds": time.perf_counter()-started,
                "blue_names": [p.name for p in blue_pop],
                "red_names": [p.name for p in red_pop],
                "blue_mixture": [float(w) for w in updated.blue_policy],
                "red_mixture": [float(w) for w in updated.red_policy],
                "restricted_nash_gap": float(updated.strategy_gap),
            }
            history.append(row)
            result["elapsed_seconds"] = row["elapsed_seconds"]
            save()
            if tracker is not None:
                payload = {
                    "psro/iteration": iteration,
                    "psro/meta_value": new_value,
                    "psro/meta_before": v,
                    "psro/blue_best_response": blue_br,
                    "psro/red_best_response": red_br,
                    "psro/blue_gain": row["blue_gain"],
                    "psro/red_gain": row["red_gain"],
                    "psro/learned_br_candidate_gap": row["learned_BR_candidate_gap"],
                    "psro/blue_population": len(blue_pop),
                    "psro/red_population": len(red_pop),
                    "psro/restricted_nash_gap": row["restricted_nash_gap"],
                    "psro/elapsed_seconds": row["elapsed_seconds"],
                    "psro/blue_oracle_seconds": row["blue_seconds"],
                    "psro/red_oracle_seconds": row["red_seconds"],
                }
                if svi is not None:
                    payload["psro/abs_gap_to_svi"] = abs(new_value-svi)
                for player, weights in (("blue", updated.blue_policy),
                                        ("red", updated.red_policy)):
                    payload.update({"mixture/%s/policy_%03d" % (player,i): float(w)
                                    for i,w in enumerate(weights)})
                tracker.log(payload)
            print("ITER", condition, seed, iteration,
                  "V", round(v, 4), "B", round(blue_br, 4),
                  "R", round(red_br, 4), "new", round(new_value, 4),
                  "elapsed", round(row["elapsed_seconds"],1), flush=True)

        result.update({
            "status": "complete", "final": float(updated.value),
            "abs_gap_to_svi": abs(float(updated.value)-svi) if svi is not None else None,
            "total_seconds": time.perf_counter()-started,
            "final_blue_names": [p.name for p in blue_pop],
            "final_red_names": [p.name for p in red_pop],
            "final_blue_mixture": [float(w) for w in updated.blue_policy],
            "final_red_mixture": [float(w) for w in updated.red_policy],
            "payoff_matrix": mat.tolist(),
        })
        save()
        if tracker is not None:
            tracker.summary.update({"final_meta_value": result["final"],
                                    "total_seconds": result["total_seconds"]})
        print("DONE", condition, seed, "final", result["final"], flush=True)
    except BaseException as exc:
        result["status"] = "failed"
        result["error"] = repr(exc)
        save()
        raise
    finally:
        if tracker is not None:
            tracker.finish()


def main():
    parser = argparse.ArgumentParser(description="Long PSRO: scratch, BC, or heuristic population seed")
    parser.add_argument("--init", choices=("scratch","bc","heuristic","all"), default="all")
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--seeds", nargs="+", type=int, default=[11,12,13])
    parser.add_argument("--steps", type=int, default=100000, help="PPO steps PER oracle, not total PSRO steps")
    parser.add_argument("--iterations", type=int, default=5)
    parser.add_argument("--threads", type=int, default=1)
    parser.add_argument("--out-dir", type=Path, default=ROOT / "results_psro_long")
    parser.add_argument("--skip-svi", action="store_true")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--wandb", action="store_true")
    parser.add_argument("--wandb-project", default="agt5-psro")
    parser.add_argument("--wandb-entity", default=None)
    parser.add_argument("--wandb-mode", choices=("online","offline","disabled"), default="online")
    args = parser.parse_args()
    if min(args.steps, args.iterations, args.threads) <= 0:
        parser.error("--steps, --iterations, --threads must be positive")
    conditions = ("scratch","bc","heuristic") if args.init=="all" else (args.init,)
    seeds = (args.seed,) if args.seed is not None else args.seeds
    for condition in conditions:
        for seed in seeds:
            dest = args.out_dir / condition / ("seed%d.json" % seed)
            if dest.exists() and not args.force:
                try:
                    existing = json.loads(dest.read_text())
                    if (existing.get("status")=="complete" and
                        existing.get("ppo_steps_per_oracle")==args.steps and
                        existing.get("psro_iterations")==args.iterations):
                        print("SKIP", condition, seed, flush=True)
                        continue
                except (ValueError,OSError):
                    pass
            run(condition, seed, args)


if __name__ == "__main__":
    main()
