# Portability validation log

Validation performed in the preparation environment using **Python 3.13.5**, NumPy 2.3.5, SciPy 1.17.0 and PyTorch 2.10.0+cpu. A native Python 3.9 binary was not accessible; **this is not a claim of a completed native 3.9 runtime test**.

- Parsed every project `.py` file with `ast.parse(feature_version=(3, 9))` successfully.
- Imported `adversarial_graph_game`, `runs.main_run_SB`, the BC diagnostic, and the Rel-GNN PPO implementation.
- Tested `strict_zip` on equal and unequal list lengths.
- Tested the conditional Python 3.9 fallback for `@dataclass(slots=True, frozen=True)` by simulating a 3.9 version flag.
- Created the 5-node support-enabled scenario and requested legal Blue actions from its initial state.
- Executed full PSRO **smoke** for all four architectures (`mlp_mlp`, `mlp_rel`, `rel_mlp`, `rel_rel`) with seed 11, 8 PPO steps per oracle, and one PSRO expansion. All completed.
- Executed the exact-DP behavior-cloning diagnostic from an unrelated working directory with 1 epoch and seed 11, for Static and Action Rel-GNN. Both completed and wrote JSON.
- Executed the smoke suite from a separate venv with dependency access to the preinstalled Python 3.13 libraries. No `PYTHONPATH` export was needed.
- For `rel_rel`, seed 11, 8 steps, 1 expansion, the original archive and corrected archive produced **identical** final value, initial value, response values, equilibrium mixtures, and payoff matrix (both `V_final=47.342710837526305`). This confirms numerical preservation for that single smoke configuration only.

The 8-step PSRO and 1-epoch BC tests are implementation checks, **not valid algorithmic performance results**.

## Remaining VM-specific validation

Run `python verify_portability.py` and `bash run_smoke.sh` under an **actual Python 3.9 VM with the requirements installed**, then run the desired full-budget experiment. The setup helper is `bash setup_linux_vm.sh`; it creates `.venv` without modifying the system Python. PyTorch wheels and CUDA availability are platform-specific.
