# Python 3.9.9 VM deployment — fresh replacement (V5)

The previous versions of this project contained f-string expressions that Python 3.9
could not parse. This archive fixes the known syntax failures, preserves the W&B
changes, and adds a **repository-wide preflight**. It is important to avoid mixing
V2/V3 files with V5 files.

## Extract to a NEW directory

```bash
cd /home/klimbu2
mkdir -p agt5_verified_v5
unzip AGT5_PSRO_python39_WANDB_v5_FULL_AUDIT.zip -d agt5_verified_v5
cd agt5_verified_v5/AGT5_PSRO_portable
source /home/klimbu2/myenv_agt/bin/activate
which python
python --version      # Must say 3.9.9 for native validation
```

## Validate every source file *before* launching training

```bash
python python39_preflight.py --require-python39
# Optional stronger check (slower): python python39_preflight.py --require-python39 --isolated-imports
```

This checks (1) source-file SHA256 integrity against the delivered archive,
(2) compilation of every `.py` file using your **real Python 3.9 parser**, and
(3) imports of every `runs/main_*.py` and package module.
The optional `--isolated-imports` mode tests each module in a separate process
but may be substantially slower on a shared VM.
If something fails, the report includes the exact file/module name and error.
If dependencies are missing, first run `python -m pip install -r requirements-py39.txt`
(and `-r requirements-wandb-py39.txt` for W&B).

For a syntax-only check without dependencies:

```bash
python python39_preflight.py --require-python39 --syntax-only
```

For a quick, controlled runtime smoke check:

```bash
PYTHON_BIN=python bash run_smoke.sh
```

Only after preflight and smoke succeed, run the original diagnostic:

```bash
python code_src/runs/main_run_SB_PPO_relgnn_diagnostic.py
```

Or launch your W&B-enabled experiment:

```bash
wandb login
python run_full_arch_psro.py --variant rel_rel --seed 11 --steps 128 --iterations 1 \
  --force --wandb --wandb-project agt5-psro
```

## Checks and limitations

- Python 3.9 **syntax** is checked across every distributed source file by
  an independent versioned grammar parser before this ZIP was created.
- Imports and reduced training paths were tested with the Python 3.13
  environment used to create the ZIP.
- This sandbox did not have Python 3.9.9 installed. The first authoritative
  Python 3.9.9 runtime validation happens when you execute the preflight
  with `/home/klimbu2/myenv_agt/bin/python` on your VM.
- Importing a module is not equivalent to executing every full-budget training
  experiment. `run_smoke.sh` covers representative short execution paths.
- The source hashes verify your files are those from V5; if you subsequently
  edit source files intentionally, pass `--skip-hashes` to the preflight.
