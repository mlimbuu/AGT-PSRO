#!/usr/bin/env bash
# Install dependencies in a project-local venv; no root/sudo access required.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
PYTHON_BIN="${PYTHON_BIN:-python3}"
"$PYTHON_BIN" -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
if [ "$(python -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')" = "3.9" ]; then
    python -m pip install -r requirements-py39.txt
else
    python -m pip install -r requirements.txt
fi
python verify_portability.py
printf '
Environment ready. Run: source .venv/bin/activate
'
