# Long PSRO initialization comparison

Single new entry point: `run_full_psro_long.py`. The existing PPO source files are **not changed**.

## What it compares

- `scratch`: randomly tie-broken shortest-hop goal-progress Blue policy as a **minimal proper initial population**, plus stay-Red. No BC and no risk/support-aware heuristic initialization. The PPO oracle is always initialized randomly. The seed is not a fully unconstrained random policy because PSRO needs an initial valid policy and improper random policies can make expected costs undefined.
- `bc`: existing `train_static_relgnn_bc_seed` function (clone of the exact Blue BR to stay-Red); subsequent PPO best responses initialize randomly as before.
- `heuristic`: existing current-snapshot risk/support-aware shortest-path Blue policy; subsequent PPO best responses initialize randomly as before.

All conditions use `SMALL_SCENARIO` from `runs.main_run_SB`, support enabled, one ammo unit, Static Rel-GNN actor + MLP critic for Blue, MLP PPO Red, same PPO hyperparameters as existing BC/heuristic PSRO scripts. Same three seeds by default.

## Quick smoke test

```bash
python -u run_full_psro_long.py --init all --seed 11 --steps 128 --iterations 1 --wandb --wandb-project agt5-psro
```

## Long experiment, one command

```bash
python -u run_full_psro_long.py --init all --seeds 11 12 13 \
  --steps 100000 --iterations 5 --wandb --wandb-project agt5-psro
```

Each combination has its own W&B run and local `results_psro_long/{condition}/seed{seed}.json`; the script runs sequentially. To run a subset or submit three independent Slurm jobs use `--init scratch`, `--init bc`, or `--init heuristic`. Use `--force` to rerun completed configurations. W&B entity/host are inherited from the active environment; `--wandb-entity` can override entity.

`--steps` is the **total environment steps for each fresh Blue or Red PPO best-response training**, not a shared total and not training continuation across PSRO iterations. For 100,000 steps, 5 iterations, 3 seeds, 3 initializations, the requested budget is 9,000,000 PPO environment steps (2 players x 5 x 3 x 3 x 100,000), not including BC pretraining and evaluation.

## W&B panels

- `psro/meta_value`, `psro/abs_gap_to_svi`, `psro/blue_best_response`, `psro/red_best_response`, `psro/blue_gain`, `psro/red_gain`, `psro/learned_br_candidate_gap`, `psro/elapsed_seconds`, `psro/blue_population`, `psro/red_population` vs `psro/iteration`.
- `ppo/blue/episode_cost_mean_last10`, `ppo/red/episode_cost_mean_last10`, `entropy`, `policy_loss`, `value_loss` vs `ppo/<player>/global_steps`.
- `mixture/<player>/policy_000`, etc., and named mixture weights per iteration in result JSON.

Interpretation: `psro/meta_value` is not exploitability, and `psro/learned_br_candidate_gap` is NOT a certified equilibrium gap. Exact pairwise evaluation of PPO policy snapshots occurs at the end of each best-response training and PSRO iteration, not every PPO rollout. Per-rollout episode-cost curves are **not** evaluations of intermediate exact best responses. Adding exact checkpoint BR evaluations would require changing the PPO trainers, explicitly deferred for now.

## Important experimental caveat

BC and heuristic initial policies may be identical or nearly equivalent in this small game, producing identical initial payoffs and overlapping subsequent PPO trajectories. That is a legitimate experimental result rather than a logging error.

Local tests: Python 3.9 syntax parser passed; all three conditions ran for a one-iteration 64-step smoke test; a two-iteration test ran with all conditions; the W&B path passed with a test stub. Actual Python 3.9/3.12 runtime on Hopper and cloud W&B sync are not validated in this environment.
