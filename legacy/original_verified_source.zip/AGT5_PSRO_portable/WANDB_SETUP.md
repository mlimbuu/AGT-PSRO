# Monitor AGT5 PSRO from outside the VM (W&B)

Run from the extracted `AGT5_PSRO_portable` directory. A VM needs outbound HTTPS access to W&B, but **no inbound ports, SSH forwarding, or TensorBoard server**.

## One-time VM setup (Python 3.9)

```bash
PYTHON_BIN=python3.9 bash setup_linux_vm.sh
source .venv/bin/activate
python -m pip install -r requirements-wandb-py39.txt
wandb login
```

`wandb login` prompts for an API key; obtain it from the W&B website. Never put a key into source code or commit it. If your VM uses an outbound proxy, configure HTTPS access first.

## Run one test (logs to your W&B account)

```bash
python run_full_arch_psro.py --variant rel_rel --seed 11 --steps 128 --iterations 1 --force --wandb --wandb-project agt5-psro
```

Open https://wandb.ai/ and select the `agt5-psro` project. The link W&B prints in the terminal is the direct run URL.

## Run full experiment: 4 architectures x 3 seeds

```bash
python run_full_arch_psro.py --variant all --seeds 11 12 13 --steps 6000 --iterations 5 --wandb --wandb-project agt5-psro --out-dir results
```

Each architecture+seed creates a W&B run. In W&B, group by `variant`, compare runs by `seed` and graph `psro/meta_value`, `psro/abs_gap_to_svi`, `psro/blue_gain`, `psro/red_gain`, and `ppo/blue/*`, `ppo/red/*` metrics. PPO plots are keyed to event order; use `ppo/blue/steps`, `ppo/red/steps` and `ppo/psro_iteration` to locate each oracle's local training step. Metrics for PPO losses are **last-minibatch values per rollout**, not epoch means. `episode_cost_mean_last10` is empirical training cost, not an exact BR or a certified bound. PSRO BR values come from exact evaluation of the learned policies.

### Offline VM

```bash
python run_full_arch_psro.py --variant rel_rel --seed 11 --steps 128 --iterations 1 --force --wandb --wandb-mode offline
wandb sync wandb/offline-run-*
```

Sync later from a machine with internet access if the VM has no network. You can also copy the offline-run folder to your laptop and run `wandb sync` there.

### Note

W&B is optional. Without `--wandb`, the original JSON outputs and experiment behavior are preserved. The `--force` flag is required if a matching completed JSON result exists and you want to relog it; logging cannot retroactively reproduce training trajectories from summary JSON alone.

## New dashboard panels and research interpretation

Use the W&B **Runs** workspace to compare `variant` and `seed` across runs.
Suggested line plots (these metrics are emitted automatically):

| Chart | Y-axis | X-axis | Interpretation |
|---|---|---|---|
| Meta-game convergence | `psro/meta_value` | `psro/iteration` | Restricted-game equilibrium value; **not** exploitability |
| SVI distance | `psro/abs_gap_to_svi` | `psro/iteration` | Comparison to the Type-II reference `EXACT`; not a certificate |
| Learned BR candidate band | `psro/learned_br_lower_candidate`, `psro/learned_br_upper_candidate` | `psro/iteration` | Exact policy evaluation of **learned** Blue/Red BR policies against the restricted mixtures; **NOT full-game security bounds** |
| Learned BR candidate gap | `psro/learned_br_candidate_gap` | `psro/iteration` | Upper candidate minus lower candidate, may not be nonnegative in a failed approximation; **NOT certified exploitability** |
| Restricted LP consistency | `psro/restricted_nash_gap` | `psro/iteration` | Nash/security gap **inside the finite restricted payoff matrix**; small does not establish full-game convergence |
| Mix composition | `mixture/blue/policy_000` (etc.) and `mixture/red/policy_000` | `psro/iteration` | Population policy weights; `mixture/{player}/table` gives policy names and probabilities |
| PPO episode cost | `ppo/blue/episode_cost_mean_last10`, `ppo/red/episode_cost_mean_last10` | `ppo/{player}/global_steps` | Cost from training episodes, not exact best response |
| PPO entropy/loss | `ppo/{player}/entropy`, `ppo/{player}/policy_loss`, `ppo/{player}/value_loss` | `ppo/{player}/global_steps` | Training diagnostics; loss values represent final minibatch of a rollout |

Each player's PPO cumulative step axis is `(PSRO iteration - 1) * steps_per_oracle + local PPO steps`. The metric `ppo/{player}/local_steps` resets for each newly trained best response, and `ppo/{player}/psro_iteration` identifies the corresponding oracle. W&B defines explicit per-family step axes automatically.

Tables `mixture/{player}/table` are snapshots (one table per iteration). Individual numeric policy-weight series are indexed by **insertion order**: `policy_000`, `policy_001`, etc. Policy identity can be matched from the tables and result JSON (`blue_names_after`, `red_names_after`). Use the tables for exact policy names; line plots for trajectories.

The final payoff matrix is logged as `psro/final_payoff_matrix` (W&B Table). It is also saved in the standard result JSON.

**Certification warning:** At iteration k, the code computes learned Blue candidate `J(B_PPO, sigma_R^k)` and learned Red candidate `J(sigma_B^k, R_PPO)` by exact evaluation of the **learned policies**. They are not the true best responses `min_B J(B, sigma_R^k)` and `max_R J(sigma_B^k, R)`. Hence their interval is not a rigorous bracket on the full-game Nash value. A true certificate needs exact best responses or justified per-oracle approximation error bounds. `psro/restricted_nash_gap` measures only the LP solution's finite-matrix consistency.

### Re-run existing completed experiments

`run_full_arch_psro.py` skips completed JSON configurations unless `--force` is present. New W&B graphs require **new training**, since historical summary JSON cannot recreate per-rollout curves. Example:

```bash
python run_full_arch_psro.py --variant rel_rel --seed 11 \
  --steps 6000 --iterations 5 --force \
  --wandb --wandb-project agt5-psro
```
