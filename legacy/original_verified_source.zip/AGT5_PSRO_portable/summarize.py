from pathlib import Path
from statistics import mean,stdev
from collections import defaultdict
import csv, json, zipfile, shutil
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

D=Path('/mnt/data/AGT5_full_arch_psro')
variants=[('mlp_mlp','MLP','MLP'),('mlp_rel','MLP','Static Rel-GNN'),('rel_mlp','Static Rel-GNN','MLP'),('rel_rel','Static Rel-GNN','Static Rel-GNN')]
results=[]
for code,actor,critic in variants:
    for seed in (11,12,13):
        f=D/f'{code}_seed{seed}.json'
        d=json.loads(f.read_text())
        assert d['status']=='complete' and len(d['history'])==5,(code,seed,d.get('status'))
        assert len(d['final_blue'])==8 and len(d['final_red'])==6
        results.append(d)
assert len(results)==12

run_rows=[];iter_rows=[];summaries=[]
for d in results:
    run_rows.append(dict(variant=d['id'].split('_seed')[0],actor=d['actor'],critic=d['critic'],seed=d['seed'],
       final_restricted_value=d['final'],exact_SVI=d['exact_svi'],abs_value_gap=d['abs_gap'],
       blue_improving_calls=sum(x['blue_improves'] for x in d['history']),
       red_improving_calls=sum(x['red_improves'] for x in d['history']),
       mean_blue_gain=mean(x['blue_gain'] for x in d['history']),
       mean_blue_seconds=mean(x['blue_seconds'] for x in d['history']),
       mean_red_seconds=mean(x['red_seconds'] for x in d['history']),
       total_run_seconds=d['total_seconds'],
       blue_initial_SP_weight=d['final_blue'][0],
       blue_initial_RA_weight=d['final_blue'][1],
       blue_initial_SA_weight=d['final_blue'][2],
       blue_learned_weight=sum(d['final_blue'][3:]),
       red_R0_weight=d['final_red'][0],red_R1_weight=d['final_red'][1],
       red_other_weight=sum(d['final_red'][2:])))
    for h in d['history']:
        iter_rows.append(dict(variant=d['id'].split('_seed')[0],actor=d['actor'],critic=d['critic'],seed=d['seed'],
            iteration=h['iteration'],meta_before=h['meta_before'],blue_BR=h['blue_BR'],red_BR=h['red_BR'],
            blue_gain=h['blue_gain'],red_gain=h['red_gain'],blue_improves=h['blue_improves'],
            red_improves=h['red_improves'],meta_after=h['meta_after'],
            blue_seconds=h['blue_seconds'],red_seconds=h['red_seconds']))

def csvwrite(path,rows):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,list(rows[0]));w.writeheader();w.writerows(rows)
csvwrite(D/'per_run_results.csv',run_rows)
csvwrite(D/'per_iteration_results.csv',iter_rows)

for code,actor,critic in variants:
    arr=[x for x in run_rows if x['variant']==code]
    its=[x for x in iter_rows if x['variant']==code]
    vals=[x['final_restricted_value'] for x in arr];gaps=[x['abs_value_gap'] for x in arr]
    row=dict(variant=code,actor=actor,critic=critic,n_seeds=3,blue_PPO_steps=6000,psro_expansions=5,
        final_mean=mean(vals),final_sample_sd=stdev(vals),gap_mean=mean(gaps),gap_sample_sd=stdev(gaps),
        blue_BR_improving_calls=sum(x['blue_improves'] for x in its),blue_BR_calls=len(its),
        red_BR_improving_calls=sum(x['red_improves'] for x in its),red_BR_calls=len(its),
        mean_blue_gain=mean(x['blue_gain'] for x in its),
        mean_blue_gap=mean(-x['blue_gain'] for x in its),
        mean_blue_oracle_seconds=mean(x['blue_seconds'] for x in its),
        mean_red_oracle_seconds=mean(x['red_seconds'] for x in its),
        mean_run_seconds=mean(x['total_run_seconds'] for x in arr),
        mean_SP_weight=mean(x['blue_initial_SP_weight'] for x in arr),
        mean_RA_weight=mean(x['blue_initial_RA_weight'] for x in arr),
        mean_SA_weight=mean(x['blue_initial_SA_weight'] for x in arr),
        mean_learned_blue_weight=mean(x['blue_learned_weight'] for x in arr))
    summaries.append(row)
csvwrite(D/'architecture_summary.csv',summaries)

# Plot: excess Blue BR cost over current restricted equilibrium; lower better.
fig,ax=plt.subplots(figsize=(9.2,5.2))
for code,actor,critic in variants:
    xs=list(range(1,6))
    ys=[mean(x['blue_BR']-x['meta_before'] for x in iter_rows if x['variant']==code and x['iteration']==k) for k in xs]
    ax.plot(xs,ys,marker='o',label=f'{actor} actor / {critic} critic')
ax.axhline(0,ls='--',lw=1.0,label='Improving-response threshold')
ax.set_xticks(range(1,6));ax.set_xlabel('PSRO expansion');ax.set_ylabel('Blue BR cost minus restricted value (lower better)')
ax.set_title('Blue PPO response quality — 5-node Type II, $\\alpha=1$, three seeds')
ax.grid(True,alpha=.25);ax.legend(fontsize=8,loc='upper right')
fig.tight_layout();fig.savefig(D/'blue_response_quality.png',dpi=190);plt.close(fig)

# Plot: cost-steps mean trajectory illustrates identical restricted values.
fig,ax=plt.subplots(figsize=(8.4,4.8))
for code,actor,critic in variants:
    xs=list(range(6)); ys=[]
    for k in xs:
        ds=[d for d in results if d['id'].split('_seed')[0]==code]
        ys.append(mean((d['initial_value'] if k==0 else d['history'][k-1]['meta_after']) for d in ds))
    ax.plot(xs,ys,marker='o',label=f'{actor}/{critic}')
ax.axhline(43.9336763713,ls='--',lw=1.0,label='Full-game exact SVI')
ax.set_xlabel('Number of PSRO expansions');ax.set_ylabel('Restricted-game Nash value (Blue cost)')
ax.set_title('PSRO value trajectories overlap across all four architectures')
ax.grid(True,alpha=.2);ax.legend(fontsize=8);fig.tight_layout()
fig.savefig(D/'psro_value_trajectories.png',dpi=190);plt.close(fig)

# Paste-ready table slide snippet.
tex=r'''% Paste into a Beamer frame; requires booktabs, graphicx, makecell.
\begin{frame}{5-Node Type II: Full PSRO Actor--Critic Ablation ($\alpha=1$)}
\centering\footnotesize
\resizebox{\textwidth}{!}{%
\begin{tabular}{llcccc}
\toprule
\textbf{Blue Actor} & \textbf{Blue Critic} & $V_{\mathrm{PSRO}}\downarrow$ & $|V_{\mathrm{PSRO}}-V^*|\downarrow$ & \makecell{Improving Blue BRs} & \makecell{Blue PPO seconds\ per oracle} \\
\midrule
'''
for x in summaries:
    tex+=f"{x['actor']} & {x['critic']} & ${x['final_mean']:.3f}\\pm {x['final_sample_sd']:.3f}$ & ${x['gap_mean']:.3f}\\pm {x['gap_sample_sd']:.3f}$ & ${x['blue_BR_improving_calls']}/{x['blue_BR_calls']}$ & ${x['mean_blue_oracle_seconds']:.1f}$ \\\n"
tex+=r'''\midrule
\multicolumn{2}{l}{Exact full-game SVI} & $43.934$ & $0$ & -- & -- \\
\bottomrule
\end{tabular}}
\vspace{0.5em}

{\scriptsize Heuristic Blue initialization $\{\pi_{\mathrm{SP}},\pi_{\mathrm{RA}},\pi_{\mathrm{SA}}\}$; Red $R_0=\mathrm{stay}\text{-}G_1$.\\
Five PSRO expansions, 6000 PPO steps/oracle, three matched seeds. Red oracle is fixed MLP-PPO.\\
All final Blue mass is on $\pi_{\mathrm{SP}}$ and $\pi_{\mathrm{RA}}$; no learned Blue policy enters equilibrium support.}
\end{frame}
'''
# Correct row delimiters and table-header line break for a standalone Beamer frame.
tex=tex.replace(r'\makecell{Blue PPO seconds\ per oracle}',r'\makecell{Blue PPO seconds\\per oracle}')
tex='\n'.join((line+'\\' if line.endswith(' \\') and not line.endswith(' \\\\') else line) for line in tex.split('\n'))
(D/'slide_table.tex').write_text(tex)

(D/'README.md').write_text('''# Full 5-node Type II PSRO architecture comparison

Twelve complete runs: 4 Blue actor-critic pairs x 3 matched seeds (11, 12, 13); 5 PSRO population expansions each.
All use Blue initial heuristic population {SP, RA, SA}; Red initial policy stay-G1; Red BR oracle MLP-PPO.
6000 PPO steps per Blue/Red oracle, same original hyperparameters, support enabled, alpha=1, two Blue agents.
Red game transitions all-to-all, 3 risk configurations. Stage costs use exact pairwise fixed-policy evaluation.
Exact full-game SVI reference is 43.9336763713; difference of restricted-game value is NOT an exploitability bound.

architecture_summary.csv: means and sample standard deviations across 3 matched random seeds.
per_run_results.csv: 12 final results and mixtures.
per_iteration_results.csv: 60 expansion rows, BR quality and timing.
*_seed*.json: original complete iteration histories and payoff matrices for 12 runs.
*_seed*.log: execution logs.
blue_response_quality.png: training target response gap; >0 means no improvement for minimizer.
psro_value_trajectories.png: exact SVI reference and aggregate restricted-game values.
slide_table.tex: paste-ready LaTeX Beamer results slide.
run_full_arch_psro.py: reproducible experiment harness.
code_src/: copied game and PPO source code. Scenario config at code_scenario/test_type2.py.

CAVEATS: Rel-GNN models receive graph-derived features not supplied to basic MLP; this is not a feature-matched ablation. Actor parameterization differs between MLP global action logits and GNN candidate-action scoring. Training seconds are measured under concurrent local runs, so compare as approximate wall times. Frozen neural stochastic policies are exported into exact payoff evaluation; greedy snapshots are NOT PSRO policies. Only one small game, three seeds, five fixed iterations. Red PPO policy optimization is shared across all four actor variants. No BR/exploitability certification.

RUN: set PYTHONPATH=<bundle>/code_src:<bundle>/code_scenario and execute:
  python run_full_arch_psro.py --variant mlp_mlp --seed 11
Variants: mlp_mlp, mlp_rel, rel_mlp, rel_rel. Seeds 11,12,13.
''')

# Include complete source and scenario for standalone reproduction (no external accesses).
src=Path('/mnt/data/AGT5_arch_ablation/AGT5_TypeII_alpha1/adversarial_graph_game_explicit_transitions/src')
sc=Path('/mnt/data/AGT5_arch_ablation/AGT5_TypeII_alpha1/test_type2.py')
shutil.copytree(src,D/'code_src',dirs_exist_ok=True)
(D/'code_scenario').mkdir(exist_ok=True)
shutil.copy2(sc,D/'code_scenario'/'test_type2.py')
with zipfile.ZipFile(D/'complete_12_run_bundle.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    for f in D.rglob('*'):
        if f.is_file() and f.name!='complete_12_run_bundle.zip' and '__pycache__' not in f.parts:
            z.write(f,f.relative_to(D))
print(json.dumps(summaries,indent=2))
print('WROTE',len(results),'runs and',len(iter_rows),'iter rows')
