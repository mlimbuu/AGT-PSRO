"""5-node Type II: 4 actor-critic pairs x 3 seeds, full 5-round PSRO."""
from __future__ import annotations
import argparse,json,time,traceback,sys,random,os
import numpy as np
from dataclasses import asdict
from pathlib import Path
import torch
# Resolve imports relative to this file, independent of launch directory.
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'code_src'))
sys.path.insert(0, str(ROOT / 'code_scenario'))
from test_type2 import cfg
from runs.main_run_SB import build_scenario
from runs.main_run_SB_heuristic_security_bounds import build_snapshot_blue_heuristic
from adversarial_graph_game.compat import strict_zip
from adversarial_graph_game import all_position_states
from adversarial_graph_game.models import GameState
from adversarial_graph_game.psro import (TabularPolicy,build_empirical_payoff_matrix,evaluate_policy_pair_exact,make_stay_red_policy,make_proper_blue_policy)
from adversarial_graph_game.matrix_game import solve_zero_sum_matrix_game
from adversarial_graph_game.psro_ppo import PPOConfig,train_ppo_best_response
from adversarial_graph_game.psro_ppo_relgnn_ablation import train_relgnn_blue_best_response

OUT=ROOT / 'results'
VARIANTS={'mlp_mlp':('mlp','mlp'),'mlp_rel':('mlp','static_relgnn'),'rel_mlp':('static_relgnn','mlp'),'rel_rel':('static_relgnn','static_relgnn')}
STEPS=6000;NITER=5;ALPHA=1;EXACT=43.9336763713
BASE=PPOConfig(total_steps=STEPS,rollout_steps=512,max_episode_steps=32,hidden_size=64,learning_rate=3e-4,update_epochs=4,minibatch_size=128,entropy_coef=.01,entropy_coef_final=None,reward_scale=.01,include_graph_feature=True,include_ammo_feature=True,include_red_reachability_feature=True)

def heuristics(game):
    nosup=build_scenario(cfg,max_ammo=ALPHA).build_game(with_support=False)
    sp=make_proper_blue_policy(game,name='pi_SP')
    raw,_=build_snapshot_blue_heuristic(nosup,name='risk_averse_nosupport')
    mp={}
    for ammo in range(ALPHA+1):
        for gid in game.spec.graph_costs:
            for p in all_position_states(game.spec):
                s=GameState(p,gid,ammo)
                if game.is_terminal(s):continue
                acts,pr=raw.distribution(nosup,s)
                mp[s]={acts[int(pr.argmax())]:1.0}
    return [sp,TabularPolicy('blue',mp,name='pi_RA'),build_snapshot_blue_heuristic(game,name='pi_SA')[0]]

def evalpair(game,b,r):
    return float(evaluate_policy_pair_exact(game,b,r,initial_graph=cfg.initial_graph,initial_ammo=ALPHA,initial_positions=cfg.initial_positions))

def matrix(game,bp,rp):
    return build_empirical_payoff_matrix(game,bp,rp,initial_graph=cfg.initial_graph,initial_ammo=ALPHA,initial_positions=cfg.initial_positions)

def log_mixture(tracker, player, policies, weights, iteration):
    """Log stable policy IDs as numeric panels and human-readable composition table.

    Individual numeric-series indices correspond to insertion order and remain stable
    as the population expands. Policy names are stored in the table for interpretation.
    """
    weights = np.asarray(weights, dtype=float)
    tracker.log({"psro/iteration": iteration,
                 **{f"mixture/{player}/policy_{i:03d}": float(w)
                    for i, w in enumerate(weights)}})
    tracker.log({f"mixture/{player}/table": tracker.Table(
        columns=["iteration", "policy_index", "policy_name", "probability"],
        data=[[int(iteration), i, p.name, float(w)]
              for i, (p, w) in enumerate(zip(policies, weights))])})


def run(v,seed,steps=6000,niter=5,out_dir=None,threads=1, wandb_enabled=False, wandb_project="agt5-psro", wandb_entity=None, wandb_mode="online"):
    torch.set_num_threads(threads)
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    out_dir = Path(out_dir) if out_dir is not None else OUT
    out_dir.mkdir(parents=True, exist_ok=True)
    actor,critic=VARIANTS[v]
    game=build_scenario(cfg,max_ammo=ALPHA).build_game(with_support=True)
    bp=heuristics(game);rp=[make_stay_red_policy(game,name='R0_stay_G1')]
    bs={p.signature(digits=7) for p in bp};rs={p.signature(digits=7) for p in rp}
    tracker = None
    if wandb_enabled:
        try:
            import wandb
        except ImportError as exc:
            raise RuntimeError("Install W&B first: python -m pip install 'wandb<0.20' (Python 3.9)") from exc
        tracker = wandb.init(
            project=wandb_project, entity=wandb_entity,
            name=f"{v}-seed{seed}", group=v, job_type="psro",
            mode=wandb_mode, reinit=True,
            config={"variant": v, "actor": actor, "critic": critic, "seed": seed,
                    "steps_per_oracle": steps, "psro_iterations": niter,
                    "alpha": ALPHA, "exact_svi": EXACT, "ppo": {**asdict(BASE), "total_steps": steps}},
        )
        # Distinct x axes prevent PSRO iteration and PPO rollouts sharing an event-index axis.
        wandb.define_metric("psro/iteration")
        wandb.define_metric("psro/*", step_metric="psro/iteration")
        wandb.define_metric("mixture/*", step_metric="psro/iteration")
        for player in ("blue", "red"):
            wandb.define_metric(f"ppo/{player}/global_steps")
            wandb.define_metric(f"ppo/{player}/*", step_metric=f"ppo/{player}/global_steps")
        # W&B starts a new run for each architecture/seed. No server ports needed.
    dest=out_dir/f'{v}_seed{seed}.json' 
    params=asdict(BASE); params['total_steps']=steps
    m=matrix(game,bp,rp);init=solve_zero_sum_matrix_game(m,tolerance=1e-9)
    data=dict(id=f'{v}_seed{seed}',actor=actor,critic=critic,seed=seed,alpha=ALPHA,
        graph='5node Type II 3-risk all-to-all',support=True,initial_blue=[p.name for p in bp],
        initial_red=[p.name for p in rp],red_oracle='MLP PPO',initial_value=float(init.value),
        exact_svi=EXACT,steps=steps,n_expansions=niter,config=params,history=[],status='running')
    t0=time.perf_counter();dest.write_text(json.dumps(data,indent=2))
    if tracker is not None:
        tracker.log({"psro/iteration": 0, "psro/meta_value": float(init.value),
                     "psro/abs_gap_to_svi": abs(float(init.value)-EXACT),
                     "psro/blue_population": len(bp), "psro/red_population": len(rp),
                     "psro/restricted_nash_gap": float(init.strategy_gap)})
        log_mixture(tracker, "blue", bp, init.blue_policy, iteration=0)
        log_mixture(tracker, "red", rp, init.red_policy, iteration=0)
    print('START',v,seed,'initial',data['initial_value'],flush=True)
    for k in range(1,niter+1):
        t=time.perf_counter();m=matrix(game,bp,rp);sol=solve_zero_sum_matrix_game(m,tolerance=1e-9);V=float(sol.value)
        bc=PPOConfig(**{**params,'seed':seed+k-1});rc=PPOConfig(**{**params,'seed':seed+90+k-1})
        def log_oracle(player):
            if tracker is None:
                return None
            def emit(metrics):
                # Global per-player training step is monotonic across PSRO iterations.
                # Local step and iteration remain available for filtering a single BR.
                local_steps = int(metrics["steps"])
                tracker.log({f"ppo/{player}/global_steps": (k-1)*steps + local_steps,
                             f"ppo/{player}/local_steps": local_steps,
                             f"ppo/{player}/psro_iteration": k,
                             **{f"ppo/{player}/{key}": val for key,val in metrics.items()
                                if key != "steps" and val is not None}})
            return emit
        B,bs0,_=train_relgnn_blue_best_response(game,actor_kind=actor,critic_kind=critic,
           opponent_population=rp,opponent_weights=sol.red_policy,initial_graph=cfg.initial_graph,
           initial_ammo=ALPHA,initial_positions=cfg.initial_positions,config=bc,name=f'{v}_{seed}_B{k}',gnn_dim=16,metric_callback=log_oracle('blue'))
        R,rs0=train_ppo_best_response(game,player='red',opponent_population=bp,
           opponent_weights=sol.blue_policy,initial_graph=cfg.initial_graph,
           initial_ammo=ALPHA,initial_positions=cfg.initial_positions,config=rc,name=f'{v}_{seed}_R{k}',metric_callback=log_oracle('red'))
        bv=sum(float(w)*evalpair(game,B,p) for w,p in strict_zip(sol.red_policy,rp))
        rv=sum(float(w)*evalpair(game,p,R) for w,p in strict_zip(sol.blue_policy,bp))
        bnew=B.signature(digits=7) not in bs;rnew=R.signature(digits=7) not in rs
        row=dict(iteration=k,blue_population_before=len(bp),red_population_before=len(rp),meta_before=V,
           blue_BR=bv,red_BR=rv,blue_improves=bv<V-1e-9,red_improves=rv>V+1e-9,
           blue_gain=V-bv,red_gain=rv-V,blue_added=bnew,red_added=rnew,
           blue_seconds=float(bs0.elapsed_seconds),red_seconds=float(rs0.elapsed_seconds),
           blue_mixture_before=sol.blue_policy.tolist(),red_mixture_before=sol.red_policy.tolist(),
           blue_names_before=[p.name for p in bp],red_names_before=[p.name for p in rp],
           # These are evaluations of PPO candidates, NOT exact full-game best-response bounds.
           learned_br_lower_candidate=float(bv),learned_br_upper_candidate=float(rv),
           learned_br_candidate_gap=float(rv-bv),
           restricted_nash_gap_before=float(sol.strategy_gap))
        if bnew:bp.append(B);bs.add(B.signature(digits=7))
        if rnew:rp.append(R);rs.add(R.signature(digits=7))
        m=matrix(game,bp,rp);sol=solve_zero_sum_matrix_game(m,tolerance=1e-9)
        row.update(meta_after=float(sol.value),iteration_seconds=time.perf_counter()-t,
                   restricted_nash_gap_after=float(sol.strategy_gap),
                   blue_mixture_after=sol.blue_policy.tolist(),
                   red_mixture_after=sol.red_policy.tolist(),
                   blue_names_after=[p.name for p in bp],red_names_after=[p.name for p in rp])
        data['history'].append(row);data['elapsed_seconds']=time.perf_counter()-t0
        if tracker is not None:
            tracker.log({"psro/iteration": k, "psro/meta_before": V,
                         "psro/meta_value": float(sol.value),
                         "psro/abs_gap_to_svi": abs(float(sol.value)-EXACT),
                         "psro/blue_best_response": bv, "psro/red_best_response": rv,
                         "psro/blue_gain": V-bv, "psro/red_gain": rv-V,
                         "psro/blue_population": len(bp), "psro/red_population": len(rp),
                         "psro/blue_oracle_seconds": float(bs0.elapsed_seconds),
                         "psro/red_oracle_seconds": float(rs0.elapsed_seconds),
                         "psro/iteration_seconds": float(row['iteration_seconds']),
                         "psro/learned_br_lower_candidate": float(bv),
                         "psro/learned_br_upper_candidate": float(rv),
                         "psro/learned_br_candidate_gap": float(rv-bv),
                         "psro/restricted_nash_gap": float(sol.strategy_gap),
                         "psro/restricted_nash_gap_before": float(row['restricted_nash_gap_before'])})
            log_mixture(tracker, "blue", bp, sol.blue_policy, iteration=k)
            log_mixture(tracker, "red", rp, sol.red_policy, iteration=k)
        dest.write_text(json.dumps(data,indent=2))
        print('ITER',v,seed,k,'V',round(V,3),'Blue',round(bv,3),'Red',round(rv,3),'new',round(float(sol.value),3),'s',round(row['iteration_seconds'],1),flush=True)
    data.update(status='complete',final=float(sol.value),abs_gap=abs(float(sol.value)-EXACT),
       final_blue=sol.blue_policy.tolist(),final_red=sol.red_policy.tolist(),
       blue_names=[p.name for p in bp],red_names=[p.name for p in rp],
       payoff_matrix=m.tolist(),total_seconds=time.perf_counter()-t0)
    dest.write_text(json.dumps(data,indent=2))
    if tracker is not None:
        # Artifacts make the final restricted payoff matrix and policy labels inspectable.
        tracker.log({"psro/final_payoff_matrix": tracker.Table(
            columns=["red_policy", *[p.name for p in bp]],
            data=[[r.name, *[float(x) for x in matrix_row]]
                  for r,matrix_row in zip(rp,m.tolist())])})
        tracker.summary.update({"final_meta_value": data["final"],
                                "final_abs_gap_to_svi": data["abs_gap"],
                                "final_blue_population": len(bp),
                                "final_red_population": len(rp),
                                "total_seconds": data["total_seconds"]})
        tracker.finish()
    print('DONE',v,seed,'V',data['final'],'gap',data['abs_gap'],'seconds',round(data['total_seconds'],1),flush=True)

def main():
    parser = argparse.ArgumentParser(description='Portable full PSRO actor-critic experiment')
    parser.add_argument('--variant', choices=[*VARIANTS, 'all'], default='all')
    parser.add_argument('--seed', type=int, help='One seed; overrides --seeds')
    parser.add_argument('--seeds', type=int, nargs='+', default=[11, 12, 13])
    parser.add_argument('--steps', type=int, default=6000, help='PPO environment steps per oracle')
    parser.add_argument('--iterations', type=int, default=5, help='PSRO expansions')
    parser.add_argument('--out-dir', type=Path, default=ROOT / 'results')
    parser.add_argument('--threads', type=int, default=1, help='PyTorch CPU threads')
    parser.add_argument('--force', action='store_true', help='Overwrite completed matching runs')
    parser.add_argument('--wandb', action='store_true', help='Enable W&B logging (disabled by default)')
    parser.add_argument('--wandb-project', default='agt5-psro', help='W&B project name')
    parser.add_argument('--wandb-entity', default=None, help='Optional W&B username/team')
    parser.add_argument('--wandb-mode', choices=['online', 'offline', 'disabled'], default='online')
    args = parser.parse_args()
    if args.steps <= 0 or args.iterations <= 0 or args.threads <= 0:
        parser.error('--steps, --iterations, and --threads must be positive')
    seeds = [args.seed] if args.seed is not None else args.seeds
    variants = list(VARIANTS) if args.variant == 'all' else [args.variant]
    for v in variants:
        for seed in seeds:
            target = args.out_dir / f'{v}_seed{seed}.json'
            if target.exists() and not args.force:
                try:
                    existing = json.loads(target.read_text())
                    if (existing.get('status') == 'complete'
                        and existing.get('steps') == args.steps
                        and existing.get('n_expansions') == args.iterations):
                        print(f'SKIP completed {v} seed {seed}', flush=True)
                        continue
                except (ValueError, OSError):
                    pass
            run(v, seed, steps=args.steps, niter=args.iterations,
                out_dir=args.out_dir, threads=args.threads,
                wandb_enabled=args.wandb, wandb_project=args.wandb_project,
                wandb_entity=args.wandb_entity, wandb_mode=args.wandb_mode)

if __name__ == '__main__':
    main()
