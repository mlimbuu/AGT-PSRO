from runs.main_run_SB import BenchmarkConfig, TerrainEdge, RiskEdge, AttackConfiguration, SupportRelation, build_scenario
from adversarial_graph_game import PruningMode, solve_ammo_layers
from dataclasses import replace
from time import perf_counter
# Reconstruct graph directly from slide
G1,G2,G3=1,2,3
cfg=BenchmarkConfig(name='5-node Type II (slide)',goal_node=4,num_blue_agents=2, initial_positions=(0,0), initial_graph=G1,
 terrain_edges=tuple(TerrainEdge(u,v,10.0) for u,v in [(0,1),(0,2),(1,4),(2,4),(2,3),(3,4)]),
 attack_configurations=(AttackConfiguration(G1,(RiskEdge(1,4,200.0),),'G1'),AttackConfiguration(G2,(RiskEdge(2,4,200.0),),'G2'),AttackConfiguration(G3,(RiskEdge(2,3,200.0),),'G3')),
 red_transitions={k:(1,2,3) for k in [1,2,3]},
 support_relations=(SupportRelation(3,1,4),SupportRelation(1,2,3),SupportRelation(1,2,4)),
 ammo_levels=(1,), gamma=1.-1e-9, wait_cost=1., active_support_wait_cost=1., use_agent_symmetry=True, repetitions=1)
if __name__=='__main__':
 for s in [False,True]:
  t=perf_counter(); game=build_scenario(cfg,max_ammo=1).build_game(with_support=s)
  r=solve_ammo_layers(game,pruning_mode=PruningMode.NONE,tolerance=1e-9,max_iterations=5000)
  print('support',s,'v',r.values[(1,1)][game.canonical_positions((0,0))], 'secs',perf_counter()-t,'states',len(r.values[(1,1)]),flush=True)
