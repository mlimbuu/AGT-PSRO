# Portable AGT 5-node Type II full PSRO actor-critic comparison

This package contains the **game solver, PPO oracles, relational GNN ablation, scenario, experiment runner, and summarizer**. It is a copy of the prior experiment's source with a portable entry point: no `/mnt/data` dependencies, no manual PYTHONPATH setting, and user-selectable output paths.

## Python 3.9 f-string correction and complete source audit (Nov 12, 2026)

See [PYTHON39_SYNTAX_FIX.md](PYTHON39_SYNTAX_FIX.md) for the fix to `main_run.py` and `main_run_SB.py`, 3.9 grammar verification for every `.py` file, and VM commands. A prior validation using `ast.parse(feature_version=(3, 9))` was insufficient to detect f-string quote reuse; this version uses the strict 3.9 `parso` grammar in addition to compiling code under the active interpreter.

## Python 3.9 / import-path fix (November 2026)

This corrected archive fixes the direct-file `ModuleNotFoundError: No module named
'adversarial_graph_game'` and removes Python 3.10-only runtime constructs
from the execution paths. The original project used `dataclass(slots=True)`,
`zip(..., strict=True)`, `typing.TypeAlias`, runtime union types and
`isinstance(x, A | B)`. The compatibility layer retains slots on Python 3.10+
and validates zip lengths on Python 3.9. The game/PSRO algorithms are unchanged.

**Linux VM with standard Python 3.9**, in the extracted project directory:

```bash
python3 --version                # Ensure it is 3.9.x (or set PYTHON_BIN=python3.9)
bash setup_linux_vm.sh           # Creates .venv; installs pinned 3.9 wheels
source .venv/bin/activate
python verify_portability.py
bash run_smoke.sh                 # 4 architecture smoke tests + BC diagnostic
```

For a quick direct-file test (without any `PYTHONPATH` or package installation):

```bash
python code_src/runs/main_run_SB_RelGNN_behavior_cloning_diagnostic.py --seeds 11 --epochs 1
```

The **original behavior-cloning diagnostic** is still the default if you omit
`--epochs` and `--seeds`: 80 epochs, seeds 11/12/13, both Static and Action Rel-GNN.
You can redirect its JSON via `--out-dir /your/output/directory`.

The **full experiment** has unchanged defaults and is launched from the project
root as before:

```bash
python run_full_arch_psro.py --variant all --seeds 11 12 13 --steps 6000 --iterations 5 --out-dir results
python summarize_results.py --results results
```

The short smoke test is only an installation/runtime check and **cannot be
used as PSRO performance evidence**.

On a shared or headless Linux VM, run from the project root and set `PYTHON_BIN`
if necessary. No sudo access and no system-Python modification are required.
The `pyproject.toml` also permits optional editable installation with
`python -m pip install -e . --no-deps`, but direct script execution no longer
requires it. For GPU execution, replace the default PyTorch package with an
appropriate CUDA build; the current models run on CPU by default.

**Validation caveat:** This archive was smoke-tested with Python 3.13 and its
3.9 parser compatibility checked. A real Python 3.9 interpreter was not
available in the creation sandbox, so the supplied VM commands should be run
once on your 3.9 machine to confirm its installed binary dependencies.

---

## Experiment

- 5 nodes, three exclusive Red configurations G1/G2/G3, all-to-all Red transitions.
- Two Blue agents begin at (0,0), aim for node 4; support enabled; alpha=1.
- Initial Blue population: SP, risk-aware RA, support-aware SA; initial Red policy: stay-G1.
- Full PSRO with Nash solver, exact fixed-policy pair payoff evaluation, MLP-PPO Red oracle.
- Four Blue combinations: `mlp_mlp`, `mlp_rel`, `rel_mlp`, `rel_rel`.
- Default: 6000 PPO steps per Blue/Red oracle call, 5 PSRO expansions, seeds 11,12,13.
- Exact full-game SVI reference: 43.9336763713 (small-game reference; not an exploitability certificate).

## Installation on Linux / macOS / cloud VM

```bash
unzip AGT5_PSRO_portable.zip
cd AGT5_PSRO_portable
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python run_full_arch_psro.py --variant all --seeds 11 12 13 --steps 6000 --iterations 5
python summarize_results.py
```

## Installation on Windows (PowerShell)

Extract the ZIP (e.g. via File Explorer) and open PowerShell inside the extracted directory:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe run_full_arch_psro.py --variant all --seeds 11 12 13 --steps 6000 --iterations 5
.\.venv\Scripts\python.exe summarize_results.py
```

PyTorch installation can vary by OS/GPU. `requirements.txt` installs a standard PyTorch build. For CUDA acceleration, use the official PyTorch build for the target driver/CUDA version. This code can run on CPU and does not require a GPU; it does not automatically place the networks on CUDA.

## Short smoke test

```bash
python run_full_arch_psro.py --variant rel_rel --seed 11 --steps 64 --iterations 1 --out-dir test_results
python summarize_results.py --results test_results
```

Smoke-test outputs **must not** be interpreted as scientific experiment results.

## Output and resuming

- Writes `results/<variant>_seed<seed>.json` after each PSRO iteration and on completion.
- `python summarize_results.py` produces `per_run_results.csv`, `per_iteration_results.csv`, `architecture_summary.csv`.
- Default behavior skips complete JSON runs only when they match requested steps and iteration count. Incomplete runs start over; this is **not mid-run resume**. `--force` overwrites complete runs.
- Change `--out-dir` to point to cloud-mounted or shared storage (e.g. `/scratch/user/psro_results`).
- Use `--threads 1` or another appropriate integer for PyTorch CPU threads.
- Do not run multiple jobs against the *same variant and seed output file* concurrently.

## Running on a scheduler / many-core cloud VM

Run independent architectures and seeds in separate jobs, with a shared output directory. Example:

```bash
python run_full_arch_psro.py --variant mlp_mlp --seed 11 --out-dir /scratch/psro_results
python run_full_arch_psro.py --variant rel_mlp --seed 11 --out-dir /scratch/psro_results
```

Do not launch all 12 as simultaneous processes unless you have enough CPU/GPU resources; the original timings were from concurrent jobs and are hardware-dependent.

## Important limitations

- Baseline MLP does not receive exactly the same graph-derived features as Rel-GNN; architectural comparison is not feature-controlled.
- Rel-GNN vs MLP actor also changes action parameterization.
- Frozen stochastic policies (not greedy policy snapshots) are used for PSRO payoffs.
- Training is approximate; five iterations does not prove convergence, and the difference to SVI is not exploitability.
- No certified full-game BR stopping rule, no mid-iteration policy checkpoint, and numerical reproducibility across CPU/GPU and PyTorch versions is not guaranteed.
- The bundled `code_src/` includes related existing solver scripts as dependencies; run only the top-level portable entry point to reproduce this experiment.
