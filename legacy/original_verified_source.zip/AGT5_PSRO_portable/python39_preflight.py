#!/usr/bin/env python3
"""Repository-wide Python 3.9 preflight.

Run this file with the EXACT interpreter used for experiments. When run under
Python 3.9, compiling every file uses Python 3.9's *real* grammar, including
its f-string restrictions. This does not execute full training jobs.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib
import json
from pathlib import Path
import subprocess
import sys
import traceback

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "SOURCE_SHA256.json"


def all_sources():
    return sorted(p for p in ROOT.rglob("*.py")
                  if not any(part in (".venv", "__pycache__", ".git") for part in p.parts))


def relative(path):
    return path.relative_to(ROOT).as_posix()


def check_integrity(files):
    expected = json.loads(MANIFEST.read_text(encoding="utf-8"))
    current = {relative(path): hashlib.sha256(path.read_bytes()).hexdigest()
               for path in files}
    missing = sorted(set(expected) - set(current))
    unexpected = sorted(set(current) - set(expected))
    modified = sorted(name for name in set(expected) & set(current)
                      if expected[name] != current[name])
    for name in missing:
        print("FAIL MISSING:", name)
    for name in modified:
        print("FAIL MODIFIED:", name)
    for name in unexpected:
        print("NOTE NEW SOURCE:", name)
    if not missing and not modified:
        print("PASS: distributed source hashes match ({} files)".format(len(expected)))
    return not missing and not modified


def check_syntax(files):
    errors = []
    for path in files:
        try:
            compile(path.read_bytes(), str(path), "exec")
            print("PASS SYNTAX:", relative(path))
        except (SyntaxError, UnicodeError) as exc:
            errors.append((relative(path), "{}: {}".format(type(exc).__name__, exc)))
            print("FAIL SYNTAX:", relative(path), exc)
    print("Syntax compilation: {}/{} passed under Python {}".format(
        len(files) - len(errors), len(files), sys.version.split()[0]))

    # Python 3.12+ accepts syntax that old Pythons don't. Compiling with 3.13
    # is not proof of 3.9 compatibility. If present, use independent parso.
    if sys.version_info >= (3, 10):
        try:
            import parso
        except ImportError:
            print("FAIL: Python >=3.10 needs `python -m pip install parso` "
                  "for an independent strict Python 3.9 grammar check.")
            errors.append(("grammar", "parso not installed"))
        else:
            grammar = parso.load_grammar(version="3.9")
            for path in files:
                source = path.read_text(encoding="utf-8")
                tree = grammar.parse(source, error_recovery=True)
                for error in grammar.iter_errors(tree):
                    print("FAIL PY3.9 GRAMMAR:", relative(path), error.start_pos, error)
                    errors.append((relative(path), "parso Python 3.9 syntax error"))
            if not any(label == "grammar" or msg == "parso Python 3.9 syntax error"
                       for label, msg in errors):
                print("PASS: strict Python 3.9 grammar for every source file (parso)")
    else:
        print("PASS: native Python 3.9 compiler checked all f-string syntax")
    return not errors


def module_names():
    run_dir = ROOT / "code_src" / "runs"
    pkg_dir = ROOT / "code_src" / "adversarial_graph_game"
    runs = ["runs." + path.stem for path in sorted(run_dir.glob("main_*.py"))]
    game = ["adversarial_graph_game." + path.stem
            for path in sorted(pkg_dir.glob("*.py"))]
    return runs, game


def check_imports(isolated=False):
    sys.path.insert(0, str(ROOT / "code_src"))
    sys.path.insert(0, str(ROOT / "code_scenario"))
    runs, game = module_names()
    failures = []
    for module in runs + game:
        try:
            if isolated:
                snippet = ("import sys; sys.path.insert(0, {!r}); "
                           "sys.path.insert(0, {!r}); "
                           "import importlib; importlib.import_module({!r})").format(
                               str(ROOT / "code_src"), str(ROOT / "code_scenario"), module)
                completed = subprocess.run([sys.executable, "-c", snippet],
                                           text=True, stdout=subprocess.PIPE,
                                           stderr=subprocess.PIPE, timeout=90)
                if completed.returncode:
                    raise RuntimeError(completed.stderr[-3000:])
            else:
                importlib.import_module(module)
            print("PASS IMPORT:", module)
        except Exception as exc:
            failures.append(module)
            print("FAIL IMPORT:", module, type(exc).__name__, str(exc))
            if not isolated:
                traceback.print_exc(limit=2)
    print("Module imports: {}/{} passed".format(
        len(runs) + len(game) - len(failures), len(runs) + len(game)))
    return not failures


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--require-python39", action="store_true",
                        help="Fail if not actually running the Python 3.9 interpreter")
    parser.add_argument("--syntax-only", action="store_true",
                        help="Do not import packages (useful before installing dependencies)")
    parser.add_argument("--isolated-imports", action="store_true",
                        help="Import each module in a fresh interpreter; slower but thorough")
    parser.add_argument("--skip-hashes", action="store_true",
                        help="For local source edits; still checks syntax and imports")
    args = parser.parse_args()

    print("Python executable:", sys.executable)
    print("Python version:", sys.version.split()[0])
    print("Project root:", ROOT)
    results = []
    if args.require_python39:
        is_py39 = sys.version_info[:2] == (3, 9)
        print("{}: native Python 3.9 interpreter".format("PASS" if is_py39 else "FAIL"))
        results.append(is_py39)
    if not MANIFEST.is_file() and not args.skip_hashes:
        print("FAIL: SOURCE_SHA256.json missing; wrong extraction directory?")
        results.append(False)

    files = all_sources()
    if not args.skip_hashes and MANIFEST.is_file():
        results.append(check_integrity(files))
    syntax_ok = check_syntax(files)
    results.append(syntax_ok)
    if syntax_ok and not args.syntax_only:
        results.append(check_imports(isolated=args.isolated_imports))
    elif not syntax_ok and not args.syntax_only:
        print("SKIP: import checks until syntax errors are repaired")
    print("\nRESULT:", "PASS" if all(results) else "FAIL")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
