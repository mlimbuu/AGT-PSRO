# Python 3.9 syntax audit and VM validation

## What failed

`code_src/runs/main_run_SB.py` (lines 713-717) and
`code_src/runs/main_run.py` (lines 714-718) used Python 3.12+ f-string
parsing features: their outer double-quoted f-strings also used double
quotes to index `metadata` inside `{...}`. Python 3.9 reports
`SyntaxError: f-string: unmatched '['`.

Both files now use single-quoted dictionary keys inside the double-quoted
f-strings, e.g.:

```python
f"{metadata['benchmark_wall_clock']['elapsed_formatted']} "
```

## Validation performed for this revision

- All **38** `.py` files compiled on Python 3.13 and passed an
  independent **Python 3.9 grammar** parser (parso 0.8.7).
- **13** run entry-point modules imported without running their main() functions.
- **19** `adversarial_graph_game` package modules imported.
- 4 actor/critic configurations passed a short PSRO smoke test.
- `main_run_SB_PPO_relgnn_diagnostic.py` completed a reduced
  8-step, one-seed run for both static and action Rel-GNN modes.
- The behavior-cloning diagnostic passed with `--epochs 1 --seeds 11`.

**Limitations:** The test sandbox has Python 3.13.5, not a real Python 3.9
runtime. We attempted to download Python 3.9, but the download was blocked
by network/DNS restrictions. The strict 3.9 grammar check catches the
reported f-string bug; actual 3.9 runtime compatibility must be confirmed
on your VM. Short smoke-test results are NOT scientific results.

## On your VM (existing environment)

Run these commands *from the new archive's project root*:

```bash
source /home/klimbu2/myenv_agt/bin/activate
python --version                     # Should show 3.9.9
python -m compileall -q code_src code_scenario .
python verify_portability.py         # Compiles and imports every run module
bash run_smoke.sh                    # Short CPU-only runs
```

After that, execute your diagnostic normally:

```bash
python code_src/runs/main_run_SB_PPO_relgnn_diagnostic.py
```

**Warning:** This particular diagnostic has 10,000 PPO steps per configuration
and 3 seeds as hard-coded defaults; unlike the short verification above, the
normal command is a full experiment and can take substantial time.

### Avoid accidentally launching the old code

Extract into a NEW directory first, or explicitly overwrite the older code.
Check that `main_run_SB.py` contains the corrected version:

```bash
grep -n "elapsed_formatted" code_src/runs/main_run_SB.py
```

The f-string on line 713 should use single quotes for its dictionary keys.
